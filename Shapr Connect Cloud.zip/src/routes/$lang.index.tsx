import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Check } from "lucide-react";
import wolf from "@/assets/wolf-hero.png";
import { dict, isLang, DEFAULT_LANG, type Lang } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/")({
  head: ({ params }) => {
    const lang: Lang = isLang(params.lang) ? params.lang : DEFAULT_LANG;
    const t = dict(lang);
    const title = `Shapr — ${t.hero.title} ${t.hero.titleAccent}`;
    return {
      meta: [
        { title },
        { name: "description", content: t.hero.lead },
        { property: "og:title", content: title },
        { property: "og:description", content: t.hero.lead },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: Landing,
});

function Landing() {
  return (
    <main>
      <Hero />
      <BottomCTA />
    </main>
  );
}

function Hero() {
  const { lang, t } = useT();
  const fr = lang === "fr";

  return (
    <section className="relative overflow-hidden">
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full opacity-70 blur-[120px]"
        style={{ background: "var(--gradient-glow)" }}
      />
      <div className="relative mx-auto grid max-w-5xl gap-10 px-5 py-14 lg:grid-cols-[1fr_1fr] lg:items-center lg:py-20">
        <div className="animate-rise">
          <img
            src={wolf}
            alt=""
            width={1024}
            height={1024}
            className="mb-5 h-32 w-auto"
          />
          <h1 className="text-4xl font-extrabold leading-[1.05] sm:text-5xl">
            {t.hero.title} <span className="serif-italic">{t.hero.titleAccent}</span>
          </h1>
          <p className="mt-4 max-w-md text-lg leading-relaxed text-muted-foreground">
            {fr
              ? "Une photo, un plan clair, puis une leçon par jour. C'est tout."
              : "One photo, a clear plan, then one lesson a day. That's it."}
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-4">
            <Link
              to="/$lang/academy"
              params={{ lang }}
              className="btn-chunky inline-flex items-center gap-2 bg-primary px-7 py-4 font-bold text-primary-foreground"
            >
              {fr ? "Commencer" : "Start"}
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/$lang/example"
              params={{ lang }}
              className="text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground"
            >
              {t.hero.orExample}
            </Link>
          </div>
        </div>

        <div className="animate-rise" style={{ animationDelay: "120ms" }}>
          <div className="panel p-6 sm:p-7">
            <p className="label-mono text-primary">Scan</p>
            <h2 className="mt-2 font-display text-2xl leading-tight">
              {fr ? "Une photo, une lecture honnête" : "One photo, an honest read"}
            </h2>
            <ul className="mt-4 space-y-2.5 text-sm text-muted-foreground">
              {(fr
                ? ["Douze aspects de ton visage notés", "Les trois changements qui comptent", "Un plan dans le bon ordre"]
                : ["Twelve facial areas scored", "The three changes that matter", "A plan in the right order"]
              ).map((line) => (
                <li key={line} className="flex gap-2.5">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                  <span>{line}</span>
                </li>
              ))}
            </ul>
            <Link
              to="/$lang/scan"
              params={{ lang }}
              className="btn-chunky mt-6 inline-flex w-full items-center justify-center gap-2 bg-primary px-6 py-4 font-semibold text-primary-foreground"
            >
              {fr ? "Lancer mon scan" : "Start my scan"}
              <ArrowRight className="h-4 w-4" />
            </Link>
            <p className="mt-4 text-center text-xs text-muted-foreground">{t.hero.reassure}</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function BottomCTA() {
  const { lang } = useT();
  const fr = lang === "fr";
  return (
    <section className="border-y border-border bg-surface/50">
      <div className="mx-auto max-w-5xl px-5 py-16 sm:py-20">
        <p className="label-mono text-primary">{fr ? "Simple et gratuit" : "Simple and free"}</p>
        <div className="mt-3 grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
          <div>
            <h2 className="max-w-xl text-3xl font-extrabold sm:text-4xl">
              {fr
                ? "Une photo. Une note claire. Un premier plan d'action."
                : "One photo. One clear score. One first action plan."}
            </h2>
            <ul className="mt-6 grid gap-3 text-sm text-muted-foreground sm:grid-cols-3">
              {(fr
                ? ["Analyse du visage", "Note et potentiel", "3 leçons offertes"]
                : ["Face analysis", "Score and potential", "3 free lessons"]
              ).map((item) => (
                <li key={item} className="flex items-center gap-2">
                  <Check className="h-4 w-4 shrink-0 text-primary" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <Link
            to="/$lang/scan"
            params={{ lang }}
            className="btn-chunky inline-flex items-center justify-center gap-2 bg-primary px-8 py-4 font-bold text-primary-foreground"
          >
            {fr ? "Lancer mon scan gratuit" : "Start my free scan"}
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </div>
    </section>
  );
}
