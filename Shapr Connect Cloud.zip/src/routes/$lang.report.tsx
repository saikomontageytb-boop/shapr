import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ReportView } from "@/components/report/ReportView";
import type { ScanRecord } from "@/lib/analysis-schema";
import { track } from "@/lib/analytics";
import { useAuth } from "@/lib/auth";
import { fetchCloudScans, saveCloudQuests, saveScanToCloud } from "@/lib/cloud-scans";
import { dict, isLang, DEFAULT_LANG } from "@/lib/i18n";
import {
  clearPendingAnalysis,
  getPendingAnalysis,
  getSessionPhoto,
} from "@/lib/pending-photo";
import { useAccess } from "@/lib/access";
import {
  EMPTY_PROGRESS,
  toggleQuest,
  xpFor,
  type ProgressState,
} from "@/lib/progress";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/report")({
  head: ({ params }) => {
    const t = dict(isLang(params.lang) ? params.lang : DEFAULT_LANG);
    return {
      meta: [
        { title: t.report.metaTitle },
        { name: "description", content: t.report.metaDesc },
        { property: "og:title", content: t.report.metaTitle },
        { property: "og:description", content: t.report.metaDesc },
      ],
    };
  },
  component: ReportPage,
});

function ReportPage() {
  const { lang, t } = useT();
  const { user, loading } = useAuth();
  const access = useAccess();
  const [state, setState] = useState<ProgressState>(EMPTY_PROGRESS);
  const [cloudScans, setCloudScans] = useState<ScanRecord[] | null>(null);
  const [photo, setPhoto] = useState<string | null>(null);

  useEffect(() => {
    setPhoto(getSessionPhoto());
  }, []);

  useEffect(() => {
    const pending = getPendingAnalysis();
    const pendingScan: ScanRecord | null = pending
      ? { id: "pending", created_at: new Date().toISOString(), analysis: pending }
      : null;

    if (!user) {
      const scans = pendingScan ? [pendingScan] : [];
      setCloudScans(scans);
      setState({ ...EMPTY_PROGRESS, scans });
      return;
    }

    const sync = async () => {
      if (pending && (await saveScanToCloud(pending))) clearPendingAnalysis();
      const cloud = await fetchCloudScans();
      const scans = cloud.scans.length > 0 ? cloud.scans : pendingScan ? [pendingScan] : [];
      setCloudScans(scans);
      setState({
        scans,
        completedQuests: cloud.completedQuests,
        achievements: scans.length
          ? ["first_scan", ...(scans.length > 1 ? ["rescan"] : [])]
          : [],
        unlocked: false,
      });
    };
    void sync();
  }, [user]);

  if (loading) return <div className="min-h-[60vh]" />;

  const usingCloud = Boolean(user && cloudScans && cloudScans.length > 0);
  const scans = usingCloud ? cloudScans! : [];
  const scan = scans.length ? scans[scans.length - 1]! : null;

  if (!scan) {
    return (
      <main className="mx-auto flex min-h-[70vh] max-w-2xl flex-col items-center justify-center px-5 text-center">
        <p className="label-mono">{t.report.noneLabel}</p>
        <h1 className="mt-3 font-display text-4xl">{t.report.noneTitle}</h1>
        <p className="mt-3 text-muted-foreground">{t.report.noneBody}</p>
        <Link
          to="/$lang/scan"
          params={{ lang }}
          className="mt-8 rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          {t.common.startScan}
        </Link>
      </main>
    );
  }

  const analysis = scan.analysis;
  const xp = xpFor(state, analysis);

  return (
    <main className="mx-auto max-w-5xl px-5 py-12">
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="label-mono">{t.report.savedOn(scans.length, usingCloud)}</p>
          <h1 className="font-display text-3xl">{t.report.title}</h1>
        </div>
        <Link
          to="/$lang/scan"
          params={{ lang }}
          className="rounded-full bg-surface-2 px-5 py-2.5 text-sm font-medium transition-colors hover:text-primary"
        >
          {t.report.newScan}
        </Link>
      </div>

      {!user && (
        <section className="panel mb-8 flex flex-wrap items-center justify-between gap-4 p-6">
          <div>
            <h2 className="font-display text-xl">{t.report.syncTitle}</h2>
            <p className="mt-1 max-w-md text-sm text-muted-foreground">
              {t.report.syncBody}
            </p>
          </div>
          <Link
            to="/$lang/auth"
            params={{ lang }}
            className="rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            {t.report.syncCta}
          </Link>
        </section>
      )}

      {scans.length > 1 && <ScanDelta scans={scans} />}

      <ReportView
        analysis={analysis}
        access={access}
        photo={photo ?? undefined}
        completed={state.completedQuests}
        achievements={state.achievements}
        scans={scans}
        xp={xp}
        onToggleQuest={(id) => {
          const next = toggleQuest(state, id);
          setState(next);
          if (user) void saveCloudQuests(scan.id, next.completedQuests);
          if (next.completedQuests.includes(id))
            track("recommendation_completed", { quest: id });
        }}
      />

      <Link
        to="/$lang/academy"
        params={{ lang }}
        className="panel mt-12 flex items-center justify-between gap-4 p-6 transition-colors hover:bg-surface-2/60"
      >
        <span>
          <span className="label-mono">{lang === "fr" ? "Académie" : "Academy"}</span>
          <span className="mt-1 block text-lg font-semibold">
            {lang === "fr"
              ? "Approfondir : nutrition, hormones, peau, sommeil, style"
              : "Go deeper: nutrition, hormones, skin, sleep, style"}
          </span>
        </span>
        <span aria-hidden="true" className="text-muted-foreground">&rarr;</span>
      </Link>
    </main>
  );
}

function ScanDelta({ scans }: { scans: ScanRecord[] }) {
  const { t } = useT();
  const first = scans[0]!;
  const current = scans[scans.length - 1]!;
  const delta = current.analysis.overall_score - first.analysis.overall_score;

  return (
    <section className="panel mb-10 flex flex-wrap items-center gap-8 p-6">
      <div>
        <p className="label-mono">{t.report.first}</p>
        <p className="font-display text-4xl tabular-nums">
          {first.analysis.overall_score.toFixed(1)}
        </p>
      </div>
      <span className="text-2xl text-muted-foreground">→</span>
      <div>
        <p className="label-mono">{t.report.current}</p>
        <p className="font-display text-4xl tabular-nums">
          {current.analysis.overall_score.toFixed(1)}
        </p>
      </div>
      <div
        className={`rounded-2xl px-5 py-3 ${
          delta >= 0 ? "bg-primary/12 text-primary" : "bg-surface-2 text-muted-foreground"
        }`}
      >
        <p className="label-mono">{t.report.change}</p>
        <p className="font-display text-3xl tabular-nums">
          {delta >= 0 ? "+" : ""}
          {delta.toFixed(1)}
        </p>
      </div>
      <p className="max-w-sm text-sm text-muted-foreground">
        {t.report.changed} {current.analysis.summary}
      </p>
    </section>
  );
}
