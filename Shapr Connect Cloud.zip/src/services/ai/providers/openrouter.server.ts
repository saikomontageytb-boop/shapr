import type {
  VisionAnalysisProvider,
  VisionRequest,
  VisionResponse,
} from "./types";
import { VisionProviderError } from "./types";

const ENDPOINT = "https://openrouter.ai/api/v1/chat/completions";

/**
 * OpenRouter provider — free vision tier.
 * Default model: qwen/qwen2.5-vl-72b-instruct:free (~50 scans/day).
 */
export function createOpenRouterProvider(model: string): VisionAnalysisProvider {
  return {
    id: "openrouter",
    model,
    async analyze(request: VisionRequest): Promise<VisionResponse> {
      const apiKey = process.env["OPENROUTER_API_KEY"];
      if (!apiKey) {
        throw new VisionProviderError(
          "unauthorized",
          "OpenRouter key is not configured.",
        );
      }

      const messages: Array<Record<string, unknown>> = [
        { role: "system", content: request.systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: request.userPrompt },
            { type: "image_url", image_url: { url: request.imageDataUrl } },
          ],
        },
      ];

      if (request.repair) {
        messages.push({ role: "assistant", content: request.repair.previous });
        messages.push({ role: "user", content: request.repair.instruction });
      }

      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
          "HTTP-Referer": "https://lookmap.app",
          "X-Title": "Shapr",
        },
        body: JSON.stringify({
          model,
          messages,
          response_format: { type: "json_object" },
        }),
      });

      if (!res.ok) {
        const detail = await res.text().catch(() => "");
        if (res.status === 429)
          throw new VisionProviderError(
            "rate_limited",
            "Too many scans right now.",
          );
        if (res.status === 402)
          throw new VisionProviderError("credits", "AI credits are exhausted.");
        if (res.status === 401 || res.status === 403)
          throw new VisionProviderError(
            "unauthorized",
            "OpenRouter access is blocked.",
          );
        if (res.status === 400)
          throw new VisionProviderError(
            "invalid_request",
            detail.slice(0, 200),
          );
        throw new VisionProviderError(
          "unavailable",
          `OpenRouter error ${res.status}`,
        );
      }

      const json = (await res.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
      };
      const text = json.choices?.[0]?.message?.content ?? "";
      if (!text)
        throw new VisionProviderError("unavailable", "Empty model response.");
      return { text };
    },
  };
}
