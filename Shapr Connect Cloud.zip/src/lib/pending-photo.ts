/**
 * Hand-off for a photo picked on the landing page and confirmed on /scan.
 * Session-scoped and cleared on read: the image never persists past the tab.
 */
import { analysisSchema, type Analysis } from "./analysis-schema";

const KEY = "loadout.pending-photo";

export function setPendingPhoto(dataUrl: string) {
  try {
    window.sessionStorage.setItem(KEY, dataUrl);
  } catch {
    /* storage unavailable — the scan page simply asks for the photo again */
  }
}

export function takePendingPhoto(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const value = window.sessionStorage.getItem(KEY);
    window.sessionStorage.removeItem(KEY);
    return value;
  } catch {
    return null;
  }
}

/**
 * Session-scoped copy of the scanned photo, kept only so the face map can be
 * drawn on the report page in the same tab. Never uploaded, never persisted.
 */
const SESSION_KEY = "loadout.session-photo";

export function setSessionPhoto(dataUrl: string) {
  try {
    window.sessionStorage.setItem(SESSION_KEY, dataUrl);
  } catch {
    /* storage unavailable — the face map falls back to a generic guide */
  }
}

export function getSessionPhoto(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage.getItem(SESSION_KEY);
  } catch {
    return null;
  }
}

export function clearSessionPhoto() {
  try {
    window.sessionStorage.removeItem(SESSION_KEY);
  } catch {
    /* nothing to clear */
  }
}

/**
 * Keeps a completed anonymous report through the sign-in hand-off. Only the
 * derived report is stored; the photo remains separate and never reaches the database.
 */
const PENDING_ANALYSIS_KEY = "loadout.pending-analysis";

export function setPendingAnalysis(analysis: Analysis) {
  try {
    window.sessionStorage.setItem(PENDING_ANALYSIS_KEY, JSON.stringify(analysis));
  } catch {
    /* storage unavailable — the report remains visible on the scan page */
  }
}

export function getPendingAnalysis(): Analysis | null {
  if (typeof window === "undefined") return null;
  try {
    const value = window.sessionStorage.getItem(PENDING_ANALYSIS_KEY);
    if (!value) return null;
    const parsed = analysisSchema.safeParse(JSON.parse(value));
    if (!parsed.success) {
      window.sessionStorage.removeItem(PENDING_ANALYSIS_KEY);
      return null;
    }
    return parsed.data;
  } catch {
    return null;
  }
}

export function clearPendingAnalysis() {
  try {
    window.sessionStorage.removeItem(PENDING_ANALYSIS_KEY);
  } catch {
    /* nothing to clear */
  }
}

