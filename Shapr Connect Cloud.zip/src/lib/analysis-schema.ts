import { z } from "zod";

/** Category keys the product analyses. Extensible: add a key + label here only. */
export const CATEGORY_KEYS = [
  "face_shape",
  "symmetry",
  "jawline",
  "eyes",
  "eyebrows",
  "nose",
  "skin",
  "hair",
  "facial_hair",
  "eyewear",
  "style",
  "proportions",
] as const;

export type CategoryKey = (typeof CATEGORY_KEYS)[number];

export const CATEGORY_LABELS: Record<CategoryKey, string> = {
  face_shape: "Face shape",
  symmetry: "Facial symmetry",
  jawline: "Jawline & chin",
  eyes: "Eyes",
  eyebrows: "Eyebrows",
  nose: "Nose",
  skin: "Skin",
  hair: "Hair",
  facial_hair: "Facial hair",
  eyewear: "Eyewear",
  style: "Style",
  proportions: "Facial proportions",
};

export const prioritySchema = z.enum(["low", "medium", "high"]);
export type Priority = z.infer<typeof prioritySchema>;

export const categorySchema = z.object({
  key: z.enum(CATEGORY_KEYS),
  score: z.number().min(0).max(10),
  /** Neutral description of what is visible in the photo. */
  observation: z.string().min(4),
  /** Why this matters for overall presentation. */
  why_it_matters: z.string().min(4),
  /** Actionable, safe recommendation. Empty when nothing to change. */
  recommendation: z.string().min(4),
  priority: prioritySchema,
  /** True when the trait is structural and should be worked *around*, not changed. */
  fixed_trait: z.boolean(),
});

export const upgradeSchema = z.object({
  title: z.string(),
  category: z.enum(CATEGORY_KEYS),
  impact: prioritySchema,
  why: z.string(),
  action: z.string(),
});

export const questSchema = z.object({
  id: z.string(),
  title: z.string(),
  category: z.enum(CATEGORY_KEYS),
  difficulty: z.enum(["easy", "medium", "hard"]),
  impact: prioritySchema,
  xp: z.number().int().min(20).max(400),
});

export const roadmapLevelSchema = z.object({
  level: z.number().int().min(1),
  title: z.string(),
  focus: z.string(),
  quests: z.array(questSchema).min(2).max(6),
});

/** What the visitor tells us after the photo, so advice is tailored. */
export const subjectProfileSchema = z.object({
  sex: z.enum(["male", "female", "other"]),
  age_range: z.enum(["under_18", "18_24", "25_34", "35_44", "45_plus"]),
  skin_type: z.enum(["dry", "oily", "combination", "normal", "sensitive", "unknown"]),
  body_fat: z.enum(["lean", "average", "soft", "unknown"]),
  facial_hair_goal: z.enum(["clean_shaven", "stubble", "full_beard", "not_applicable"]),
  goals: z.array(
    z.enum(["masculine", "feminine", "skin", "jawline", "hair", "style", "overall"]),
  ),
  effort: z.enum(["light", "serious", "obsessive"]),
});
export type SubjectProfile = z.infer<typeof subjectProfileSchema>;

/** One clickable point on the scanned photo. */
export const annotationSchema = z.object({
  id: z.string(),
  /** Percent of image width / height, 0-100, top-left origin. */
  x: z.number().min(0).max(100),
  y: z.number().min(0).max(100),
  label: z.string(),
  category: z.enum(CATEGORY_KEYS),
  severity: prioritySchema,
  observation: z.string(),
  fix: z.string(),
  xp: z.number().int().min(20).max(300),
  lesson: z.object({
    title: z.string(),
    steps: z.array(z.object({ title: z.string(), body: z.string() })).min(2).max(5),
    tip: z.string(),
    quiz: z.object({
      question: z.string(),
      options: z.array(z.string()).min(2).max(4),
      answer_index: z.number().int().min(0).max(3),
      explanation: z.string(),
    }),
  }),
});
export type Annotation = z.infer<typeof annotationSchema>;

/** Longer-horizon protocols: nutrition, hormones (natural only), sleep, training, skin. */
export const protocolSchema = z.object({
  id: z.enum(["nutrition", "hormones", "sleep", "training", "skincare", "posture"]),
  title: z.string(),
  why: z.string(),
  steps: z.array(z.string()).min(2).max(7),
  avoid: z.array(z.string()).max(5).default([]),
  timeline: z.string(),
});
export type Protocol = z.infer<typeof protocolSchema>;

export const analysisSchema = z.object({
  overall_score: z.number().min(0).max(10),
  potential_score: z.number().min(0).max(10),
  percentile: z.number().int().min(1).max(99),
  headline: z.string(),
  summary: z.string(),
  categories: z
    .array(categorySchema)
    .length(CATEGORY_KEYS.length)
    .refine(
      (categories) => new Set(categories.map((category) => category.key)).size === CATEGORY_KEYS.length,
      "Every category must appear exactly once",
    ),
  priority_actions: z.array(upgradeSchema).min(2).max(3),
  roadmap: z.array(roadmapLevelSchema).min(2).max(4),
  annotations: z.array(annotationSchema).default([]),
  protocols: z.array(protocolSchema).default([]),
});

export type Analysis = z.infer<typeof analysisSchema>;
export type Category = z.infer<typeof categorySchema>;
export type Upgrade = z.infer<typeof upgradeSchema>;
export type Quest = z.infer<typeof questSchema>;
export type RoadmapLevel = z.infer<typeof roadmapLevelSchema>;


export const scanRecordSchema = z.object({
  id: z.string(),
  created_at: z.string(),
  analysis: analysisSchema,
});
export type ScanRecord = z.infer<typeof scanRecordSchema>;

/** Errors the UI knows how to explain in human language. */
export type AnalysisErrorCode =
  | "no_face"
  | "multiple_faces"
  | "low_quality"
  | "invalid_format"
  | "too_large"
  | "rate_limited"
  | "credits"
  | "unavailable";

export const analysisResultSchema = z.discriminatedUnion("ok", [
  z.object({ ok: z.literal(true), analysis: analysisSchema }),
  z.object({
    ok: z.literal(false),
    code: z.string(),
    message: z.string(),
  }),
]);
export type AnalysisResult = z.infer<typeof analysisResultSchema>;
