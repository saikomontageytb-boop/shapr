# Fiabiliser le scan et simplifier l’accueil

## Objectif
Rendre la note faciale plus factuelle, éviter la perte d’un résultat pendant l’inscription, afficher une attente fidèle au temps réel, et nettoyer uniquement le bas de la page d’accueil.

## Changements
- Renforcer la grille d’analyse masculine avec des critères visibles et mesurables : mâchoire et menton, pommettes, zone des yeux, proportions, symétrie, nez, lèvres, peau et cheveux.
- Interdire les notes arbitrairement basses : chaque note devra être justifiée par ce qui est réellement visible, tenir compte de la qualité et de l’angle de la photo, et rester prudente quand une mesure n’est pas fiable.
- Conserver temporairement le rapport terminé dans l’onglet avant d’envoyer vers l’inscription ou la connexion.
- Après une connexion réussie, enregistrer ce rapport sur le compte puis ouvrir directement les résultats, sans demander un nouveau scan.
- Faire progresser les étapes de chargement pendant toute la durée réelle de l’analyse, sans afficher toutes les étapes trop tôt.
- Ne pas modifier le haut de l’accueil, sauf retirer le petit pictogramme placé à côté de « Scan ».
- Retirer les trois blocs « Envoyer / Analyser / Améliorer » et remplacer les deux offres contradictoires par une seule section simple : scan gratuit, ce qui est inclus, puis un bouton clair.

## Vérification
- Tester le parcours complet scan → création de compte ou connexion → résultat conservé.
- Vérifier le chargement long, l’affichage mobile et ordinateur, et l’absence d’erreurs sur les pages concernées.

## Détail technique
Le rapport temporaire restera limité à l’onglet du navigateur. La photo ne sera pas envoyée dans la base ; seul le résultat d’analyse sera enregistré après authentification.
