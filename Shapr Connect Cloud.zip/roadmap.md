# Roadmap

- [x] Copier le code source de shapr (new-base.rar) dans ce projet
- [x] Réinstaller les dépendances
- [x] Ajouter le provider OpenRouter (Qwen 2.5-VL 72B free) pour la notation photo — provider par défaut
- [x] Conserver le script Microsoft Clarity dans __root.tsx
- [x] Activer Lovable Cloud et appliquer les 8 migrations (profiles, scans, leçons, arène)
- [x] Activer la connexion email + Google
- [x] Vérifier que le build passe et que les pages chargent
- [x] Calibrer la notation sur des critères faciaux concrets et observables
- [x] Conserver le résultat du scan pendant l'inscription ou la connexion
- [x] Synchroniser l'indicateur de chargement avec l'attente réelle
- [x] Simplifier le bas de la landing page sans modifier le haut
