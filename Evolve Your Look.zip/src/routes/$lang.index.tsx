import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight } from "lucide-react";
import wolf from "@/assets/wolf-hero.png";
import { UploadZone } from "@/components/scan/UploadZone";
import { track } from "@/lib/analytics";
import { dict, isLang, DEFAULT_LANG, type Lang } from "@/lib/i18n";
import { setPendingPhoto } from "@/lib/pending-photo";
import { PRO_PRICE, PRO_PRICE_EN } from "@/lib/pro";
import { useT } from "@/lib/use-lang";


export const Route = createFileRoute("/$lang/")({
  head: ({ params }) => {
    const lang: Lang = isLang(params.lang) ? params.lang : DEFAULT_LANG;
    const t = dict(lang);
    const title = `Shapr — ${t.hero.title} ${t.hero.titleAccent}`;
    return {
      meta: [
        { title },
        { name: "description", content: t.hero.lead },
        { property: "og:title", content: title },
        { property: "og:description", content: t.hero.lead },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: Landing,
});

function Landing() {
  return (
    <main>
      <Hero />
      <Steps />
      <Plans />
    </main>
  );
}

function Hero() {
  const { lang, t } = useT();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const fr = lang === "fr";

  return (
    <section className="relative overflow-hidden">
      <div
        className="pointer-events-none absolute -top-40 left-1/2 h-[520px] w-[820px] -translate-x-1/2 rounded-full opacity-70 blur-[120px]"
        style={{ background: "var(--gradient-glow)" }}
      />
      <div className="relative mx-auto grid max-w-5xl gap-10 px-5 py-14 lg:grid-cols-[1fr_1fr] lg:items-center lg:py-20">
        <div className="animate-rise">
          <img
            src={wolf}
            alt=""
            width={1024}
            height={1024}
            className="mb-5 h-32 w-auto"
          />
          <h1 className="text-4xl font-extrabold leading-[1.05] sm:text-5xl">
            {t.hero.title} <span className="serif-italic">{t.hero.titleAccent}</span>
          </h1>
          <p className="mt-4 max-w-md text-lg leading-relaxed text-muted-foreground">
            {fr
              ? "Une photo, un plan clair, puis une leçon par jour. C'est tout."
              : "One photo, a clear plan, then one lesson a day. That's it."}
          </p>
          <div className="mt-7 flex flex-wrap items-center gap-4">
            <Link
              to="/$lang/academy"
              params={{ lang }}
              className="btn-chunky inline-flex items-center gap-2 bg-primary px-7 py-4 font-bold text-primary-foreground"
            >
              {fr ? "Commencer" : "Start"}
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/$lang/example"
              params={{ lang }}
              className="text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground"
            >
              {t.hero.orExample}
            </Link>
          </div>
        </div>

        <div className="animate-rise" style={{ animationDelay: "120ms" }}>
          <UploadZone
            compact
            copy={{ ...t.hero, ...t.upload }}
            onReady={(dataUrl) => {
              setPendingPhoto(dataUrl);
              track("photo_uploaded", { from: "hero" });
              void navigate({ to: "/$lang/scan", params: { lang } });
            }}
            onError={(message) => setError(message)}
          />
          {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
          <p className="mt-4 text-center text-xs text-muted-foreground">
            {t.hero.reassure}
          </p>
        </div>
      </div>
    </section>
  );
}


function Steps() {
  const { t } = useT();
  return (
    <section className="mx-auto max-w-5xl px-5 pb-4">
      <div className="grid gap-4 md:grid-cols-3">
        {t.steps.items.map((s) => (
          <div key={s.n} className="rounded-2xl bg-surface px-5 py-4">
            <span className="font-mono text-xs text-primary">{s.n}</span>
            <p className="mt-1 font-semibold">{s.title}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function Plans() {
  const { lang } = useT();
  const fr = lang === "fr";
  const price = fr ? PRO_PRICE : PRO_PRICE_EN;
  return (
    <section id="pricing" className="mx-auto max-w-5xl px-5 py-16">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="panel p-7">
          <p className="label-mono">{fr ? "Gratuit" : "Free"}</p>
          <p className="mt-2 font-display text-4xl">€0</p>
          <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
            <li>
              •{" "}
              {fr
                ? "Un scan complet du visage avec une note"
                : "One full face scan with a score"}
            </li>
            <li>• {fr ? "3 leçons offertes" : "3 free lessons"}</li>
          </ul>
          <Link
            to="/$lang/scan"
            params={{ lang }}
            className="mt-7 inline-flex rounded-full bg-surface-2 px-6 py-3 font-medium transition-colors hover:text-primary"
          >
            {fr ? "Lancer mon scan" : "Start my scan"}
          </Link>
        </div>
        <div className="panel bg-primary/5 p-7">
          <p className="label-mono text-primary">Pro</p>
          <p className="mt-2 font-display text-4xl">
            {price}
            <span className="ml-2 text-base text-muted-foreground">
              {fr ? "/ mois" : "/ month"}
            </span>
          </p>
          <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
            <li>
              •{" "}
              {fr
                ? "Re-scans illimités : ton score suivi dans le temps"
                : "Unlimited re-scans: your score tracked over time"}
            </li>
            <li>
              •{" "}
              {fr
                ? "Comparaison avant / après entre deux scans"
                : "Before / after comparison between two scans"}
            </li>
            <li>
              •{" "}
              {fr
                ? "Des centaines de leçons pour apprendre à être beau"
                : "Hundreds of lessons on how to look good"}
            </li>
          </ul>
          <Link
            to="/$lang/pro"
            params={{ lang }}
            className="mt-7 inline-flex rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            {fr ? "Voir Pro" : "See Pro"}
          </Link>
        </div>
      </div>
    </section>
  );
}
