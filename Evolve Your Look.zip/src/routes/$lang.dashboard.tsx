import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowUpRight, Flame } from "lucide-react";
import { TrackArt } from "@/components/academy/TrackArt";
import { useAcademy, lessonKey } from "@/lib/academy";
import { useAcademyCopy } from "@/lib/academy-copy";
import { useAuth } from "@/lib/auth";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useAccount } from "@/lib/account";
import { fetchCloudScans } from "@/lib/cloud-scans";
import {
  ACHIEVEMENTS,
  EMPTY_PROGRESS,
  academyXp,
  latestScan,
  levelFor,
  streakFor,
  xpFor,
  type ProgressState,
} from "@/lib/progress";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/dashboard")({
  head: ({ params }) => {
    const lang = isLang(params.lang) ? params.lang : DEFAULT_LANG;
    const title =
      lang === "fr" ? "Ton tableau de bord — Shapr" : "Your dashboard — Shapr";
    const description =
      lang === "fr"
        ? "Niveau, XP, série de jours, score actuel et prochaine leçon : toute ta progression sur un écran."
        : "Level, XP, day streak, current score and next lesson: all your progress on one screen.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: DashboardPage,
});

function DashboardPage() {
  const { lang, t } = useT();
  const c = useAcademyCopy();
  const { user } = useAuth();
  const tracks = useAcademy();
  const { academy, ready } = useAccount();
  const [progress, setProgress] = useState<ProgressState>(EMPTY_PROGRESS);

  useEffect(() => {
    if (!user) {
      setProgress(EMPTY_PROGRESS);
      return;
    }
    void fetchCloudScans().then(({ scans, completedQuests }) => {
      setProgress({
        scans,
        completedQuests,
        achievements: scans.length
          ? ["first_scan", ...(scans.length > 1 ? ["rescan"] : [])]
          : [],
        unlocked: false,
      });
    });
  }, [user]);

  if (!ready) return <div className="min-h-[60vh]" />;

  const scan = latestScan(progress);
  const xp = xpFor(progress, scan?.analysis ?? null) + academyXp(academy);
  const { level, progress: levelPct } = levelFor(xp);
  const streak = streakFor(academy);
  const lessonsDone = academy.completedLessons.length;

  const nextTrack =
    tracks.find((tr) =>
      tr.lessons.some((l) => !academy.completedLessons.includes(lessonKey(tr.id, l.id))),
    ) ?? null;
  const nextLesson = nextTrack
    ? nextTrack.lessons.find(
        (l) => !academy.completedLessons.includes(lessonKey(nextTrack.id, l.id)),
      )
    : null;

  return (
    <main className="mx-auto max-w-3xl px-5 py-14 sm:py-20">
      <p className="label-mono">{c.overview}</p>
      <h1 className="mt-3 font-display text-4xl sm:text-6xl">{c.dashboard}</h1>

      <section className="panel mt-10 p-6 sm:p-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="label-mono">{c.level}</p>
            <p className="font-display text-6xl leading-none tabular-nums">{level}</p>
          </div>
          <div className="text-right">
            <p className="label-mono">{c.xp}</p>
            <p className="font-display text-3xl tabular-nums">{xp}</p>
          </div>
        </div>
        <div className="mt-6 h-1.5 overflow-hidden rounded-full bg-surface-2">
          <div
            className="h-full rounded-full bg-gradient-to-r from-accent to-primary transition-[width] duration-700"
            style={{ width: `${levelPct}%` }}
          />
        </div>
      </section>

      <section className="mt-4 grid gap-4 sm:grid-cols-3">
        <Stat label={c.streak} value={String(streak)} icon />
        <Stat label={c.lessonsDone} value={String(lessonsDone)} />
        <Stat
          label={c.scoreNow}
          value={scan ? scan.analysis.overall_score.toFixed(1) : "—"}
        />
      </section>

      {nextTrack && nextLesson && (
        <section className="mt-4">
          <p className="label-mono">{c.nextUp}</p>
          <Link
            to="/$lang/academy/$track"
            params={{ lang, track: nextTrack.id }}
            className="panel mt-3 flex items-center gap-4 p-5 transition-colors hover:bg-surface-2/60"
          >
            <TrackArt
              trackId={nextTrack.id}
              alt=""
              className="h-11 w-11 shrink-0"
              rounded="rounded-2xl"
            />
            <span className="min-w-0 flex-1">
              <span className="block truncate font-semibold">{nextLesson.title}</span>
              <span className="label-mono mt-1 block">
                {nextTrack.title} · {nextLesson.minutes} {c.minutes} · {nextLesson.xp} XP
              </span>
            </span>
            <ArrowUpRight className="h-4 w-4 shrink-0 text-muted-foreground" />
          </Link>
        </section>
      )}

      <section className="mt-4 flex flex-wrap gap-3">
        <Link
          to={scan ? "/$lang/report" : "/$lang/scan"}
          params={{ lang }}
          className="rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          {scan ? c.openReport : t.common.startScan}
        </Link>
        {scan && (
          <Link
            to="/$lang/scan"
            params={{ lang }}
            className="rounded-full bg-surface-2 px-6 py-3 text-sm font-medium transition-colors hover:text-primary"
          >
            {c.newScan}
          </Link>
        )}
        <Link
          to="/$lang/academy"
          params={{ lang }}
          className="rounded-full bg-surface-2 px-6 py-3 text-sm font-medium transition-colors hover:text-primary"
        >
          {c.academyTitle}
        </Link>
      </section>

      {progress.achievements.length > 0 && (
        <section className="mt-10">
          <p className="label-mono">{c.achievements}</p>
          <div className="mt-3 flex flex-wrap gap-2">
            {progress.achievements.map((id) => (
              <span
                key={id}
                className="rounded-full bg-surface-2 px-4 py-2 text-sm"
                title={ACHIEVEMENTS[id]?.detail}
              >
                {ACHIEVEMENTS[id]?.title ?? id}
              </span>
            ))}
          </div>
        </section>
      )}

      {!user && (
        <p className="mt-12 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
          {c.signedOut}
          <Link
            to="/$lang/auth"
            params={{ lang }}
            className="text-primary underline underline-offset-4"
          >
            {c.createAccount}
          </Link>
        </p>
      )}
    </main>
  );
}

function Stat({
  label,
  value,
  icon = false,
}: {
  label: string;
  value: string;
  icon?: boolean;
}) {
  return (
    <div className="panel p-5">
      <p className="label-mono flex items-center gap-1.5">
        {icon && <Flame className="h-3.5 w-3.5 text-primary" />}
        {label}
      </p>
      <p className="mt-2 font-display text-3xl tabular-nums">{value}</p>
    </div>
  );
}
