import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, UserRound } from "lucide-react";
import { Logo } from "./Logo";
import { useAuth } from "@/lib/auth";
import { otherLang } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";
import { supabase } from "@/integrations/supabase/client";

export function SiteHeader() {
  const { lang, t } = useT();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const nav = [
    { label: t.nav.how, hash: "how" },
    { label: t.nav.analyze, hash: "analyze" },
    { label: t.nav.pricing, hash: "pricing" },
  ];

  const signOut = async () => {
    await supabase.auth.signOut();
    void navigate({ to: "/$lang", params: { lang } });
  };

  return (
    <header className="sticky top-0 z-50 bg-background/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Link
          to="/$lang"
          params={{ lang }}
          className="flex shrink-0 items-center gap-2.5"
          aria-label={t.nav.home}
        >
          <Logo className="h-8 w-8" />
          <span className="font-display text-xl font-bold tracking-tight">Shapr</span>
        </Link>

        <nav className="hidden items-center gap-6 whitespace-nowrap lg:flex" aria-label="Main">
          {nav.map((item) => (
            <Link
              key={item.hash}
              to="/$lang"
              params={{ lang }}
              hash={item.hash}
              className="text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {item.label}
            </Link>
          ))}
          <Link
            to="/$lang/example"
            params={{ lang }}
            className="text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            {t.nav.example}
          </Link>
          <Link
            to="/$lang/academy"
            params={{ lang }}
            className="text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            {t.nav.academy}
          </Link>
          <Link
            to="/$lang/pro"
            params={{ lang }}
            className="text-sm font-semibold text-primary transition-opacity hover:opacity-80"
          >
            Pro
          </Link>
        </nav>

        <div className="flex shrink-0 items-center gap-2">
          <LangSwitch />
          {user ? (
            <>
              <Link
                to="/$lang/dashboard"
                params={{ lang }}
                className="hidden items-center gap-2 rounded-full bg-surface-2 px-4 py-2 text-sm sm:inline-flex"
              >
                <UserRound className="h-4 w-4 text-primary" />
                {t.nav.dashboard}
              </Link>
              <button
                onClick={() => void signOut()}
                className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:inline-flex"
              >
                {t.nav.signOut}
              </button>
            </>
          ) : (
            <Link
              to="/$lang/auth"
              params={{ lang }}
              className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:inline-flex"
            >
              {t.nav.signIn}
            </Link>
          )}
          <Link
            to="/$lang/scan"
            params={{ lang }}
            className="hidden rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 sm:inline-flex"
          >
            {t.nav.scan}
          </Link>
          <button
            className="rounded-full bg-surface-2 p-2 lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? t.nav.menuClose : t.nav.menuOpen}
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="bg-surface px-5 py-4 lg:hidden" aria-label="Mobile">
          <ul className="space-y-3">
            {nav.map((item) => (
              <li key={item.hash}>
                <Link
                  to="/$lang"
                  params={{ lang }}
                  hash={item.hash}
                  onClick={() => setOpen(false)}
                  className="block text-sm text-muted-foreground"
                >
                  {item.label}
                </Link>
              </li>
            ))}
            <li>
              <Link
                to="/$lang/example"
                params={{ lang }}
                onClick={() => setOpen(false)}
                className="block text-sm text-muted-foreground"
              >
                {t.nav.example}
              </Link>
            </li>
            <li>
              <Link
                to="/$lang/academy"
                params={{ lang }}
                onClick={() => setOpen(false)}
                className="block text-sm text-muted-foreground"
              >
                {t.nav.academy}
              </Link>
            </li>
            <li>
              <Link
                to="/$lang/dashboard"
                params={{ lang }}
                onClick={() => setOpen(false)}
                className="block text-sm text-muted-foreground"
              >
                {t.nav.dashboard}
              </Link>
            </li>
            <li>
              {user ? (
                <button
                  onClick={() => {
                    setOpen(false);
                    void signOut();
                  }}
                  className="block text-sm text-muted-foreground"
                >
                  {t.nav.signOut}
                </button>
              ) : (
                <Link
                  to="/$lang/auth"
                  params={{ lang }}
                  onClick={() => setOpen(false)}
                  className="block text-sm text-muted-foreground"
                >
                  {t.nav.signIn}
                </Link>
              )}
            </li>
            <li>
              <Link
                to="/$lang/scan"
                params={{ lang }}
                onClick={() => setOpen(false)}
                className="mt-2 block rounded-full bg-primary px-4 py-2 text-center text-sm font-semibold text-primary-foreground"
              >
                {t.nav.scan}
              </Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}

function LangSwitch() {
  const { lang } = useT();
  const next = otherLang(lang);
  return (
    <div className="flex items-center rounded-full bg-surface-2 p-0.5 text-xs font-medium uppercase">
      <span className="rounded-full bg-primary px-2.5 py-1 text-primary-foreground">
        {lang}
      </span>
      <Link
        to="/$lang"
        params={{ lang: next }}
        className="px-2.5 py-1 text-muted-foreground transition-colors hover:text-foreground"
        aria-label={next === "fr" ? "Passer en français" : "Switch to English"}
      >
        {next}
      </Link>
    </div>
  );
}
