CREATE OR REPLACE FUNCTION public.submit_arena_run_internal(
  p_user_id uuid,
  p_score integer,
  p_difficulty smallint,
  p_question_count integer,
  p_correct_count integer,
  p_best_streak integer,
  p_eliminated boolean,
  p_category_ids text[] DEFAULT '{}',
  p_challenge_date date DEFAULT NULL
)
RETURNS TABLE (arena_xp integer, runs integer, best_score integer, daily_streak integer, xp_earned integer, new_badges text[])
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_reward numeric;
  v_xp integer;
  v_badges text[] := '{}';
BEGIN
  IF p_user_id IS NULL OR NOT EXISTS (SELECT 1 FROM auth.users WHERE id = p_user_id) THEN RAISE EXCEPTION 'Invalid member'; END IF;
  IF p_difficulty < 0 OR p_difficulty > 4 OR p_question_count < 1 OR p_question_count > 100 OR p_correct_count < 0 OR p_correct_count > p_question_count OR p_best_streak < 0 OR p_best_streak > p_question_count OR p_score < 0 OR p_score > p_question_count * 1250 THEN RAISE EXCEPTION 'Invalid run'; END IF;
  IF p_challenge_date IS NOT NULL AND p_challenge_date <> (now() AT TIME ZONE 'utc')::date THEN RAISE EXCEPTION 'Invalid daily challenge date'; END IF;
  v_reward := CASE p_difficulty WHEN 0 THEN 0.5 WHEN 1 THEN 0.8 WHEN 2 THEN 1.0 WHEN 3 THEN 1.6 ELSE 2.5 END;
  v_xp := LEAST(2500, round((p_score / 12.0) * v_reward));

  INSERT INTO public.arena_runs (user_id, challenge_date, score, xp_earned, difficulty, question_count, correct_count, best_streak, eliminated, category_ids)
  VALUES (p_user_id, p_challenge_date, p_score, v_xp, p_difficulty, p_question_count, p_correct_count, p_best_streak, p_eliminated, COALESCE(p_category_ids, '{}'));

  INSERT INTO public.player_progress (user_id, arena_xp, runs, best_score, daily_streak, last_daily_date)
  VALUES (p_user_id, v_xp, 1, p_score, CASE WHEN p_challenge_date IS NOT NULL THEN 1 ELSE 0 END, p_challenge_date)
  ON CONFLICT (user_id) DO UPDATE SET
    arena_xp = player_progress.arena_xp + v_xp,
    runs = player_progress.runs + 1,
    best_score = GREATEST(player_progress.best_score, p_score),
    daily_streak = CASE WHEN p_challenge_date IS NULL THEN player_progress.daily_streak WHEN player_progress.last_daily_date = p_challenge_date THEN player_progress.daily_streak WHEN player_progress.last_daily_date = p_challenge_date - 1 THEN player_progress.daily_streak + 1 ELSE 1 END,
    last_daily_date = COALESCE(p_challenge_date, player_progress.last_daily_date), updated_at = now();

  IF p_score > 0 THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'first_run', now()) ON CONFLICT DO NOTHING; END IF;
  IF p_best_streak >= 10 THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'streak_10', now()) ON CONFLICT DO NOTHING; END IF;
  IF p_correct_count = p_question_count AND p_question_count >= 5 THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'perfect_run', now()) ON CONFLICT DO NOTHING; END IF;
  IF p_challenge_date IS NOT NULL THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'daily_first', now()) ON CONFLICT DO NOTHING; END IF;
  SELECT COALESCE(array_agg(badge_id ORDER BY unlocked_at), '{}') INTO v_badges FROM public.badge_unlocks WHERE user_id = p_user_id;
  RETURN QUERY SELECT pp.arena_xp, pp.runs, pp.best_score, pp.daily_streak, v_xp, v_badges FROM public.player_progress pp WHERE pp.user_id = p_user_id;
END;
$$;
REVOKE ALL ON FUNCTION public.submit_arena_run_internal(uuid, integer, smallint, integer, integer, integer, boolean, text[], date) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.submit_arena_run_internal(uuid, integer, smallint, integer, integer, integer, boolean, text[], date) TO service_role;