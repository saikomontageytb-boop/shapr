CREATE TABLE public.player_progress (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  arena_xp integer NOT NULL DEFAULT 0 CHECK (arena_xp >= 0),
  runs integer NOT NULL DEFAULT 0 CHECK (runs >= 0),
  best_score integer NOT NULL DEFAULT 0 CHECK (best_score >= 0),
  daily_streak integer NOT NULL DEFAULT 0 CHECK (daily_streak >= 0),
  last_daily_date date,
  show_on_leaderboard boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.player_progress TO authenticated;
GRANT ALL ON public.player_progress TO service_role;
ALTER TABLE public.player_progress ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view own player progress" ON public.player_progress FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Members create own player progress" ON public.player_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id AND arena_xp = 0 AND runs = 0 AND best_score = 0 AND daily_streak = 0 AND last_daily_date IS NULL);
CREATE POLICY "Members update leaderboard preference" ON public.player_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.arena_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  challenge_date date,
  score integer NOT NULL CHECK (score >= 0),
  xp_earned integer NOT NULL CHECK (xp_earned >= 0),
  difficulty smallint NOT NULL CHECK (difficulty BETWEEN 0 AND 4),
  question_count integer NOT NULL CHECK (question_count BETWEEN 1 AND 100),
  correct_count integer NOT NULL CHECK (correct_count BETWEEN 0 AND question_count),
  best_streak integer NOT NULL DEFAULT 0 CHECK (best_streak BETWEEN 0 AND question_count),
  eliminated boolean NOT NULL DEFAULT false,
  category_ids text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, challenge_date)
);
GRANT SELECT ON public.arena_runs TO authenticated;
GRANT ALL ON public.arena_runs TO service_role;
ALTER TABLE public.arena_runs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view own arena runs" ON public.arena_runs FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE INDEX arena_runs_user_created_idx ON public.arena_runs (user_id, created_at DESC);

CREATE TABLE public.badge_unlocks (
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  badge_id text NOT NULL CHECK (char_length(badge_id) BETWEEN 1 AND 64),
  unlocked_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, badge_id)
);
GRANT SELECT ON public.badge_unlocks TO authenticated;
GRANT ALL ON public.badge_unlocks TO service_role;
ALTER TABLE public.badge_unlocks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Members view own badge unlocks" ON public.badge_unlocks FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.touch_player_progress_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;
CREATE TRIGGER touch_player_progress BEFORE UPDATE ON public.player_progress FOR EACH ROW EXECUTE FUNCTION public.touch_player_progress_updated_at();

CREATE OR REPLACE FUNCTION public.submit_arena_run(
  p_score integer,
  p_difficulty smallint,
  p_question_count integer,
  p_correct_count integer,
  p_best_streak integer,
  p_eliminated boolean,
  p_category_ids text[] DEFAULT '{}',
  p_challenge_date date DEFAULT NULL
)
RETURNS TABLE (arena_xp integer, runs integer, best_score integer, daily_streak integer, xp_earned integer, new_badges text[])
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_user uuid := auth.uid();
  v_reward numeric;
  v_xp integer;
  v_streak integer;
  v_badges text[] := '{}';
BEGIN
  IF v_user IS NULL THEN RAISE EXCEPTION 'Authentication required'; END IF;
  IF p_difficulty < 0 OR p_difficulty > 4 OR p_question_count < 1 OR p_question_count > 100 OR p_correct_count < 0 OR p_correct_count > p_question_count OR p_best_streak < 0 OR p_best_streak > p_question_count OR p_score < 0 OR p_score > p_question_count * 1250 THEN
    RAISE EXCEPTION 'Invalid run';
  END IF;
  IF p_challenge_date IS NOT NULL AND p_challenge_date <> (now() AT TIME ZONE 'utc')::date THEN
    RAISE EXCEPTION 'Invalid daily challenge date';
  END IF;
  v_reward := CASE p_difficulty WHEN 0 THEN 0.5 WHEN 1 THEN 0.8 WHEN 2 THEN 1.0 WHEN 3 THEN 1.6 ELSE 2.5 END;
  v_xp := LEAST(2500, round((p_score / 12.0) * v_reward));

  INSERT INTO public.arena_runs (user_id, challenge_date, score, xp_earned, difficulty, question_count, correct_count, best_streak, eliminated, category_ids)
  VALUES (v_user, p_challenge_date, p_score, v_xp, p_difficulty, p_question_count, p_correct_count, p_best_streak, p_eliminated, COALESCE(p_category_ids, '{}'));

  INSERT INTO public.player_progress (user_id, arena_xp, runs, best_score, daily_streak, last_daily_date)
  VALUES (v_user, v_xp, 1, p_score,
    CASE WHEN p_challenge_date IS NOT NULL THEN 1 ELSE 0 END,
    p_challenge_date)
  ON CONFLICT (user_id) DO UPDATE SET
    arena_xp = player_progress.arena_xp + v_xp,
    runs = player_progress.runs + 1,
    best_score = GREATEST(player_progress.best_score, p_score),
    daily_streak = CASE
      WHEN p_challenge_date IS NULL THEN player_progress.daily_streak
      WHEN player_progress.last_daily_date = p_challenge_date THEN player_progress.daily_streak
      WHEN player_progress.last_daily_date = p_challenge_date - 1 THEN player_progress.daily_streak + 1
      ELSE 1
    END,
    last_daily_date = COALESCE(p_challenge_date, player_progress.last_daily_date),
    updated_at = now();

  IF p_score > 0 THEN
    INSERT INTO public.badge_unlocks VALUES (v_user, 'first_run', now()) ON CONFLICT DO NOTHING;
  END IF;
  IF p_best_streak >= 10 THEN
    INSERT INTO public.badge_unlocks VALUES (v_user, 'streak_10', now()) ON CONFLICT DO NOTHING;
  END IF;
  IF p_correct_count = p_question_count AND p_question_count >= 5 THEN
    INSERT INTO public.badge_unlocks VALUES (v_user, 'perfect_run', now()) ON CONFLICT DO NOTHING;
  END IF;
  IF p_challenge_date IS NOT NULL THEN
    INSERT INTO public.badge_unlocks VALUES (v_user, 'daily_first', now()) ON CONFLICT DO NOTHING;
  END IF;

  SELECT COALESCE(array_agg(badge_id), '{}') INTO v_badges FROM public.badge_unlocks WHERE user_id = v_user;
  RETURN QUERY SELECT pp.arena_xp, pp.runs, pp.best_score, pp.daily_streak, v_xp, v_badges FROM public.player_progress pp WHERE pp.user_id = v_user;
END;
$$;
REVOKE ALL ON FUNCTION public.submit_arena_run(integer, smallint, integer, integer, integer, boolean, text[], date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.submit_arena_run(integer, smallint, integer, integer, integer, boolean, text[], date) TO authenticated;

CREATE OR REPLACE FUNCTION public.get_arena_leaderboard(p_limit integer DEFAULT 10)
RETURNS TABLE (rank bigint, display_name text, arena_xp integer, best_score integer, is_current_user boolean)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  WITH ranked AS (
    SELECT row_number() OVER (ORDER BY pp.arena_xp DESC, pp.best_score DESC, pp.updated_at ASC) AS place,
      left(COALESCE(NULLIF(trim(p.display_name), ''), 'Membre Shapr'), 32) AS member_name,
      pp.arena_xp AS points,
      pp.best_score AS record,
      pp.user_id
    FROM public.player_progress pp
    JOIN public.profiles p ON p.id = pp.user_id
    WHERE pp.show_on_leaderboard
  )
  SELECT place, member_name, points, record, user_id = auth.uid()
  FROM ranked
  WHERE place <= LEAST(GREATEST(p_limit, 3), 50) OR user_id = auth.uid()
  ORDER BY place;
$$;
REVOKE ALL ON FUNCTION public.get_arena_leaderboard(integer) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_arena_leaderboard(integer) TO authenticated;