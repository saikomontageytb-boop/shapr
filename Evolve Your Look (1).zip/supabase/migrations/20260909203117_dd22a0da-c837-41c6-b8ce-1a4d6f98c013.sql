ALTER TABLE public.player_progress
  ADD COLUMN IF NOT EXISTS daily_xp integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS daily_period text NOT NULL DEFAULT to_char((now() AT TIME ZONE 'utc')::date, 'YYYY-MM'),
  ADD COLUMN IF NOT EXISTS account_xp integer NOT NULL DEFAULT 0;

GRANT UPDATE (show_on_leaderboard, account_xp) ON public.player_progress TO authenticated;

CREATE OR REPLACE FUNCTION public.submit_arena_run_internal(p_user_id uuid, p_score integer, p_difficulty smallint, p_question_count integer, p_correct_count integer, p_best_streak integer, p_eliminated boolean, p_category_ids text[] DEFAULT '{}'::text[], p_challenge_date date DEFAULT NULL::date)
 RETURNS TABLE(arena_xp integer, runs integer, best_score integer, daily_streak integer, xp_earned integer, new_badges text[])
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_reward numeric;
  v_xp integer;
  v_badges text[] := '{}';
  v_period text := to_char((now() AT TIME ZONE 'utc')::date, 'YYYY-MM');
BEGIN
  IF p_user_id IS NULL OR NOT EXISTS (SELECT 1 FROM auth.users WHERE id = p_user_id) THEN RAISE EXCEPTION 'Invalid member'; END IF;
  IF p_difficulty < 0 OR p_difficulty > 4 OR p_question_count < 1 OR p_question_count > 100 OR p_correct_count < 0 OR p_correct_count > p_question_count OR p_best_streak < 0 OR p_best_streak > p_question_count OR p_score < 0 OR p_score > p_question_count * 1250 THEN RAISE EXCEPTION 'Invalid run'; END IF;
  IF p_challenge_date IS NOT NULL AND p_challenge_date <> (now() AT TIME ZONE 'utc')::date THEN RAISE EXCEPTION 'Invalid daily challenge date'; END IF;
  IF p_challenge_date IS NOT NULL AND EXISTS (SELECT 1 FROM public.arena_runs WHERE user_id = p_user_id AND challenge_date = p_challenge_date) THEN
    RAISE EXCEPTION 'Daily challenge already played';
  END IF;

  v_reward := CASE p_difficulty WHEN 0 THEN 0.5 WHEN 1 THEN 0.8 WHEN 2 THEN 1.0 WHEN 3 THEN 1.6 ELSE 2.5 END;
  v_xp := LEAST(2500, round((p_score / 12.0) * v_reward));

  INSERT INTO public.arena_runs (user_id, challenge_date, score, xp_earned, difficulty, question_count, correct_count, best_streak, eliminated, category_ids)
  VALUES (p_user_id, p_challenge_date, p_score, v_xp, p_difficulty, p_question_count, p_correct_count, p_best_streak, p_eliminated, COALESCE(p_category_ids, '{}'));

  INSERT INTO public.player_progress (user_id, arena_xp, runs, best_score, daily_streak, last_daily_date, daily_xp, daily_period)
  VALUES (p_user_id, v_xp, 1, p_score, CASE WHEN p_challenge_date IS NOT NULL THEN 1 ELSE 0 END, p_challenge_date, CASE WHEN p_challenge_date IS NOT NULL THEN v_xp ELSE 0 END, v_period)
  ON CONFLICT (user_id) DO UPDATE SET
    arena_xp = player_progress.arena_xp + v_xp,
    runs = player_progress.runs + 1,
    best_score = GREATEST(player_progress.best_score, p_score),
    daily_streak = CASE WHEN p_challenge_date IS NULL THEN player_progress.daily_streak WHEN player_progress.last_daily_date = p_challenge_date THEN player_progress.daily_streak WHEN player_progress.last_daily_date = p_challenge_date - 1 THEN player_progress.daily_streak + 1 ELSE 1 END,
    last_daily_date = COALESCE(p_challenge_date, player_progress.last_daily_date),
    daily_xp = CASE
      WHEN player_progress.daily_period <> v_period THEN (CASE WHEN p_challenge_date IS NOT NULL THEN v_xp ELSE 0 END)
      ELSE player_progress.daily_xp + (CASE WHEN p_challenge_date IS NOT NULL THEN v_xp ELSE 0 END)
    END,
    daily_period = v_period,
    updated_at = now();

  IF p_score > 0 THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'first_run', now()) ON CONFLICT DO NOTHING; END IF;
  IF p_best_streak >= 10 THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'streak_10', now()) ON CONFLICT DO NOTHING; END IF;
  IF p_correct_count = p_question_count AND p_question_count >= 5 THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'perfect_run', now()) ON CONFLICT DO NOTHING; END IF;
  IF p_challenge_date IS NOT NULL THEN INSERT INTO public.badge_unlocks VALUES (p_user_id, 'daily_first', now()) ON CONFLICT DO NOTHING; END IF;
  SELECT COALESCE(array_agg(badge_id ORDER BY unlocked_at), '{}') INTO v_badges FROM public.badge_unlocks WHERE user_id = p_user_id;
  RETURN QUERY SELECT pp.arena_xp, pp.runs, pp.best_score, pp.daily_streak, v_xp, v_badges FROM public.player_progress pp WHERE pp.user_id = p_user_id;
END;
$function$;

REVOKE ALL ON FUNCTION public.submit_arena_run_internal(uuid, integer, smallint, integer, integer, integer, boolean, text[], date) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.submit_arena_run_internal(uuid, integer, smallint, integer, integer, integer, boolean, text[], date) TO service_role;

DROP FUNCTION IF EXISTS public.get_arena_leaderboard(integer);
CREATE OR REPLACE FUNCTION public.get_arena_leaderboard(p_limit integer DEFAULT 25)
 RETURNS TABLE(rank bigint, display_name text, arena_xp integer, daily_xp integer, account_xp integer, total_xp integer, best_score integer, is_current_user boolean)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  WITH ranked AS (
    SELECT row_number() OVER (ORDER BY (pp.arena_xp + pp.account_xp) DESC, pp.best_score DESC, pp.updated_at ASC) AS place,
      left(COALESCE(NULLIF(trim(p.display_name), ''), 'Membre Shapr'), 32) AS member_name,
      pp.arena_xp AS points,
      CASE WHEN pp.daily_period = to_char((now() AT TIME ZONE 'utc')::date, 'YYYY-MM') THEN pp.daily_xp ELSE 0 END AS month_points,
      pp.account_xp AS account_points,
      (pp.arena_xp + pp.account_xp) AS total_points,
      pp.best_score AS record,
      pp.user_id
    FROM public.player_progress pp
    JOIN public.profiles p ON p.id = pp.user_id
    WHERE pp.show_on_leaderboard
  )
  SELECT place, member_name, points, month_points, account_points, total_points, record, user_id = auth.uid()
  FROM ranked
  WHERE place <= LEAST(GREATEST(p_limit, 3), 100) OR user_id = auth.uid()
  ORDER BY place;
$function$;

REVOKE ALL ON FUNCTION public.get_arena_leaderboard(integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.get_arena_leaderboard(integer) TO service_role;