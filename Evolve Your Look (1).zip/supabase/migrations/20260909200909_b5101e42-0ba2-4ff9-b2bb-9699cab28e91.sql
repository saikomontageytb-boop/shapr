REVOKE EXECUTE ON FUNCTION public.submit_arena_run(integer, smallint, integer, integer, integer, boolean, text[], date) FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.get_arena_leaderboard(integer) FROM authenticated;
REVOKE UPDATE ON public.player_progress FROM authenticated;
GRANT UPDATE (show_on_leaderboard) ON public.player_progress TO authenticated;