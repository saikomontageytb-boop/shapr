# Hub de progression Shapr

## Résultat attendu
Transformer l’Arène et le tableau de bord en un parcours unique, clair et motivant : progression globale, défi du jour, badges graphiques et classement membres.

## Parcours
- Faire du tableau de bord le centre de progression : niveau global, XP, série, prochain objectif et raccourci prioritaire vers le défi du jour.
- Ajouter dans l’Arène un défi quotidien fixe de cinq questions, identique pour tous, avec une seule tentative par jour et une série de jours.
- Enregistrer chaque partie connectée et répercuter immédiatement son XP sur la progression du compte.
- Afficher un récapitulatif de fin de partie avec gain d’XP, changement de niveau, série quotidienne et nouveaux badges.
- Ajouter un aperçu du classement sur le tableau de bord et une vue complète simple, avec possibilité de ne pas apparaître.

## Direction visuelle
- Reprendre fidèlement la structure « Gamified progression hub » sélectionnée.
- Conserver la palette graphite électrique : fond clair `#F7F7F5`, graphite `#202124`, violet `#705CF6`, lime `#C8FF4A`.
- Utiliser Outfit pour les titres et Figtree pour le texte.
- Remplacer les récompenses textuelles par des badges SVG originaux, avec niveaux bronze, argent et or.
- Employer des transitions courtes, une mascotte expressive et des retours visuels nets, sans emoji ni effets décoratifs génériques.
- Adapter la densité et les mouvements au mobile, avec réduction des animations selon les préférences système.

## Détails techniques
- La progression Arène, les parties, les tentatives quotidiennes et les badges sont persistés dans Lovable Cloud.
- Les résultats sont contrôlés côté serveur avant attribution d’XP ; le navigateur ne peut pas modifier directement les totaux.
- Le défi quotidien utilise une sélection déterministe basée sur la date UTC.
- Le classement n’expose que le nom d’affichage, les points et le record des membres ayant choisi d’y figurer.
- Les anciennes données locales restent lisibles comme historique visuel, sans pouvoir alimenter le classement officiel.

## Validation
- Vérifier les parties normales et quotidiennes, la seconde tentative bloquée, les badges et le classement.
- Vérifier les états connecté et déconnecté.
- Contrôler l’affichage sur ordinateur et mobile, ainsi que l’absence d’erreurs visibles.
