import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, CalendarDays, Medal, Settings, Sparkles, Swords, Trophy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getLeaderboard, type LeaderboardEntry } from "@/lib/arena.functions";
import { useAuth } from "@/lib/auth";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/leaderboard")({
  head: ({ params }) => {
    const fr = (isLang(params.lang) ? params.lang : DEFAULT_LANG) === "fr";
    const title = fr ? "Classement Shapr — points, défis et défi du jour" : "Shapr leaderboard — points, arena and daily";
    const description = fr
      ? "Compare les points de compte, les points du mode défis et les points du défi du jour, remis à zéro chaque mois."
      : "Compare account points, arena points and daily-challenge points, reset every month.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: LeaderboardPage,
});

type Board = "total" | "arena" | "daily";

function LeaderboardPage() {
  const { lang } = useT();
  const fr = lang === "fr";
  const { user } = useAuth();
  const load = useServerFn(getLeaderboard);
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [board, setBoard] = useState<Board>("total");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }
    void load()
      .then(setEntries)
      .catch(() => setEntries([]))
      .finally(() => setLoading(false));
  }, [load, user]);

  const value = (entry: LeaderboardEntry) =>
    board === "arena" ? entry.arenaXp : board === "daily" ? entry.dailyXp : entry.totalXp;

  const ranked = [...entries]
    .sort((a, b) => value(b) - value(a) || b.bestScore - a.bestScore)
    .map((entry, index) => ({ entry, place: index + 1 }));

  const tabs: { id: Board; label: string; icon: typeof Trophy; hint: string }[] = [
    { id: "total", label: fr ? "Compte" : "Account", icon: Sparkles, hint: fr ? "Leçons, scan et arène cumulés" : "Lessons, scan and arena combined" },
    { id: "arena", label: fr ? "Défis" : "Arena", icon: Swords, hint: fr ? "Points gagnés en mode défis" : "Points earned in arena runs" },
    { id: "daily", label: fr ? "Défi du jour" : "Daily", icon: CalendarDays, hint: fr ? "Points des 5 questions, remis à zéro chaque mois" : "5-question points, reset every month" },
  ];

  const active = tabs.find((tab) => tab.id === board)!;

  return (
    <main className="mx-auto min-h-[calc(100dvh-4rem)] max-w-4xl px-4 py-8 sm:px-6 sm:py-14">
      <Button asChild variant="ghost" className="-ml-3">
        <Link to="/$lang/dashboard" params={{ lang }}>
          <ArrowLeft />
          {fr ? "Tableau de bord" : "Dashboard"}
        </Link>
      </Button>

      <header className="mt-8 flex flex-col gap-5 border-b border-border pb-7 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="label-mono text-primary">Shapr</p>
          <h1 className="mt-2 font-display text-4xl sm:text-6xl">{fr ? "Classement" : "Leaderboard"}</h1>
          <p className="mt-3 max-w-xl text-muted-foreground">{active.hint}</p>
        </div>
        <div className="grid h-16 w-16 shrink-0 place-items-center rounded-md bg-highlight text-foreground">
          <Trophy className="h-7 w-7" />
        </div>
      </header>

      <div className="mt-6 grid grid-cols-3 gap-2">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setBoard(tab.id)}
            aria-pressed={board === tab.id}
            className={`flex items-center justify-center gap-2 rounded-md px-3 py-3 text-sm font-medium transition-colors ${
              board === tab.id ? "bg-primary text-primary-foreground" : "bg-surface-2 text-muted-foreground hover:text-foreground"
            }`}
          >
            <tab.icon className="h-4 w-4 shrink-0" />
            <span className="truncate">{tab.label}</span>
          </button>
        ))}
      </div>

      <section className="panel mt-5 overflow-hidden">
        <div className="label-mono grid grid-cols-[2.5rem_1fr_5rem] gap-2 border-b border-border px-4 py-3 sm:grid-cols-[2.5rem_1fr_5rem_5rem_5rem]">
          <span>#</span>
          <span>{fr ? "Membre" : "Member"}</span>
          <span className="text-right sm:text-left">{fr ? "Compte" : "Account"}</span>
          <span className="hidden text-left sm:block">{fr ? "Défis" : "Arena"}</span>
          <span className="hidden text-left sm:block">{fr ? "Jour" : "Daily"}</span>
        </div>

        {ranked.map(({ entry, place }) => (
          <div
            key={`${entry.displayName}-${entry.rank}`}
            className={`grid grid-cols-[2.5rem_1fr_5rem] items-center gap-2 border-b border-border px-4 py-4 last:border-0 sm:grid-cols-[2.5rem_1fr_5rem_5rem_5rem] ${
              entry.current ? "bg-primary/10" : ""
            }`}
          >
            <span className="font-display text-lg">
              {place <= 3 ? <Medal className={`h-5 w-5 ${place === 1 ? "text-warning" : "text-chart-2"}`} /> : place}
            </span>
            <div className="min-w-0">
              <p className="truncate font-semibold">
                {entry.displayName}
                {entry.current && <span className="ml-2 text-xs text-primary">{fr ? "Toi" : "You"}</span>}
              </p>
              <p className="text-xs text-muted-foreground sm:hidden">
                {fr ? "Défis" : "Arena"} {entry.arenaXp} · {fr ? "Jour" : "Daily"} {entry.dailyXp}
              </p>
            </div>
            <strong className={`text-right tabular-nums sm:text-left ${board === "total" ? "text-primary" : ""}`}>
              {entry.totalXp.toLocaleString(lang)}
            </strong>
            <span className={`hidden tabular-nums sm:block ${board === "arena" ? "font-bold text-primary" : "text-muted-foreground"}`}>
              {entry.arenaXp.toLocaleString(lang)}
            </span>
            <span className={`hidden tabular-nums sm:block ${board === "daily" ? "font-bold text-primary" : "text-muted-foreground"}`}>
              {entry.dailyXp.toLocaleString(lang)}
            </span>
          </div>
        ))}

        {ranked.length === 0 && (
          <p className="px-4 py-10 text-center text-sm text-muted-foreground">
            {loading
              ? fr
                ? "Chargement…"
                : "Loading…"
              : user
                ? fr
                  ? "Le classement démarre avec les premières parties."
                  : "The leaderboard starts with the first runs."
                : fr
                  ? "Connecte-toi pour voir le classement."
                  : "Sign in to see the leaderboard."}
          </p>
        )}
      </section>

      <p className="mt-4 text-xs text-muted-foreground">
        {fr
          ? "Les points du défi du jour sont remis à zéro le 1er de chaque mois."
          : "Daily-challenge points reset on the 1st of every month."}
      </p>

      {user && (
        <Button asChild variant="ghost" className="mt-4">
          <Link to="/$lang/settings" params={{ lang }}>
            <Settings />
            {fr ? "Changer mon pseudo" : "Change my username"}
          </Link>
        </Button>
      )}
    </main>
  );
}
