import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ChevronRight, Flame } from "lucide-react";
import { ArenaIcon } from "@/components/site/ArenaIcon";

import wolf from "@/assets/wolf-hero.png";
import { TrackArt } from "@/components/academy/TrackArt";
import { LockBadge } from "@/components/academy/LockBadge";
import { useAcademy, lessonKey, CATEGORIES, tracksInCategory } from "@/lib/academy";
import { useAcademyCopy } from "@/lib/academy-copy";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useLessonAccess, FREE_LESSON_COUNT } from "@/lib/lesson-access";
import { levelInfo, levelTitle } from "@/lib/levels";
import { academyXp } from "@/lib/progress";
import { useAccount } from "@/lib/account";
import { useT } from "@/lib/use-lang";
import type { Track } from "@/lib/academy-types";

export const Route = createFileRoute("/$lang/academy/")({
  head: ({ params }) => {
    const lang = isLang(params.lang) ? params.lang : DEFAULT_LANG;
    const title =
      lang === "fr"
        ? "Parcours Shapr — une leçon par jour"
        : "Shapr path — one lesson a day";
    const description =
      lang === "fr"
        ? "Des grandes catégories et leurs sous-modules : musculature, nutrition, visage, cheveux, style, énergie et présence. Une leçon à la fois."
        : "Big categories and their sub-modules: muscle, nutrition, face, hair, style, energy and presence. One lesson at a time.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: AcademyIndex,
});

function AcademyIndex() {
  const { lang } = useT();
  const c = useAcademyCopy();
  const tracks = useAcademy();
  const { academy } = useAccount();
  const access = useLessonAccess();
  const done = academy.completedLessons;
  const xp = academyXp(academy);

  const info = levelInfo(xp);
  const fr = lang === "fr";
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const category = CATEGORIES.find((cat) => cat.id === categoryId) ?? null;
  const visibleTracks = category ? tracksInCategory(lang, category.id) : [];

  const TrackRow = ({ track }: { track: Track }) => {
    const completed = track.lessons.filter((l) =>
      done.includes(lessonKey(track.id, l.id)),
    ).length;
    const pct = Math.round((completed / track.lessons.length) * 100);
    const openable = track.lessons.filter((l) =>
      access.canOpen(lessonKey(track.id, l.id)),
    ).length;
    const moduleLocked = openable === 0;

    return (
      <Link
        to="/$lang/academy/$track"
        params={{ lang, track: track.id }}
        className="panel group flex items-center gap-4 overflow-hidden p-3 transition-colors hover:bg-surface-2/60"
      >
        <TrackArt trackId={track.id} alt="" className="h-16 w-20 shrink-0" rounded="rounded-xl" />
        <span className="min-w-0 flex-1">
          <span className="truncate block font-semibold">{track.title}</span>
          <span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-surface-2">
            <span
              className="block h-full rounded-full bg-primary transition-[width] duration-700"
              style={{ width: `${pct}%` }}
            />
          </span>
          <span className="label-mono mt-1.5 flex items-center gap-1.5">
            {completed}/{track.lessons.length} {c.lessons}
            {moduleLocked && (
              <span className="flex items-center gap-1 rounded-full bg-surface-2 px-2 py-0.5 text-[10px]">
                <LockBadge className="h-3 w-3" />
                {c.pro}
              </span>
            )}
          </span>
        </span>
        <ChevronRight className="h-5 w-5 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1" />
      </Link>
    );
  };

  return (
    <main className="mx-auto max-w-xl px-5 pb-20 pt-8">
      {/* Level card with the mascot */}
      <div className="panel flex items-center gap-4 p-5">
        <img src={wolf} alt="" width={1024} height={1024} className="h-20 w-auto shrink-0" />
        <div className="min-w-0 flex-1">
          <p className="label-mono">
            {c.level} {info.level} · {levelTitle(lang, info.level)}
          </p>
          <div className="mt-2 h-2.5 overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-700"
              style={{ width: `${info.progress}%` }}
            />
          </div>
          <p className="mt-2 flex items-center gap-1.5 text-sm font-semibold">
            <Flame className="h-4 w-4 text-primary" />
            {xp} XP
            {!info.max && (
              <span className="font-normal text-muted-foreground">
                · {info.toNext} {fr ? "avant le niveau" : "to level"} {info.level + 1}
              </span>
            )}
          </p>
        </div>
      </div>

      <Link
        to="/$lang/arena"
        params={{ lang }}
        
        className="panel group mt-4 flex items-center gap-4 overflow-hidden p-5 transition-colors hover:bg-surface-2/60"
      >
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-primary/15 text-primary transition-transform group-hover:scale-105">
          <ArenaIcon className="h-7 w-7" />
        </span>

        <span className="min-w-0 flex-1">
          <span className="block font-semibold">{fr ? "Arène" : "Arena"}</span>
          <span className="mt-0.5 block text-sm text-muted-foreground">
            {fr
              ? "Quiz sans fin sur les thèmes que tu as travaillés."
              : "Endless quiz on the themes you worked on."}
          </span>
        </span>
        <ChevronRight className="h-5 w-5 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1" />
      </Link>

      {!access.pro && (
        <div className="panel mt-4 flex flex-wrap items-center justify-between gap-3 p-5">
          <p className="flex items-start gap-2 text-sm text-muted-foreground">
            <LockBadge className="mt-0.5 h-4 w-4 shrink-0" />
            {fr
              ? `${FREE_LESSON_COUNT} leçons sont offertes à tout le monde. Tout le reste est dans l'abonnement.`
              : `${FREE_LESSON_COUNT} lessons are free for everyone. Everything else comes with the subscription.`}
          </p>
          <Link
            to="/$lang/pro"
            params={{ lang }}
            className="rounded-full bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            {fr ? "Voir l'abonnement" : "See the subscription"}
          </Link>
        </div>
      )}

      {category ? (
        <>
          <button
            type="button"
            onClick={() => setCategoryId(null)}
            className="mt-8 flex items-center gap-2 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            {fr ? "Toutes les catégories" : "All categories"}
          </button>
          <div className="mt-4 flex items-baseline justify-between gap-3">
            <h1 className="text-2xl font-bold">
              {fr ? category.fr : category.en}
            </h1>
            <span className="label-mono shrink-0">
              {visibleTracks.filter((t) =>
                t.lessons.every((l) => done.includes(lessonKey(t.id, l.id))),
              ).length}
              /{visibleTracks.length} {fr ? "MODULES" : "MODULES"}
            </span>
          </div>
          <div className="mt-6 space-y-3">
            {visibleTracks.map((track) => (
              <TrackRow key={track.id} track={track} />
            ))}
          </div>
        </>
      ) : (
        <>
          <div className="mt-8 flex items-baseline justify-between gap-3">
            <h1 className="text-2xl font-bold">
              {fr ? "Choisis une catégorie" : "Pick a category"}
            </h1>
            <span className="label-mono shrink-0">
              {tracks.filter((t) =>
                t.lessons.every((l) => done.includes(lessonKey(t.id, l.id))),
              ).length}
              /{tracks.length} {fr ? "MODULES" : "MODULES"}
            </span>
          </div>
          <div className="mt-6 space-y-3">
            {CATEGORIES.map((cat) => {
              const catTracks = tracksInCategory(lang, cat.id);
              const lessons = catTracks.reduce((n, t) => n + t.lessons.length, 0);
              const completed = catTracks.reduce(
                (n, t) =>
                  n + t.lessons.filter((l) => done.includes(lessonKey(t.id, l.id))).length,
                0,
              );
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategoryId(cat.id)}
                  className="panel group flex w-full items-center gap-4 overflow-hidden p-3 text-left transition-colors hover:bg-surface-2/60"
                >
                  <TrackArt trackId={cat.trackIds[0]!} alt="" className="h-16 w-20 shrink-0" rounded="rounded-xl" />
                  <span className="min-w-0 flex-1">
                    <span className="truncate block font-semibold">
                      {fr ? cat.fr : cat.en}
                    </span>
                    <span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-surface-2">
                      <span
                        className="block h-full rounded-full bg-primary transition-[width] duration-700"
                        style={{ width: `${lessons ? Math.round((completed / lessons) * 100) : 0}%` }}
                      />
                    </span>
                    <span className="label-mono mt-1.5 block">
                      {catTracks.length} {fr ? "modules" : "modules"} · {completed}/{lessons} {c.lessons}
                    </span>
                  </span>
                  <ChevronRight className="h-5 w-5 shrink-0 text-muted-foreground transition-transform group-hover:translate-x-1" />
                </button>
              );
            })}
          </div>
        </>
      )}
    </main>
  );
}
