import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { CalendarDays, Check, Flame, Play, Timer, Trophy, Users } from "lucide-react";
import wolf from "@/assets/wolf-hero.png";
import { Aurora, Over, Run, type OverProps } from "@/components/arena/game";
import { Button } from "@/components/ui/button";
import { useAccount } from "@/lib/account";
import { useAuth } from "@/lib/auth";
import { submitArenaRun } from "@/lib/arena.functions";
import {
  ARENA_COPY,
  addProgress,
  difficultyOf,
  loadProgress,
  xpForRun,
  type ArenaCopy,
} from "@/lib/arena";
import { dailyQuestions, DAILY_DIFFICULTY, DAILY_QUESTION_COUNT, utcDay } from "@/lib/daily-challenge";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/daily")({
  head: ({ params }) => {
    const fr = (isLang(params.lang) ? params.lang : DEFAULT_LANG) === "fr";
    const title = fr ? "Défi du jour — Shapr" : "Daily challenge — Shapr";
    const description = fr
      ? "5 questions, les mêmes pour tout le monde, une seule tentative par jour. Garde ta série et grimpe au classement du mois."
      : "5 questions, the same for everyone, one attempt a day. Keep your streak and climb this month's leaderboard.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: DailyPage,
});

const CONFIG = { categoryIds: [] as string[], difficulty: DAILY_DIFFICULTY, questionCount: DAILY_QUESTION_COUNT };

/** Whole hours left before the challenge is renewed (midnight UTC). */
function hoursToReset(): number {
  const now = new Date();
  const next = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1);
  return Math.max(1, Math.ceil((next - now.getTime()) / 3_600_000));
}

function DailyPage() {
  const { lang } = useT();
  const fr = lang === "fr";
  const { user } = useAuth();
  const { arena, refreshArena } = useAccount();
  const saveRun = useServerFn(submitArenaRun);
  const c = ARENA_COPY[lang] as ArenaCopy;
  const difficulty = difficultyOf(CONFIG);

  const [phase, setPhase] = useState<"intro" | "play" | "over">("intro");
  const [result, setResult] = useState<(OverProps & { xpBefore: number; xpGain: number }) | null>(null);
  const pool = useMemo(() => dailyQuestions(lang), [lang]);
  const done = arena.lastDailyDate === utcDay();

  // Someone who finishes the run lands back on the locked screen next visit.
  useEffect(() => {
    if (done && phase === "intro") setResult(null);
  }, [done, phase]);

  return (
    <main className="relative min-h-[calc(100dvh-4rem)] overflow-hidden px-4 pb-24 pt-6 sm:px-5 sm:pt-8">
      <Aurora />
      <div className="relative mx-auto w-full max-w-xl">
        {phase === "intro" && (
          <div className="animate-rise space-y-4 sm:space-y-5">
            <header className={`panel overflow-hidden ${done ? "" : "border-primary/30"}`}>
              <div className={`flex items-start gap-4 p-5 sm:p-6 ${done ? "bg-surface-2" : "bg-foreground text-background"}`}>
                <img src={wolf} alt="" width={1024} height={1024} className="animate-float h-20 w-auto shrink-0 sm:h-24" />
                <div className="min-w-0">
                  <p className={`label-mono flex items-center gap-1.5 ${done ? "text-primary" : "text-highlight"}`}>
                    {done ? <Check className="h-4 w-4" /> : <CalendarDays className="h-4 w-4" />}
                    {fr ? "Défi du jour" : "Daily challenge"}
                  </p>
                  <h1 className="mt-1 font-display text-2xl leading-tight sm:text-3xl">
                    {done
                      ? fr ? "Déjà relevé aujourd’hui" : "Already done today"
                      : fr ? "5 questions. Une tentative." : "5 questions. One attempt."}
                  </h1>
                  <p className={`mt-2 text-sm ${done ? "text-muted-foreground" : "text-background/65"}`}>
                    {done
                      ? fr
                        ? `5 nouvelles questions dans ${hoursToReset()} h. Reviens demain pour garder ta série.`
                        : `5 new questions in ${hoursToReset()} h. Come back tomorrow to keep your streak.`
                      : fr
                        ? "Les mêmes 5 questions pour toute la communauté, renouvelées chaque jour à minuit UTC."
                        : "The same 5 questions for everyone, renewed every day at midnight UTC."}
                  </p>
                </div>
              </div>
            </header>

            <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
              {[
                { icon: Flame, value: `${arena.dailyStreak}`, label: fr ? "Jours d’affilée" : "Day streak" },
                { icon: Trophy, value: `${arena.dailyXp}`, label: fr ? "Points du mois" : "Points this month" },
                { icon: Timer, value: `${difficulty.seconds}s`, label: fr ? "Par question" : "Per question" },
              ].map((s) => (
                <div key={s.label} className="panel p-3 text-center sm:p-4">
                  <s.icon className="mx-auto h-4 w-4 text-primary" />
                  <p className="mt-1.5 font-display text-xl sm:text-2xl">{s.value}</p>
                  <p className="label-mono mt-1 leading-tight">{s.label}</p>
                </div>
              ))}
            </div>

            <section className="panel p-5">
              <p className="label-mono">{fr ? "Les règles" : "The rules"}</p>
              <ul className="mt-3 space-y-2.5 text-sm text-muted-foreground">
                {[
                  fr ? "5 questions, tirées au sort pour la journée entière." : "5 questions, drawn for the whole day.",
                  fr ? "Difficulté imposée : 4 réponses, 8 secondes, gain ×1,6." : "Fixed difficulty: 4 answers, 8 seconds, ×1.6 reward.",
                  fr ? "Une seule tentative : pas de deuxième essai." : "One attempt only: no retry.",
                  fr ? "Les points du défi repartent de zéro chaque 1er du mois." : "Challenge points reset on the 1st of each month.",
                ].map((line) => (
                  <li key={line} className="flex gap-2.5">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                    <span>{line}</span>
                  </li>
                ))}
              </ul>
            </section>

            {done ? (
              <div className="panel flex items-center gap-3 p-4 text-sm">
                <Check className="h-5 w-5 shrink-0 text-primary" />
                <span className="flex-1">{fr ? "Ton défi est validé pour aujourd’hui." : "Your challenge is done for today."}</span>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setPhase("play")}
                className="btn-chunky flex w-full items-center justify-center gap-2 bg-primary px-6 py-4 text-lg font-semibold text-primary-foreground transition-all hover:brightness-110"
              >
                <Play className="h-5 w-5" />
                {fr ? "Lancer le défi" : "Start the challenge"}
              </button>
            )}

            {!user && !done && (
              <p className="text-center text-xs text-muted-foreground">
                {fr ? "Connecte-toi pour que ton résultat compte au classement." : "Sign in so your result counts on the leaderboard."}
              </p>
            )}

            <div className="grid gap-2.5 sm:grid-cols-2">
              <Button asChild variant="outline">
                <Link to="/$lang/leaderboard" params={{ lang }}>
                  <Users />
                  {fr ? "Voir le classement" : "See the leaderboard"}
                </Link>
              </Button>
              <Button asChild variant="ghost">
                <Link to="/$lang/arena" params={{ lang }}>
                  {fr ? "Jouer en Arène libre" : "Play free Arena"}
                </Link>
              </Button>
            </div>
          </div>
        )}

        {phase === "play" && (
          <Run
            c={c}
            config={CONFIG}
            difficulty={difficulty}
            pool={pool}
            onQuit={() => setPhase("intro")}
            onOver={(props) => {
              const beforeXp = user ? arena.arenaXp : loadProgress().xp;
              const finalize = async () => {
                let xpGain = xpForRun(props.score, difficulty.reward);
                if (user) {
                  try {
                    const saved = await saveRun({
                      data: {
                        score: props.score,
                        difficulty: CONFIG.difficulty,
                        questionCount: props.answers.length,
                        correctCount: props.answers.filter((a) => a.correct).length,
                        bestStreak: props.bestStreak,
                        eliminated: props.eliminated,
                        categoryIds: [],
                        challengeDate: utcDay(),
                      },
                    });
                    xpGain = saved.xpEarned;
                    await refreshArena();
                  } catch {
                    xpGain = 0;
                  }
                } else {
                  addProgress(xpGain);
                }
                setResult({ ...props, xpBefore: beforeXp, xpGain });
                setPhase("over");
              };
              void finalize();
            }}
          />
        )}

        {phase === "over" && result && (
          <Over
            {...result}
            c={c}
            lang={lang}
            best={arena.bestScore}
            onSetup={() => {
              setResult(null);
              setPhase("intro");
            }}
            setupLabel={fr ? "Revenir au défi du jour" : "Back to the daily challenge"}
          />
        )}
      </div>
    </main>
  );
}
