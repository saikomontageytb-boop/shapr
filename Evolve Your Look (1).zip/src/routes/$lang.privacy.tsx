import { createFileRoute, Link } from "@tanstack/react-router";
import { Trash2, ShieldCheck, EyeOff, Timer } from "lucide-react";
import { dict, isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/privacy")({
  head: ({ params }) => {
    const t = dict(isLang(params.lang) ? params.lang : DEFAULT_LANG);
    const title = `${t.privacy.title} | Shapr`;
    return {
      meta: [
        { title },
        { name: "description", content: t.privacy.intro },
        { property: "og:title", content: title },
        { property: "og:description", content: t.privacy.intro },
      ],
    };
  },
  component: PrivacyPage,
});

const ICONS = [Timer, Trash2, EyeOff, ShieldCheck];

function PrivacyPage() {
  const { lang, t } = useT();

  return (
    <main className="mx-auto max-w-3xl px-5 py-20">
      <p className="label-mono">{t.privacy.label}</p>
      <h1 className="mt-3 font-display text-4xl sm:text-5xl">{t.privacy.title}</h1>
      <p className="mt-4 text-lg text-muted-foreground">{t.privacy.pageLead}</p>

      <div className="mt-10 space-y-4">
        {t.privacy.points.map((p, i) => {
          const Icon = ICONS[i] ?? ShieldCheck;
          return (
            <section key={p.title} className="panel p-6">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/12">
                  <Icon className="h-4 w-4 text-primary" />
                </span>
                <h2 className="text-lg font-semibold">{p.title}</h2>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{p.body}</p>
            </section>
          );
        })}
      </div>

      <section className="panel mt-8 p-6">
        <h2 className="text-lg font-semibold">{t.privacy.checksTitle}</h2>
        <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
          {t.privacy.checks.map((c) => (
            <li key={c}>• {c}</li>
          ))}
        </ul>
      </section>

      <div className="mt-10">
        <Link
          to="/$lang/scan"
          params={{ lang }}
          className="inline-flex rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          {t.common.startScan}
        </Link>
      </div>
    </main>
  );
}
