import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, Check, Star } from "lucide-react";
import wolf from "@/assets/wolf-hero.png";
import { LessonGate } from "@/components/academy/LessonGate";
import { LessonPlayer } from "@/components/academy/LessonPlayer";
import { TrackArt } from "@/components/academy/TrackArt";
import { LockBadge } from "@/components/academy/LockBadge";
import { findTrack, lessonKey } from "@/lib/academy";
import type { Lesson } from "@/lib/academy-types";
import { useAcademyCopy } from "@/lib/academy-copy";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useLessonAccess } from "@/lib/lesson-access";
import { levelInfo } from "@/lib/levels";
import { academyXp } from "@/lib/progress";
import { useAccount } from "@/lib/account";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/academy/$track")({
  head: ({ params }) => {
    const lang = isLang(params.lang) ? params.lang : DEFAULT_LANG;
    const track = findTrack(lang, params.track);
    const title = track ? `${track.title} — Shapr` : "Shapr";
    const description = track?.tagline ?? "Modules Shapr.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: TrackPage,
});

/** Horizontal offset of each node, so the path snakes down the screen. */
const CURVE = [0, 68, 96, 68, 0, -68, -96, -68];

function TrackPage() {
  const { lang } = useT();
  const { track: trackId } = Route.useParams();
  const c = useAcademyCopy();
  const track = findTrack(lang, trackId);
  const { academy, complete } = useAccount();
  const done = academy.completedLessons;
  const xp = academyXp(academy);
  const [open, setOpen] = useState<Lesson | null>(null);
  const [gate, setGate] = useState<Lesson | null>(null);
  const access = useLessonAccess();

  if (!track) throw notFound();

  const fr = lang === "fr";
  const level = levelInfo(xp).level;
  const isDone = (l: Lesson) => done.includes(lessonKey(track.id, l.id));
  const completed = track.lessons.filter(isDone).length;

  /** First unfinished lesson: the only one highlighted as "next". */
  const nextIndex = track.lessons.findIndex((l) => !isDone(l));

  const lockOf = (l: Lesson, i: number): boolean => {
    if (l.requiresLevel && level < l.requiresLevel) return true;
    if (!access.canOpen(lessonKey(track.id, l.id))) return true;
    return nextIndex !== -1 && i > nextIndex;
  };

  return (
    <main className="mx-auto max-w-xl px-5 pb-24 pt-6">
      <Link
        to="/$lang/academy"
        params={{ lang }}
        className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        {c.allModules}
      </Link>

      {/* Module banner */}
      <div className="panel mt-4 overflow-hidden">
        <div className="flex items-center gap-4 p-5">
          <TrackArt
            trackId={track.id}
            alt=""
            className="h-14 w-14 shrink-0"
            rounded="rounded-2xl"
          />
          <div className="min-w-0">
            <h1 className="truncate text-xl font-bold">{track.title}</h1>
            <p className="truncate text-sm text-muted-foreground">{track.tagline}</p>
          </div>
          <span className="ml-auto flex shrink-0 flex-col items-end gap-1">
            <span className="rounded-full bg-surface-2 px-3 py-1.5 text-sm font-semibold">
              {completed}/{track.lessons.length}
            </span>
            {!access.pro && (
              <span className="label-mono flex items-center gap-1 text-[10px]">
                <LockBadge className="h-3 w-3" />
                {c.proOnly}
              </span>
            )}
          </span>
        </div>
        <TrackArt
          trackId={track.id}
          alt={track.title}
          className="aspect-[21/9] w-full"
          rounded="rounded-none"
        />
      </div>

      {/* The path */}
      <ol className="relative mt-10 flex flex-col items-center gap-7">
        {track.lessons.map((lesson, i) => {
          const finished = isDone(lesson);
          const key = lessonKey(track.id, lesson.id);
          const owned = access.canOpen(key);
          const locked = lockOf(lesson, i);
          const isNext = i === nextIndex && !locked;
          const dx = CURVE[i % CURVE.length]!;
          const paywalled = !owned;

          return (
            <li key={lesson.id} className="flex w-full flex-col items-center">
              <div
                className="relative flex flex-col items-center"
                style={{ transform: `translateX(${dx}px)` }}
              >
                {isNext && (
                  <span className="mb-2 rounded-xl bg-surface px-3 py-1.5 text-xs font-bold uppercase tracking-wide text-primary shadow-[var(--shadow-panel)]">
                    {completed ? c.resume : c.start}
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => {
                    if (paywalled) {
                      setGate(lesson);
                      return;
                    }
                    if (!locked) setOpen(lesson);
                  }}
                  disabled={locked && owned}
                  aria-label={`${lesson.title}${paywalled ? ` — ${c.proOnly}` : ""}`}
                  className={`btn-chunky relative flex h-[68px] w-[68px] items-center justify-center rounded-full ${
                    finished
                      ? "bg-primary text-primary-foreground"
                      : locked
                        ? "bg-surface-2 text-muted-foreground shadow-none"
                        : "bg-primary text-primary-foreground ring-4 ring-primary/25"
                  }`}
                >
                  {finished ? (
                    <Check className="h-7 w-7" strokeWidth={3} />
                  ) : locked ? (
                    <LockBadge className="h-7 w-7" tone="solid" />
                  ) : (
                    <Star className="h-7 w-7 fill-current" />
                  )}
                  {paywalled && !finished && !locked && (
                    <span className="absolute -right-1.5 -top-1.5 rounded-full bg-foreground p-1.5 text-background shadow-[var(--shadow-panel)]">
                      <LockBadge className="h-3.5 w-3.5" tone="solid" />
                    </span>
                  )}
                </button>
                <span className="mt-2 max-w-[170px] text-center text-xs font-medium leading-tight text-muted-foreground">
                  {lesson.title}
                </span>
                <span
                  className={`label-mono mt-1 rounded-full px-2 py-0.5 text-[10px] ${
                    paywalled
                      ? "bg-surface-2 text-muted-foreground"
                      : "bg-primary/10 text-primary"
                  }`}
                >
                  {access.isFree(key) ? c.free : c.pro}
                </span>
              </div>
            </li>
          );
        })}
      </ol>


      {/* Mascot at the end of the path */}
      <div className="mt-10 flex items-end justify-center gap-3">
        <img src={wolf} alt="" width={1024} height={1024} loading="lazy" className="h-28 w-auto" />
        <p className="mb-6 max-w-[200px] rounded-2xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-panel)]">
          {completed === track.lessons.length
            ? c.trackDone
            : fr
              ? "Une leçon par jour suffit. On y va ?"
              : "One lesson a day is enough. Shall we?"}
        </p>
      </div>

      {gate && (
        <LessonGate lesson={gate} onClose={() => setGate(null)} />
      )}

      {open && (
        <LessonPlayer
          lesson={open}
          trackId={track.id}
          onClose={() => setOpen(null)}
          onComplete={(bonusXp) => {
            void complete(lessonKey(track.id, open.id), bonusXp);
            setOpen(null);
          }}
        />
      )}
    </main>
  );
}
