import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Check, Sparkles } from "lucide-react";
import { LessonImage } from "@/components/academy/LessonImage";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { PRO_PRICE, PRO_PRICE_EN, useIsPro, useSetPro } from "@/lib/pro";
import { useAuth } from "@/lib/auth";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/pro")({
  head: ({ params }) => {
    const lang = isLang(params.lang) ? params.lang : DEFAULT_LANG;
    const title =
      lang === "fr"
        ? `Shapr Pro — ${PRO_PRICE}/mois, ton plan complet et les re-scans`
        : `Shapr Pro — ${PRO_PRICE_EN}/month, your full plan and re-scans`;
    const description =
      lang === "fr"
        ? `Le scan et ta note sont gratuits. Pro ouvre la carte de ton visage, les leçons liées à chaque point, le plan complet et les re-scans illimités pour ${PRO_PRICE} par mois.`
        : `The scan and your score are free. Pro opens the face map, the lesson behind each point, the full plan and unlimited re-scans for ${PRO_PRICE_EN} a month.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: ProPage,
});

const PERKS = {
  fr: [
    "La carte de ton visage : une branche tirée sur chaque point",
    "La leçon qui règle chaque point, en un clic depuis la carte",
    "Les 12 catégories détaillées et tes améliorations prioritaires",
    "Re-scans illimités et comparaison avant / après",
    "Courbe de progression et écart par rapport à ton potentiel",
    "Historique complet de tes rapports",
  ],
  en: [
    "Your face map: a branch pulled from every point",
    "The lesson that fixes each point, one click from the map",
    "All 12 category breakdowns and your priority upgrades",
    "Unlimited re-scans and before / after comparison",
    "Progress curve and the gap to your ceiling",
    "Full history of your reports",
  ],
} as const;

function ProPage() {
  const { lang } = useT();
  const navigate = useNavigate();
  const pro = useIsPro();
  const setPro = useSetPro();
  const { user } = useAuth();
  const fr = lang === "fr";

  return (
    <main className="mx-auto max-w-3xl px-5 py-14 sm:py-20">
      <p className="label-mono">Shapr Pro</p>
      <h1 className="mt-3 font-display text-4xl sm:text-6xl">
        {fr
          ? `Sache quoi améliorer, ${PRO_PRICE} par mois.`
          : `Know what to improve, ${PRO_PRICE_EN} a month.`}
      </h1>
      <p className="mt-4 max-w-xl text-muted-foreground">
        {fr
          ? "Le scan est gratuit et illimité, et ton compte affiche ta note et ton potentiel. Pro ouvre tout le reste : ce qu'il faut changer, dans quel ordre, et la leçon qui va avec."
          : "Scanning is free and unlimited, and your account shows your score and potential. Pro opens everything else: what to change, in what order, and the lesson that goes with it."}
      </p>

      <div className="mt-10 overflow-hidden rounded-3xl">
        <LessonImage
          image="training-cover"
          alt={fr ? "Salle d'entraînement" : "Training floor"}
          className="aspect-[21/9]"
          rounded="rounded-3xl"
        />
      </div>

      <div className="panel mt-10 p-7">
        <div className="flex items-baseline gap-2">
          <span className="font-display text-5xl text-primary">{fr ? PRO_PRICE : PRO_PRICE_EN}</span>
          <span className="label-mono">{fr ? "par mois" : "per month"}</span>
        </div>
        <ul className="mt-6 space-y-3">
          {PERKS[lang].map((perk) => (
            <li key={perk} className="flex gap-3 text-sm text-muted-foreground">
              <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
              {perk}
            </li>
          ))}
        </ul>

        {pro ? (
          <div className="mt-8 space-y-3">
            <p className="rounded-2xl bg-primary/10 px-5 py-4 text-sm text-primary">
              {fr ? "Ton accès Pro est actif." : "Your Pro access is active."}
            </p>
            <button
              type="button"
              onClick={() => void setPro(false)}
              className="text-sm text-muted-foreground underline-offset-4 transition-colors hover:text-foreground hover:underline"
            >
              {fr ? "Désactiver l'accès Pro" : "Turn Pro access off"}
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => {
              if (!user) {
                void navigate({ to: "/$lang/auth", params: { lang } });
                return;
              }
              void setPro(true);
              void navigate({ to: "/$lang/academy", params: { lang } });
            }}
            className="mt-8 flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-4 font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            <Sparkles className="h-4 w-4" />
            {fr ? "Activer Pro" : "Activate Pro"}
          </button>
        )}
        <p className="mt-4 text-xs text-muted-foreground">
          {fr
            ? "Le paiement n'est pas encore branché : ce bouton active l'accès Pro sur ton compte pour que tu puisses tester tout le contenu."
            : "Payment is not connected yet: this button switches Pro on for your account so you can review all the content."}
        </p>
      </div>

      <Link
        to="/$lang/academy"
        params={{ lang }}
        className="mt-8 inline-block text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        {fr ? "← Retour aux modules" : "← Back to the modules"}
      </Link>
    </main>
  );
}
