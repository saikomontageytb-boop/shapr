import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Check, Eye, EyeOff, Moon, Sun, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/integrations/supabase/client";
import { setLeaderboardVisibility } from "@/lib/arena.functions";
import { useAccount } from "@/lib/account";
import { useAuth } from "@/lib/auth";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useTheme } from "@/lib/theme";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/settings")({
  head: ({ params }) => {
    const fr = (isLang(params.lang) ? params.lang : DEFAULT_LANG) === "fr";
    const title = fr ? "Paramètres du compte — Shapr" : "Account settings — Shapr";
    const description = fr
      ? "Change ton pseudo affiché au classement, choisis le thème clair ou sombre et gère ta visibilité."
      : "Change your leaderboard name, pick the light or dark theme and manage your visibility.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: SettingsPage,
});

function SettingsPage() {
  const { lang } = useT();
  const fr = lang === "fr";
  const { user } = useAuth();
  const { arena, refreshArena } = useAccount();
  const { theme, setTheme } = useTheme();
  const saveVisibility = useServerFn(setLeaderboardVisibility);

  const [name, setName] = useState("");
  const [initial, setInitial] = useState("");
  const [saved, setSaved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [visible, setVisible] = useState(arena.showOnLeaderboard);

  useEffect(() => setVisible(arena.showOnLeaderboard), [arena.showOnLeaderboard]);

  useEffect(() => {
    if (!user) return;
    void supabase
      .from("profiles")
      .select("display_name")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        setName(data?.display_name ?? "");
        setInitial(data?.display_name ?? "");
      });
  }, [user]);

  const saveName = async () => {
    if (!user) return;
    setSaving(true);
    try {
      await supabase.from("profiles").update({ display_name: name.trim().slice(0, 32) }).eq("id", user.id);
      setInitial(name.trim().slice(0, 32));
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  };

  const toggleVisibility = async (next: boolean) => {
    setVisible(next);
    await saveVisibility({ data: { visible: next } });
    await refreshArena();
  };

  return (
    <main className="mx-auto min-h-[calc(100dvh-4rem)] max-w-3xl px-4 py-8 sm:px-6 sm:py-14">
      <Button asChild variant="ghost" className="-ml-3">
        <Link to="/$lang/dashboard" params={{ lang }}>
          <ArrowLeft />
          {fr ? "Tableau de bord" : "Dashboard"}
        </Link>
      </Button>

      <header className="mt-8 border-b border-border pb-7">
        <p className="label-mono text-primary">{fr ? "Compte" : "Account"}</p>
        <h1 className="mt-2 font-display text-4xl sm:text-5xl">{fr ? "Paramètres" : "Settings"}</h1>
      </header>

      {!user ? (
        <section className="panel mt-6 p-6 text-center">
          <p className="text-muted-foreground">
            {fr ? "Connecte-toi pour gérer ton compte." : "Sign in to manage your account."}
          </p>
          <Button asChild className="mt-4">
            <Link to="/$lang/auth" params={{ lang }}>{fr ? "Se connecter" : "Sign in"}</Link>
          </Button>
        </section>
      ) : (
        <div className="mt-6 space-y-5">
          <section className="panel p-5 sm:p-6">
            <div className="flex items-center gap-2">
              <UserRound className="h-5 w-5 text-primary" />
              <h2 className="font-display text-xl">{fr ? "Pseudo" : "Username"}</h2>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {fr
                ? "C’est le nom que les autres membres voient dans le classement."
                : "This is the name other members see on the leaderboard."}
            </p>
            <div className="mt-4 flex flex-col gap-3 sm:flex-row">
              <Input
                value={name}
                maxLength={32}
                onChange={(event) => setName(event.target.value)}
                placeholder={fr ? "Ton pseudo" : "Your username"}
                aria-label={fr ? "Pseudo" : "Username"}
              />
              <Button
                onClick={() => void saveName()}
                disabled={saving || name.trim().length < 2 || name.trim() === initial}
                className="sm:w-40"
              >
                {saved ? <Check /> : null}
                {saved ? (fr ? "Enregistré" : "Saved") : fr ? "Enregistrer" : "Save"}
              </Button>
            </div>
          </section>

          <section className="panel p-5 sm:p-6">
            <div className="flex items-center gap-2">
              {theme === "dark" ? <Moon className="h-5 w-5 text-primary" /> : <Sun className="h-5 w-5 text-primary" />}
              <h2 className="font-display text-xl">{fr ? "Apparence" : "Appearance"}</h2>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {fr ? "Choisis le mode clair ou le mode sombre." : "Pick the light or the dark mode."}
            </p>
            <div className="mt-4 grid grid-cols-2 gap-3">
              {(["light", "dark"] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  onClick={() => setTheme(option)}
                  aria-pressed={theme === option}
                  className={`flex items-center gap-3 rounded-md border p-4 text-left transition-colors ${
                    theme === option ? "border-primary bg-primary/10" : "border-border bg-surface-2"
                  }`}
                >
                  {option === "light" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
                  <span className="font-medium">
                    {option === "light" ? (fr ? "Clair" : "Light") : fr ? "Sombre" : "Dark"}
                  </span>
                </button>
              ))}
            </div>
          </section>

          <section className="panel p-5 sm:p-6">
            <div className="flex items-center gap-2">
              {visible ? <Eye className="h-5 w-5 text-primary" /> : <EyeOff className="h-5 w-5 text-muted-foreground" />}
              <h2 className="font-display text-xl">{fr ? "Classement" : "Leaderboard"}</h2>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {fr
                ? "Apparaître dans le classement public avec ton pseudo et tes points."
                : "Appear on the public leaderboard with your username and points."}
            </p>
            <div className="mt-4 flex items-center justify-between gap-3">
              <span className="text-sm font-medium">
                {visible ? (fr ? "Visible" : "Visible") : fr ? "Masqué" : "Hidden"}
              </span>
              <Switch
                checked={visible}
                onCheckedChange={(next) => void toggleVisibility(next)}
                aria-label={fr ? "Apparaître dans le classement" : "Appear on leaderboard"}
              />
            </div>
          </section>
        </div>
      )}
    </main>
  );
}
