import { createFileRoute, Link } from "@tanstack/react-router";
import { ReportView } from "@/components/report/ReportView";
import { useSample } from "@/lib/use-sample";
import { dict, isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/example")({
  head: ({ params }) => {
    const t = dict(isLang(params.lang) ? params.lang : DEFAULT_LANG);
    const title = `${t.example.label} — Shapr`;
    return {
      meta: [
        { title },
        { name: "description", content: t.example.intro },
        { property: "og:title", content: title },
        { property: "og:description", content: t.example.intro },
      ],
    };
  },
  component: ExamplePage,
});

function ExamplePage() {
  const { lang, t } = useT();
  const sample = useSample();

  return (
    <main className="mx-auto max-w-5xl px-5 py-12">
      <div className="panel mb-10 flex flex-wrap items-center justify-between gap-4 bg-accent/5 p-6">
        <div>
          <p className="label-mono text-accent">{t.example.sampleLabel}</p>
          <p className="mt-1 text-sm text-muted-foreground">{t.example.sampleBody}</p>
        </div>
        <Link
          to="/$lang/scan"
          params={{ lang }}
          className="rounded-full bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          {t.example.scanCta}
        </Link>
      </div>

      <ReportView analysis={sample} interactive={false} completed={[]} />
    </main>
  );
}
