import { useEffect, useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, CalendarDays, Flame, Play, Skull } from "lucide-react";
import { useServerFn } from "@tanstack/react-start";
import wolf from "@/assets/wolf-hero.png";
import { ArenaIcon } from "@/components/site/ArenaIcon";
import { Aurora, Over, Run, type OverProps } from "@/components/arena/game";
import { CATEGORIES } from "@/lib/academy";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { levelInfo, levelTitle } from "@/lib/levels";
import { useT } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { useAccount } from "@/lib/account";
import { submitArenaRun } from "@/lib/arena.functions";
import {
  ARENA_COPY,
  DEFAULT_CONFIG,
  DIFFICULTIES,
  LENGTH_CHOICES,
  addProgress,
  difficultyOf,
  loadBest,
  loadProgress,
  questionPool,
  saveBest,
  xpForRun,
  type ArenaConfig,
  type ArenaCopy,
  type Difficulty,
} from "@/lib/arena";

export const Route = createFileRoute("/$lang/arena")({
  head: ({ params }) => {
    const lang = isLang(params.lang) ? params.lang : DEFAULT_LANG;
    const title = lang === "fr" ? "Arène Shapr — quiz sans fin" : "Shapr Arena — endless quiz";
    const description =
      lang === "fr"
        ? "Un quiz sans fin sur les thèmes de tes leçons : choisis les thèmes, la difficulté et la durée, puis enchaîne les séries."
        : "An endless quiz built on your lesson themes: pick themes, difficulty and run length, then chain streaks.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: ArenaPage,
});

type Phase = "setup" | "play" | "over";

function ArenaPage() {
  const { lang } = useT();
  const { user } = useAuth();
  const { arena, refreshArena } = useAccount();
  const saveRun = useServerFn(submitArenaRun);
  const c = ARENA_COPY[lang] as ArenaCopy;
  const fr = lang === "fr";

  const [phase, setPhase] = useState<Phase>("setup");
  const [config, setConfig] = useState<ArenaConfig>(DEFAULT_CONFIG);
  const [best, setBest] = useState(0);
  const [progress, setProgress] = useState({ xp: 0, runs: 0 });
  const [result, setResult] = useState<(OverProps & { xpBefore: number; xpGain: number }) | null>(null);
  const [runId, setRunId] = useState(0);

  useEffect(() => {
    setBest(user ? arena.bestScore : loadBest());
    setProgress(user ? { xp: arena.arenaXp, runs: arena.runs } : loadProgress());
  }, [user, arena]);

  const difficulty = difficultyOf(config);
  const pool = useMemo(() => questionPool(lang, config.categoryIds), [lang, config.categoryIds]);

  return (
    <main className="relative min-h-[calc(100dvh-4rem)] overflow-hidden px-4 pb-24 pt-6 sm:px-5 sm:pt-8">
      <Aurora />
      <div className="relative mx-auto w-full max-w-xl">
        {phase === "setup" && (
          <Setup
            c={c}
            fr={fr}
            lang={lang}
            best={best}
            progress={progress}
            config={config}
            difficulty={difficulty}
            poolSize={pool.length}
            onChange={setConfig}
            onStart={() => setPhase("play")}
          />
        )}
        {phase === "play" && (
          <Run
            key={runId}
            c={c}
            config={config}
            difficulty={difficulty}
            pool={pool}
            onQuit={() => setPhase("setup")}
            onOver={(props) => {
              const localXp = xpForRun(props.score, difficulty.reward);
              const beforeXp = user ? arena.arenaXp : loadProgress().xp;
              const finalize = async () => {
                let xpGain = localXp;
                if (user) {
                  try {
                    const saved = await saveRun({
                      data: {
                        score: props.score,
                        difficulty: config.difficulty,
                        questionCount: props.answers.length,
                        correctCount: props.answers.filter((answer) => answer.correct).length,
                        bestStreak: props.bestStreak,
                        eliminated: props.eliminated,
                        categoryIds: config.categoryIds,
                        challengeDate: null,
                      },
                    });
                    xpGain = saved.xpEarned;
                    setProgress({ xp: saved.arenaXp, runs: saved.runs });
                    setBest(saved.bestScore);
                    await refreshArena();
                  } catch {
                    setProgress({ xp: arena.arenaXp, runs: arena.runs });
                  }
                } else {
                  setProgress(addProgress(xpGain));
                  saveBest(props.score);
                  setBest(loadBest());
                }
                setResult({ ...props, xpBefore: beforeXp, xpGain });
                setPhase("over");
              };
              void finalize();
            }}
          />
        )}
        {phase === "over" && result && (
          <Over
            {...result}
            c={c}
            lang={lang}
            best={best}
            onAgain={() => {
              setResult(null);
              setRunId((n) => n + 1);
              setPhase("play");
            }}
            onSetup={() => {
              setResult(null);
              setPhase("setup");
            }}
          />
        )}
      </div>
    </main>
  );
}

/* ------------------------------------------------------------------- setup */

function Setup({
  c,
  fr,
  lang,
  best,
  progress,
  config,
  difficulty,
  poolSize,
  onChange,
  onStart,
}: {
  c: ArenaCopy;
  fr: boolean;
  lang: "fr" | "en";
  best: number;
  progress: { xp: number; runs: number };
  config: ArenaConfig;
  difficulty: Difficulty;
  poolSize: number;
  onChange: (next: ArenaConfig) => void;
  onStart: () => void;
}) {
  const ready = poolSize >= 4;
  const info = levelInfo(progress.xp);

  const toggleCategory = (id: string) => {
    const on = config.categoryIds.includes(id);
    onChange({
      ...config,
      categoryIds: on ? config.categoryIds.filter((x) => x !== id) : [...config.categoryIds, id],
    });
  };

  return (
    <div className="animate-rise space-y-4 sm:space-y-5">
      <Link
        to="/$lang/academy"
        params={{ lang }}
        className="label-mono inline-flex items-center gap-1.5 transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        {c.backAcademy}
      </Link>

      <header className="panel relative overflow-hidden p-5 sm:p-6">
        <div className="relative flex items-start gap-4">
          <img src={wolf} alt="" width={1024} height={1024} className="animate-float h-20 w-auto shrink-0 sm:h-24" />
          <div className="min-w-0">
            <p className="label-mono flex items-center gap-1.5 text-primary">
              <ArenaIcon className="h-4 w-4" />
              {c.name}
            </p>
            <h1 className="mt-1 font-display text-2xl leading-tight sm:text-3xl">{c.tagline}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{c.intro}</p>
          </div>
        </div>

        <div className="relative mt-5 rounded-2xl bg-surface-2 p-4">
          <div className="flex items-baseline justify-between gap-3">
            <p className="font-semibold">
              {c.level} {info.level}
              <span className="ml-2 font-normal text-muted-foreground">{levelTitle(lang, info.level)}</span>
            </p>
            <p className="label-mono tabular-nums">
              {progress.xp} {c.totalXp}
            </p>
          </div>
          <div className="mt-2.5 h-2 overflow-hidden rounded-full bg-background">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-700"
              style={{ width: `${info.progress}%` }}
            />
          </div>
          <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
            <span>
              {progress.runs} {c.runs}
            </span>
            {best > 0 && (
              <span className="inline-flex items-center gap-1.5 font-semibold text-primary">
                <Flame className="h-3.5 w-3.5" />
                {c.best} · {best}
              </span>
            )}
          </div>
        </div>
      </header>

      <section className="panel p-4 sm:p-5">
        <p className="label-mono">{c.themes}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <Chip
            active={config.categoryIds.length === 0}
            onClick={() => onChange({ ...config, categoryIds: [] })}
            label={c.allThemes}
          />
          {CATEGORIES.map((cat) => (
            <Chip
              key={cat.id}
              active={config.categoryIds.includes(cat.id)}
              onClick={() => toggleCategory(cat.id)}
              label={fr ? cat.fr : cat.en}
            />
          ))}
        </div>
      </section>

      <section className="panel p-4 sm:p-5">
        <div className="flex items-baseline justify-between gap-3">
          <p className="label-mono">{c.difficulty}</p>
          <p className="font-display text-lg text-primary">{fr ? difficulty.fr : difficulty.en}</p>
        </div>

        <input
          type="range"
          min={0}
          max={DIFFICULTIES.length - 1}
          step={1}
          value={config.difficulty}
          aria-label={c.difficulty}
          onChange={(e) => onChange({ ...config, difficulty: Number(e.target.value) })}
          className="mt-4 h-2 w-full cursor-pointer appearance-none rounded-full bg-surface-2 accent-primary"
        />
        <div className="mt-2 flex justify-between">
          {DIFFICULTIES.map((d, i) => (
            <span
              key={d.en}
              className={`h-1.5 w-1.5 rounded-full transition-colors ${
                i <= config.difficulty ? "bg-primary" : "bg-surface-2"
              }`}
            />
          ))}
        </div>

        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          <Stat label={c.answers} value={String(difficulty.optionCount)} />
          <Stat label={c.timer} value={difficulty.seconds === 0 ? "∞" : `${difficulty.seconds}${c.seconds}`} />
          <Stat label={c.reward} value={`×${difficulty.reward}`} />
        </div>

        {difficulty.suddenDeath && (
          <p className="mt-3 flex items-center gap-2 rounded-2xl bg-destructive/10 px-4 py-2.5 text-sm font-medium text-destructive">
            <Skull className="h-4 w-4 shrink-0" />
            {c.suddenDeath}
          </p>
        )}
      </section>

      <section className="panel p-4 sm:p-5">
        <p className="label-mono">{c.length}</p>
        <div className="mt-2.5 flex flex-wrap gap-2">
          {LENGTH_CHOICES.map((n) => (
            <Chip
              key={n}
              active={config.questionCount === n}
              onClick={() => onChange({ ...config, questionCount: n })}
              label={n === 0 ? `∞ ${c.endless}` : String(n)}
            />
          ))}
        </div>
      </section>

      <p className="label-mono text-center">{ready ? `${poolSize} ${c.questionsReady}` : c.notEnough}</p>

      <button
        type="button"
        disabled={!ready}
        onClick={onStart}
        className="btn-chunky flex w-full items-center justify-center gap-2 bg-primary px-6 py-4 text-lg font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-40"
      >
        <Play className="h-5 w-5" />
        {c.play}
      </button>

      <Link
        to="/$lang/daily"
        params={{ lang }}
        className="flex items-center gap-3 rounded-2xl bg-surface-2 px-4 py-3 text-sm transition-colors hover:text-primary"
      >
        <CalendarDays className="h-4 w-4 shrink-0 text-primary" />
        <span className="flex-1">
          {fr
            ? "Le défi du jour est une page à part : 5 questions, une fois par jour."
            : "The daily challenge lives on its own page: 5 questions, once a day."}
        </span>
      </Link>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-surface-2 px-2 py-3">
      <p className="font-display text-lg leading-none">{value}</p>
      <p className="label-mono mt-1.5 leading-tight">{label}</p>
    </div>
  );
}

function Chip({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-4 py-2 text-sm font-medium transition-all active:scale-95 ${
        active ? "bg-primary text-primary-foreground shadow-glow" : "bg-surface-2 text-muted-foreground hover:text-foreground"
      }`}
    >
      {label}
    </button>
  );
}
