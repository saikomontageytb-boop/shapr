import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { AlertTriangle, ArrowRight } from "lucide-react";
import { ReportView } from "@/components/report/ReportView";
import { ProfileStep } from "@/components/scan/ProfileStep";
import { ScanningSequence } from "@/components/scan/ScanningSequence";
import { UploadZone } from "@/components/scan/UploadZone";
import type { Analysis, SubjectProfile } from "@/lib/analysis-schema";
import { track } from "@/lib/analytics";
import { useAuth } from "@/lib/auth";
import { saveScanToCloud } from "@/lib/cloud-scans";
import { dict, isLang, DEFAULT_LANG, type Lang } from "@/lib/i18n";
import {
  clearSessionPhoto,
  setSessionPhoto,
  takePendingPhoto,
} from "@/lib/pending-photo";
import { analyzeScan } from "@/lib/scan.functions";
import { useAccess } from "@/lib/access";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/scan")({
  head: ({ params }) => {
    const t = dict(isLang(params.lang) ? params.lang : DEFAULT_LANG);
    return {
      meta: [
        { title: t.scan.metaTitle },
        { name: "description", content: t.scan.metaDesc },
        { property: "og:title", content: t.scan.metaTitle },
        { property: "og:description", content: t.scan.metaDesc },
      ],
    };
  },
  component: ScanPage,
});

type Stage = "upload" | "preview" | "profile" | "analyzing" | "result" | "error";


const ERROR_COPY: Record<Lang, Record<string, { title: string; body: string }>> = {
  fr: {
    no_face: {
      title: "On n'arrive pas à lire clairement ton visage",
      body: "Essaie une photo de face, mieux éclairée, avec tout le visage dans le cadre.",
    },
    multiple_faces: {
      title: "Il y a plus d'un visage sur cette photo",
      body: "Envoie une photo où tu es seul pour que l'analyse reste juste.",
    },
    low_quality: {
      title: "Cette photo est trop sombre, floue ou petite",
      body: "Utilise une photo nette et bien éclairée, en résolution correcte. Un selfie récent suffit.",
    },
    invalid_format: {
      title: "Ce fichier n'est pas une image prise en charge",
      body: "Utilise un JPG, un PNG ou un WebP.",
    },
    too_large: {
      title: "Cette photo est trop lourde",
      body: "Reste sous 8 Mo — la plupart des photos de téléphone y sont déjà.",
    },
    rate_limited: {
      title: "Trop de scans en peu de temps",
      body: "Laisse passer quelques minutes et reviens.",
    },
    quota: {
      title: "Le moteur d'analyse est à court de crédits",
      body: "C'est de notre côté, pas du tien. Réessaie un peu plus tard.",
    },
    unavailable: {
      title: "L'analyse n'a pas abouti",
      body: "Quelque chose a échoué chez nous. Ta photo n'a pas été conservée. Réessaie.",
    },
  },
  en: {
    no_face: {
      title: "We couldn't get a clear read of your face",
      body: "Try a front-facing photo in brighter light, with your whole face in frame.",
    },
    multiple_faces: {
      title: "There's more than one face in that photo",
      body: "Upload a photo with only you in it so the analysis stays accurate.",
    },
    low_quality: {
      title: "That photo is too dark, blurry or small",
      body: "Use a sharp, well-lit photo at a decent resolution — a recent selfie works fine.",
    },
    invalid_format: {
      title: "That file isn't a supported image",
      body: "Use a JPG, PNG or WebP photo.",
    },
    too_large: {
      title: "That photo is too large",
      body: "Keep it under 8 MB — most phone photos already are.",
    },
    rate_limited: {
      title: "Too many scans in a short window",
      body: "Give it a few minutes and come back.",
    },
    quota: {
      title: "The analysis engine is out of credits",
      body: "This is on our side, not yours. Try again shortly.",
    },
    unavailable: {
      title: "The analysis didn't complete",
      body: "Something failed on our end. Your photo wasn't stored. Try again.",
    },
  },
};

function ScanPage() {
  const { lang, t } = useT();
  const navigate = useNavigate();
  const analyze = useServerFn(analyzeScan);
  const { user } = useAuth();
  const access = useAccess();
  const [stage, setStage] = useState<Stage>("upload");
  const [image, setImage] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [error, setError] = useState<{ title: string; body: string } | null>(null);

  const errors = ERROR_COPY[lang];

  useEffect(() => {
    track("scan_started");
    const pending = takePendingPhoto();
    if (pending) {
      setImage(pending);
      setStage("preview");
      track("photo_uploaded", { from: "landing" });
    }
  }, []);

  const run = async (dataUrl: string, profile: SubjectProfile) => {
    setStage("analyzing");
    track("analysis_started", { sex: profile.sex, age_range: profile.age_range });
    try {
      const result = await analyze({ data: { imageDataUrl: dataUrl, lang, profile } });
      if (result.ok) {
        setAnalysis(result.analysis);
        if (user) void saveScanToCloud(result.analysis);
        // The photo stays in this tab's session only, so the face map can be
        // drawn on the report. It is never uploaded or persisted.
        setSessionPhoto(dataUrl);
        setImage(null);
        setStage("result");
        track("analysis_completed", { score: result.analysis.overall_score });
        track("report_preview_viewed");
        track("paywall_viewed");
      } else {
        setError(errors[result.code] ?? errors["unavailable"]!);
        setStage("error");
        track("analysis_failed", { code: result.code });
      }
    } catch {
      setError(errors["unavailable"]!);
      setStage("error");
      track("analysis_failed", { code: "network" });
    }
  };

  const reset = () => {
    setImage(null);
    setAnalysis(null);
    setError(null);
    clearSessionPhoto();
    setStage("upload");
  };


  return (
    <main className="mx-auto max-w-2xl px-5 py-12 sm:py-16">
      {stage === "upload" && (
        <>
          <header className="mb-8">
            <h1 className="font-display text-4xl sm:text-5xl">{t.scan.step1Title}</h1>
            <p className="mt-3 text-muted-foreground">{t.scan.step1Body}</p>
          </header>
          <UploadZone
            copy={{ ...t.hero, ...t.upload }}
            onReady={(dataUrl) => {
              setImage(dataUrl);
              setStage("preview");
              track("photo_uploaded");
            }}
            onError={(message) => {
              setError({ title: t.scan.badPhoto, body: message });
              setStage("error");
            }}
          />
        </>
      )}

      {stage === "preview" && image && (
        <>
          <header className="mb-8">
            <h1 className="font-display text-4xl sm:text-5xl">{t.scan.step2Title}</h1>
          </header>
          <div className="space-y-4">
            <div className="panel overflow-hidden">
              <img
                src={image}
                alt=""
                className="max-h-[420px] w-full object-cover"
              />
            </div>
            <div className="flex flex-col gap-3">
              <p className="text-sm text-muted-foreground">{t.scan.confirmBody}</p>
              <button
                onClick={() => setStage("profile")}
                className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
              >
                {t.scan.analyzeCta}
              </button>
              <button
                onClick={reset}
                className="rounded-full bg-surface-2 px-6 py-3 text-sm font-medium transition-colors hover:text-primary"
              >
                {t.scan.pickAnother}
              </button>
            </div>
          </div>
        </>
      )}

      {stage === "profile" && image && (
        <ProfileStep
          preview={image}
          onBack={reset}
          onSubmit={(profile) => void run(image, profile)}
        />
      )}


      {stage === "analyzing" && <ScanningSequence imageDataUrl={image ?? ""} />}

      {stage === "error" && error && (
        <div className="panel mx-auto max-w-lg p-8 text-center">
          <span className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-warning/12">
            <AlertTriangle className="h-5 w-5 text-warning" />
          </span>
          <h1 className="mt-5 font-display text-3xl">{error.title}</h1>
          <p className="mt-2 text-sm text-muted-foreground">{error.body}</p>
          <button
            onClick={reset}
            className="mt-6 rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            {t.scan.tryAnother}
          </button>
        </div>
      )}

      {stage === "result" && analysis && (
        <div className="animate-rise">
          <ReportView analysis={analysis} access={access} photo={image ?? undefined} />
          <div className="panel mt-10 flex flex-wrap items-center justify-between gap-4 p-6">
            <p className="text-sm text-muted-foreground">
              {user ? t.scan.savedCloud : t.scan.savedLocal}
            </p>
            <Link
              to="/$lang/report"
              params={{ lang }}
              className="inline-flex items-center gap-2 text-sm font-semibold text-primary"
            >
              {t.scan.goProgress} <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      )}
    </main>
  );
}
