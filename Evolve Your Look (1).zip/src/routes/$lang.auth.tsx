import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { dict, isLang, DEFAULT_LANG } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";
import { useAuth } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";

export const Route = createFileRoute("/$lang/auth")({
  head: ({ params }) => {
    const t = dict(isLang(params.lang) ? params.lang : DEFAULT_LANG);
    return {
      meta: [
        { title: t.auth.metaTitle },
        { name: "description", content: t.auth.metaDesc },
        { property: "og:title", content: t.auth.metaTitle },
        { property: "og:description", content: t.auth.metaDesc },
      ],
    };
  },
  component: AuthPage,
});

function AuthPage() {
  const { lang, t } = useT();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) void navigate({ to: "/$lang/report", params: { lang } });
  }, [user, lang, navigate]);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setMessage(null);

    if (mode === "up") {
      const { data, error: err } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/${lang}/report`,
          data: { display_name: name, locale: lang },
        },
      });
      setBusy(false);
      if (err) {
        setError(err.message);
        return;
      }
      if (!data.session) setMessage(t.auth.checkEmail);
      return;
    }

    const { error: err } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (err) setError(err.message);
  };

  const google = async () => {
    setError(null);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError(result.error.message ?? "OAuth error");
      return;
    }
    if (result.redirected) return;
    void navigate({ to: "/$lang/report", params: { lang } });
  };

  return (
    <main className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-5 py-16">
      <p className="label-mono">{t.auth.label}</p>
      <h1 className="mt-3 font-display text-4xl">
        {mode === "in" ? t.auth.signInTitle : t.auth.signUpTitle}
      </h1>
      <p className="mt-3 text-muted-foreground">
        {mode === "in" ? t.auth.signInLead : t.auth.signUpLead}
      </p>

      <form onSubmit={(e) => void submit(e)} className="panel mt-8 space-y-4 p-6">
        {mode === "up" && (
          <Field label={t.auth.name}>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              autoComplete="nickname"
              className="w-full rounded-xl bg-surface-2 px-4 py-3 text-sm outline-none"
            />
          </Field>
        )}
        <Field label={t.auth.email}>
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            className="w-full rounded-xl bg-surface-2 px-4 py-3 text-sm outline-none"
          />
        </Field>
        <Field label={t.auth.password}>
          <input
            type="password"
            required
            minLength={8}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete={mode === "in" ? "current-password" : "new-password"}
            className="w-full rounded-xl bg-surface-2 px-4 py-3 text-sm outline-none"
          />
        </Field>

        {error && <p className="text-sm text-destructive">{error}</p>}
        {message && <p className="text-sm text-primary">{message}</p>}

        <button
          type="submit"
          disabled={busy}
          className="w-full rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-60"
        >
          {busy ? t.auth.working : mode === "in" ? t.auth.signIn : t.auth.signUp}
        </button>

        <p className="text-center text-xs uppercase tracking-widest text-muted-foreground">
          {t.auth.or}
        </p>

        <button
          type="button"
          onClick={() => void google()}
          className="w-full rounded-full bg-surface-2 px-6 py-3 text-sm font-medium transition-colors hover:text-primary"
        >
          {t.auth.google}
        </button>
      </form>

      <button
        onClick={() => {
          setMode(mode === "in" ? "up" : "in");
          setError(null);
          setMessage(null);
        }}
        className="mt-6 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        {mode === "in" ? t.auth.toSignUp : t.auth.toSignIn}
      </button>

      <Link
        to="/$lang/scan"
        params={{ lang }}
        className="mt-2 text-sm text-primary"
      >
        {t.common.startScan}
      </Link>
    </main>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="label-mono">{label}</span>
      <span className="mt-2 block">{children}</span>
    </label>
  );
}
