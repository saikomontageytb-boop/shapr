import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowRight, CalendarDays, Check, Flame, ScanFace, Sparkles, Trophy, Zap } from "lucide-react";
import wolf from "@/assets/wolf-hero.png";
import { BadgeEmblem } from "@/components/progress/BadgeEmblem";
import { Button } from "@/components/ui/button";
import { TrackArt } from "@/components/academy/TrackArt";
import { BADGES } from "@/lib/badges";
import { useAcademy, lessonKey } from "@/lib/academy";
import { getLeaderboard, syncAccountXp, type LeaderboardEntry } from "@/lib/arena.functions";
import { useAuth } from "@/lib/auth";
import { useAccount } from "@/lib/account";
import { fetchCloudScans } from "@/lib/cloud-scans";
import { utcDay } from "@/lib/daily-challenge";
import { isLang, DEFAULT_LANG } from "@/lib/i18n";
import { levelTitle } from "@/lib/levels";
import { EMPTY_PROGRESS, academyXp, latestScan, levelFor, streakFor, xpFor, type ProgressState } from "@/lib/progress";
import { useT } from "@/lib/use-lang";

export const Route = createFileRoute("/$lang/dashboard")({
  head: ({ params }) => {
    const fr = (isLang(params.lang) ? params.lang : DEFAULT_LANG) === "fr";
    const title = fr ? "Progression et défis — Shapr" : "Progress and challenges — Shapr";
    const description = fr ? "Suis ton niveau, relève le défi du jour et débloque tes badges Shapr." : "Track your level, take the daily challenge and unlock Shapr badges.";
    return { meta: [{ title }, { name: "description", content: description }, { property: "og:title", content: title }, { property: "og:description", content: description }, { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" }] };
  },
  component: DashboardPage,
});

function DashboardPage() {
  const { lang } = useT();
  const fr = lang === "fr";
  const { user } = useAuth();
  const tracks = useAcademy();
  const { academy, arena, ready } = useAccount();
  const fetchLeaderboard = useServerFn(getLeaderboard);
  const pushAccountXp = useServerFn(syncAccountXp);
  const [progress, setProgress] = useState<ProgressState>(EMPTY_PROGRESS);
  const [leaders, setLeaders] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    if (!user) return;
    void Promise.all([fetchCloudScans(), fetchLeaderboard().catch(() => [])]).then(([cloud, ranking]) => {
      setProgress({ scans: cloud.scans, completedQuests: cloud.completedQuests, achievements: cloud.scans.length ? ["first_scan", ...(cloud.scans.length > 1 ? ["rescan"] : [])] : [], unlocked: false });
      setLeaders(ranking);
    });
  }, [user, fetchLeaderboard]);

  useEffect(() => {
    if (!user || !ready) return;
    const xp = xpFor(progress, latestScan(progress)?.analysis ?? null) + academyXp(academy);
    if (xp === arena.accountXp) return;
    void pushAccountXp({ data: { xp } }).catch(() => undefined);
  }, [user, ready, progress, academy, arena.accountXp, pushAccountXp]);

  const scan = latestScan(progress);
  const foundationXp = xpFor(progress, scan?.analysis ?? null) + academyXp(academy);
  const totalXp = foundationXp + arena.arenaXp;
  if (!ready) return <div className="min-h-[60vh]" />;
  const info = levelFor(totalXp);
  const learningStreak = streakFor(academy);
  const dailyDone = arena.lastDailyDate === utcDay();
  const unlockedIds = new Set([...progress.achievements, ...arena.badges]);
  const nextTrack = tracks.find((track) => track.lessons.some((lesson) => !academy.completedLessons.includes(lessonKey(track.id, lesson.id))));
  const nextLesson = nextTrack?.lessons.find((lesson) => !academy.completedLessons.includes(lessonKey(nextTrack.id, lesson.id)));

  return (
    <main className="relative overflow-hidden px-4 py-8 sm:px-6 sm:py-12">
      <div className="grid-noise pointer-events-none absolute inset-0 -z-10 opacity-50" />
      <div className="mx-auto max-w-6xl">
        <header className="flex flex-col gap-5 border-b border-border pb-7 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="label-mono text-primary">{fr ? "Centre de progression" : "Progress hub"}</p>
            <h1 className="mt-2 font-display text-4xl sm:text-6xl">{fr ? "Ton évolution, en direct." : "Your growth, live."}</h1>
          </div>
          <div className="flex items-center gap-3 rounded-md bg-foreground px-4 py-3 text-background">
            <Zap className="h-5 w-5 text-highlight" />
            <div><p className="text-xs opacity-70">{fr ? "Niveau global" : "Global level"}</p><p className="font-display text-xl">{info.level} · {levelTitle(lang, info.level)}</p></div>
          </div>
        </header>

        <div className="mt-6 grid gap-5 lg:grid-cols-[1.45fr_0.75fr]">
          <div className="space-y-5">
            <section className="panel relative overflow-hidden bg-foreground p-6 text-background sm:p-8">
              <div className="relative z-10 max-w-xl">
                <p className="label-mono text-highlight">{totalXp.toLocaleString(lang)} XP</p>
                <h2 className="mt-3 font-display text-3xl sm:text-4xl">{fr ? "Chaque action façonne ta prochaine version." : "Every action shapes your next version."}</h2>
                <div className="mt-7 h-2 overflow-hidden rounded-full bg-background/20"><div className="h-full rounded-full bg-highlight transition-[width] duration-700" style={{ width: `${info.progress}%` }} /></div>
                <div className="mt-2 flex justify-between text-xs text-background/65"><span>{info.into} / {info.span} XP</span><span>{info.max ? (fr ? "Maximum" : "Maximum") : `${info.toNext} XP`}</span></div>
              </div>
              <img src={wolf} alt="" className="absolute -bottom-12 -right-6 hidden h-56 w-auto opacity-70 sm:block" />
            </section>

            <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Metric icon={Flame} value={String(Math.max(learningStreak, arena.dailyStreak))} label={fr ? "Série" : "Streak"} />
              <Metric icon={Sparkles} value={String(academy.completedLessons.length)} label={fr ? "Leçons" : "Lessons"} />
              <Metric icon={Trophy} value={String(arena.bestScore)} label={fr ? "Record" : "Best"} />
              <Metric icon={ScanFace} value={scan ? scan.analysis.overall_score.toFixed(1) : "—"} label={fr ? "Score scan" : "Scan score"} />
            </section>

            <section className="panel overflow-hidden">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border p-5"><div><p className="label-mono">{fr ? "Récompenses" : "Rewards"}</p><h2 className="mt-1 font-display text-2xl">{unlockedIds.size} / {BADGES.length} {fr ? "badges" : "badges"}</h2></div><Trophy className="h-6 w-6 text-primary" /></div>
              <div className="grid sm:grid-cols-2">{BADGES.map((badge) => <BadgeEmblem key={badge.id} badge={badge} unlocked={unlockedIds.has(badge.id)} lang={lang} />)}</div>
            </section>
          </div>

          <aside className="space-y-5">
            <section className="panel overflow-hidden border-primary/25">
              <div className={`p-5 ${dailyDone ? "bg-surface-2" : "bg-primary text-primary-foreground"}`}>
                <div className="flex items-center justify-between">
                  <p className={`label-mono ${dailyDone ? "text-primary" : "text-primary-foreground/70"}`}>{fr ? "Défi du jour" : "Daily challenge"}</p>
                  {dailyDone ? <Check className="h-5 w-5 text-primary" /> : <CalendarDays className="h-5 w-5" />}
                </div>
                <h2 className="mt-8 font-display text-3xl">
                  {dailyDone ? (fr ? "Défi relevé aujourd’hui" : "Done for today") : `5 ${fr ? "questions. Une tentative." : "questions. One attempt."}`}
                </h2>
                <p className={`mt-2 text-sm ${dailyDone ? "text-muted-foreground" : "text-primary-foreground/75"}`}>
                  {dailyDone
                    ? fr ? "5 nouvelles questions à minuit UTC." : "5 new questions at midnight UTC."
                    : fr ? "Le même test pour tous. Ta série se joue aujourd’hui." : "The same test for everyone. Your streak is on the line."}
                </p>
              </div>
              <div className="p-5">
                <div className="mb-3 flex items-center justify-between text-sm"><span>{fr ? "Série quotidienne" : "Daily streak"}</span><strong>{arena.dailyStreak} {fr ? "jours" : "days"}</strong></div>
                <div className="mb-4 flex items-center justify-between text-sm"><span>{fr ? "Points du mois" : "Points this month"}</span><strong>{arena.dailyXp}</strong></div>
                {dailyDone ? (
                  <Button variant="outline" className="h-12 w-full rounded-md" disabled>
                    <Check />
                    {fr ? "Déjà joué aujourd’hui" : "Already played today"}
                  </Button>
                ) : (
                  <Button asChild className="h-12 w-full rounded-md">
                    <Link to="/$lang/daily" params={{ lang }}>{fr ? "Lancer le défi" : "Start challenge"}<ArrowRight /></Link>
                  </Button>
                )}
              </div>
            </section>

            {nextTrack && nextLesson && <section><p className="label-mono mb-3">{fr ? "Prochaine étape" : "Next step"}</p><Link to="/$lang/academy/$track" params={{ lang, track: nextTrack.id }} className="panel flex items-center gap-3 p-4 transition-transform hover:-translate-y-0.5"><TrackArt trackId={nextTrack.id} alt="" className="h-12 w-12 shrink-0" rounded="rounded-md" /><span className="min-w-0 flex-1"><strong className="block truncate">{nextLesson.title}</strong><span className="text-xs text-muted-foreground">{nextLesson.minutes} min · {nextLesson.xp} XP</span></span><ArrowRight className="h-4 w-4" /></Link></section>}

            <section className="panel p-5"><div className="flex items-center justify-between"><div><p className="label-mono">{fr ? "Classement" : "Leaderboard"}</p><h2 className="mt-1 font-display text-2xl">Top Shapr</h2></div><Trophy className="h-5 w-5 text-primary" /></div><div className="mt-4 space-y-1">{leaders.slice(0, 5).map((entry) => <div key={`${entry.rank}-${entry.displayName}`} className={`flex items-center gap-3 rounded-md px-3 py-2.5 ${entry.current ? "bg-primary/10" : "bg-surface-2"}`}><span className="label-mono w-6">{entry.rank}</span><span className="min-w-0 flex-1 truncate font-medium">{entry.displayName}</span><strong className="text-sm tabular-nums">{entry.totalXp} XP</strong></div>)}{leaders.length === 0 && <p className="py-4 text-sm text-muted-foreground">{user ? (fr ? "Le classement démarre avec les premières parties." : "The leaderboard starts with the first runs.") : (fr ? "Connecte-toi pour voir le classement." : "Sign in to see the leaderboard.")}</p>}</div>{user && <Button asChild variant="ghost" className="mt-3 w-full"><Link to="/$lang/leaderboard" params={{ lang }}>{fr ? "Voir tout le classement" : "View full leaderboard"}<ArrowRight /></Link></Button>}</section>
          </aside>
        </div>
      </div>
    </main>
  );
}

function Metric({ icon: Icon, value, label }: { icon: typeof Flame; value: string; label: string }) {
  return <div className="panel p-4"><Icon className="h-4 w-4 text-primary" /><p className="mt-4 font-display text-3xl tabular-nums">{value}</p><p className="label-mono mt-1">{label}</p></div>;
}