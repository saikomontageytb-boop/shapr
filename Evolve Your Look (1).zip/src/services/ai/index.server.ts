import { createGatewayProvider } from "./providers/lovable-gateway.server";
import type { VisionAnalysisProvider } from "./providers/types";

/**
 * Provider registry. Swap the active provider (or add OpenAI / Claude /
 * a specialised model) without touching any calling code.
 */
const registry: Record<string, () => VisionAnalysisProvider> = {
  "gateway:gemini": () => createGatewayProvider("google/gemini-3.7-flash"),
  "gateway:gpt": () => createGatewayProvider("openai/gpt-5.5"),
};

export function getVisionProvider(): VisionAnalysisProvider {
  const id = process.env["VISION_PROVIDER"] ?? "gateway:gemini";
  const factory = registry[id] ?? registry["gateway:gemini"]!;
  return factory();
}
