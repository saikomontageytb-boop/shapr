import { analysisSchema, type Analysis, type SubjectProfile } from "@/lib/analysis-schema";
import { getVisionProvider } from "./index.server";
import {
  APPEARANCE_SYSTEM_PROMPT,
  APPEARANCE_USER_PROMPT,
  REPAIR_PROMPT,
  subjectProfilePrompt,
} from "./prompts";
import { VisionProviderError } from "./providers/types";

export type AnalyzeOutcome =
  | { ok: true; analysis: Analysis }
  | { ok: false; code: string; message: string };

function extractJson(raw: string): unknown {
  const cleaned = raw
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start === -1 || end === -1) throw new Error("No JSON object in response");
  return JSON.parse(cleaned.slice(start, end + 1));
}

function languageRule(lang: "fr" | "en") {
  return lang === "fr"
    ? "LANGUE\n- Écris TOUS les champs textuels (headline, summary, observation, why_it_matters, recommendation, titres, focus) en français naturel, tutoiement direct. Les clés JSON et les valeurs d'énumération restent en anglais."
    : "LANGUAGE\n- Write every human-readable text field in English.";
}

const IMAGE_ERRORS = new Set(["no_face", "multiple_faces", "low_quality"]);

/** Runs the vision analysis, validates it, repairs once, then fails cleanly. */
export async function analyzeImage(
  imageDataUrl: string,
  lang: "fr" | "en" = "fr",
  profile?: SubjectProfile,
): Promise<AnalyzeOutcome> {
  const provider = getVisionProvider();
  const systemPrompt = [
    APPEARANCE_SYSTEM_PROMPT,
    languageRule(lang),
    profile ? subjectProfilePrompt(profile) : "",
  ]
    .filter(Boolean)
    .join("\n\n");

  try {
    const first = await provider.analyze({
      imageDataUrl,
      systemPrompt,
      userPrompt: APPEARANCE_USER_PROMPT,
    });

    let parsed: unknown;
    try {
      parsed = extractJson(first.text);
    } catch {
      parsed = null;
    }

    const imageError =
      parsed && typeof parsed === "object" && "error" in (parsed as object)
        ? String((parsed as { error: unknown }).error)
        : null;
    if (imageError && IMAGE_ERRORS.has(imageError)) {
      return { ok: false, code: imageError, message: imageError };
    }

    const validated = analysisSchema.safeParse(parsed);
    if (validated.success) return { ok: true, analysis: validated.data };

    // One repair pass with the validation errors fed back to the model.
    const repaired = await provider.analyze({
      imageDataUrl,
      systemPrompt,
      userPrompt: APPEARANCE_USER_PROMPT,
      repair: {
        previous: first.text.slice(0, 8000),
        instruction: `${REPAIR_PROMPT}\nValidation errors: ${JSON.stringify(
          validated.error.issues.slice(0, 12),
        )}`,
      },
    });

    const second = analysisSchema.safeParse(extractJson(repaired.text));
    if (second.success) return { ok: true, analysis: second.data };

    return {
      ok: false,
      code: "unavailable",
      message: "The analysis came back malformed.",
    };
  } catch (err) {
    if (err instanceof VisionProviderError) {
      return { ok: false, code: err.code, message: err.message };
    }
    return { ok: false, code: "unavailable", message: "Analysis failed." };
  }
}
