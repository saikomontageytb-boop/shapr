/**
 * Vision provider abstraction.
 *
 * Any model that can read an image and return text can be plugged in here:
 * OpenAI, Gemini, Claude, a specialised model, or an internal one.
 * The rest of the app only ever talks to this interface.
 */
export interface VisionRequest {
  /** data: URL of the image (never persisted, never logged). */
  imageDataUrl: string;
  systemPrompt: string;
  userPrompt: string;
  /** Previous raw output + repair instruction, when retrying a malformed response. */
  repair?: { previous: string; instruction: string };
}

export interface VisionResponse {
  text: string;
}

export class VisionProviderError extends Error {
  constructor(
    public code:
      | "rate_limited"
      | "credits"
      | "unavailable"
      | "invalid_request"
      | "unauthorized",
    message: string,
  ) {
    super(message);
    this.name = "VisionProviderError";
  }
}

export interface VisionAnalysisProvider {
  id: string;
  model: string;
  analyze(request: VisionRequest): Promise<VisionResponse>;
}
