/**
 * Shared quiz engine used by both the Arena (free runs) and the Daily
 * challenge (5 fixed questions, one attempt a day).
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Check, Flame, Play, Timer, TrendingUp, X, Zap } from "lucide-react";
import wolf from "@/assets/wolf-hero.png";
import mark from "@/assets/wolf-mark.png";
import { levelInfo, levelTitle } from "@/lib/levels";
import {
  multiplierFor,
  narrow,
  scoreFor,
  shuffle,
  type ArenaConfig,
  type ArenaCopy,
  type ArenaQuestion,
  type Difficulty,
} from "@/lib/arena";

export interface Answered {
  question: ArenaQuestion;
  picked: number;
  correct: boolean;
}

export interface OverProps {
  answers: Answered[];
  score: number;
  bestStreak: number;
  eliminated: boolean;
}

export function Aurora() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <div className="grid-noise absolute inset-0 opacity-70" />
      <div className="absolute inset-x-0 top-0 h-px bg-primary/30" />
    </div>
  );
}

/* --------------------------------------------------------------------- run */

export function Run({
  c,
  config,
  difficulty,
  pool,
  onQuit,
  onOver,
}: {
  c: ArenaCopy;
  config: ArenaConfig;
  difficulty: Difficulty;
  pool: ArenaQuestion[];
  onQuit: () => void;
  onOver: (props: OverProps) => void;
}) {
  const seconds = difficulty.seconds;

  const [queue, setQueue] = useState<ArenaQuestion[]>([]);
  const [index, setIndex] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [gain, setGain] = useState<number | null>(null);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [answers, setAnswers] = useState<Answered[]>([]);
  const [left, setLeft] = useState(seconds);
  const [dead, setDead] = useState(false);
  const reported = useRef(false);

  useEffect(() => {
    setQueue(shuffle(pool).map((q) => narrow(q, difficulty.optionCount)));
  }, [pool, difficulty.optionCount]);

  const question = queue[index];
  const total = config.questionCount || 0;

  const finish = useCallback(
    (eliminated = false) => {
      if (reported.current) return;
      reported.current = true;
      onOver({ answers, score, bestStreak, eliminated });
    },
    [onOver, answers, score, bestStreak],
  );

  const answer = useCallback(
    (choice: number) => {
      if (picked !== null || !question) return;
      const correct = choice === question.answer;
      setPicked(choice);
      setAnswers((a) => [...a, { question, picked: choice, correct }]);
      if (correct) {
        const points = scoreFor(streak, left, seconds, difficulty.reward);
        setScore((s) => s + points);
        setGain(points);
        setStreak((s) => {
          const next = s + 1;
          setBestStreak((b) => Math.max(b, next));
          return next;
        });
      } else {
        setGain(null);
        setStreak(0);
        if (difficulty.suddenDeath) setDead(true);
      }
    },
    [picked, question, streak, left, seconds, difficulty.reward, difficulty.suddenDeath],
  );

  // Countdown for the current question.
  useEffect(() => {
    if (picked !== null || seconds === 0) return;
    setLeft(seconds);
    const id = window.setInterval(() => {
      setLeft((v: number) => {
        if (v <= 1) {
          window.clearInterval(id);
          return 0;
        }
        return v - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [index, picked, seconds]);

  useEffect(() => {
    if (seconds > 0 && left === 0 && picked === null && question) answer(-1);
  }, [left, picked, seconds, question, answer]);

  const next = () => {
    if (dead) return finish(true);
    setPicked(null);
    setGain(null);
    setLeft(seconds);
    const upcoming = index + 1;
    if (total > 0 && upcoming >= total) return finish();
    if (upcoming >= queue.length) {
      setQueue((q) => shuffle(q));
      setIndex(0);
      return;
    }
    setIndex(upcoming);
  };

  if (!question) return null;

  const multiplier = multiplierFor(streak);
  const timedOut = picked === -1;
  const good = picked === question.answer;

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* HUD */}
      <div className="panel sticky top-3 z-10 flex items-center gap-2.5 p-3 sm:gap-3">
        <button
          type="button"
          onClick={onQuit}
          aria-label={c.quit}
          className="rounded-full bg-surface-2 p-2 text-muted-foreground transition-colors hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-2">
            <span key={score} className="animate-pop font-display text-xl leading-none tabular-nums sm:text-2xl">
              {score}
            </span>
            <span className="label-mono truncate">{c.score}</span>
            {gain !== null && (
              <span key={`g${index}`} className="animate-float-up text-sm font-semibold text-primary">
                +{gain}
              </span>
            )}
          </div>
          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-500"
              style={{
                width: total > 0 ? `${((index + 1) / total) * 100}%` : `${((index % 10) + 1) * 10}%`,
              }}
            />
          </div>
        </div>
        <div
          className={`flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-bold transition-colors ${
            streak > 0 ? "bg-primary/15 text-primary" : "bg-surface-2 text-muted-foreground"
          }`}
        >
          <Zap className={`h-4 w-4 ${streak > 2 ? "animate-pop" : ""}`} />×{multiplier}
        </div>
      </div>

      {/* Question card */}
      <div key={index} className="panel animate-rise relative overflow-hidden p-5 sm:p-6">
        <div className="flex items-center justify-between gap-3">
          <p className="label-mono truncate text-primary">{question.trackTitle}</p>
          {seconds > 0 && picked === null && (
            <span
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold tabular-nums ${
                left <= 5 ? "bg-destructive/10 text-destructive" : "bg-surface-2 text-muted-foreground"
              }`}
            >
              <Timer className="h-3.5 w-3.5" />
              {left}
              {c.seconds}
            </span>
          )}
        </div>

        <h2 className="mt-3 font-display text-xl leading-snug sm:text-2xl">{question.question}</h2>

        {seconds > 0 && picked === null && (
          <div className="mt-4 h-1 overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-1000 ease-linear"
              style={{ width: `${(left / seconds) * 100}%` }}
            />
          </div>
        )}

        <div className="mt-5 space-y-2.5 sm:space-y-3">
          {question.options.map((option, i) => {
            const isAnswer = i === question.answer;
            const isPicked = picked === i;
            const state =
              picked === null
                ? "bg-surface-2 hover:bg-primary/10 sm:hover:translate-x-1 active:scale-[0.98]"
                : isAnswer
                  ? "bg-primary/15 text-primary ring-1 ring-primary/40 animate-pop"
                  : isPicked
                    ? "bg-destructive/10 text-destructive animate-shake"
                    : "bg-surface-2 text-muted-foreground opacity-50";
            return (
              <button
                key={option}
                type="button"
                disabled={picked !== null}
                onClick={() => answer(i)}
                style={{ animationDelay: `${i * 60}ms` }}
                className={`animate-rise flex w-full items-center gap-3 rounded-2xl px-4 py-3.5 text-left text-sm transition-all sm:px-5 sm:py-4 ${state}`}
              >
                <span className="label-mono shrink-0">{String.fromCharCode(65 + i)}</span>
                <span className="flex-1">{option}</span>
                {picked !== null && isAnswer && <Check className="h-4 w-4 shrink-0" />}
                {picked !== null && isPicked && !isAnswer && <X className="h-4 w-4 shrink-0" />}
              </button>
            );
          })}
        </div>
      </div>

      {/* Verdict */}
      {picked !== null && (
        <div className="panel animate-rise flex gap-4 p-4 sm:p-5">
          <img
            src={mark}
            alt=""
            width={1024}
            height={1024}
            className={`h-12 w-12 shrink-0 sm:h-14 sm:w-14 ${good ? "animate-pop" : "animate-shake"}`}
          />
          <div className="min-w-0">
            <p className={`font-display text-lg ${good ? "text-primary" : "text-foreground"}`}>
              {dead ? c.eliminated : timedOut ? c.timeUp : good ? c.correct : c.wrong}
            </p>
            <p className="mt-1 text-sm text-muted-foreground">{question.explanation}</p>
          </div>
        </div>
      )}

      {picked !== null && (
        <div className="space-y-3">
          <button
            type="button"
            onClick={next}
            className="btn-chunky w-full bg-primary px-6 py-4 font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            {dead ? c.stop : c.next}
          </button>
          {!dead && (
            <button
              type="button"
              onClick={() => finish()}
              className="w-full rounded-2xl px-6 py-3 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              {c.stop}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

/* --------------------------------------------------------------------- end */

export function Over({
  answers,
  score,
  bestStreak,
  eliminated,
  xpBefore,
  xpGain,
  c,
  lang,
  best,
  onAgain,
  onSetup,
  againLabel,
  setupLabel,
}: OverProps & {
  xpBefore: number;
  xpGain: number;
  c: ArenaCopy;
  lang: "fr" | "en";
  best: number;
  /** Omitted on the daily challenge: one attempt a day. */
  onAgain?: () => void;
  onSetup: () => void;
  againLabel?: string;
  setupLabel?: string;
}) {
  const right = answers.filter((a) => a.correct).length;
  const accuracy = answers.length ? Math.round((right / answers.length) * 100) : 0;
  const verdict = accuracy === 100 ? c.perfect : accuracy >= 60 ? c.good : c.meh;
  const record = score > 0 && score >= best;

  const before = levelInfo(xpBefore);
  const after = levelInfo(xpBefore + xpGain);
  const levelUp = after.level > before.level;

  // Animate the XP bar from where the run started to where it ends.
  const [shown, setShown] = useState(before.progress);
  useEffect(() => {
    const id = window.setTimeout(() => setShown(after.progress), 350);
    return () => window.clearTimeout(id);
  }, [after.progress]);

  return (
    <div className="animate-rise space-y-4 sm:space-y-5">
      <div className="panel relative overflow-hidden p-6 text-center sm:p-8">
        <div className="absolute inset-x-0 top-0 h-1 bg-highlight" />
        <img
          src={wolf}
          alt=""
          width={1024}
          height={1024}
          className="animate-float relative mx-auto h-24 w-auto sm:h-28"
        />
        <p className="label-mono relative mt-4">{eliminated ? c.eliminated : c.over}</p>
        <p className="animate-pop relative font-display text-5xl text-primary sm:text-6xl">{score}</p>
        {record && (
          <p className="relative mt-2 inline-flex items-center gap-1.5 rounded-full bg-primary/15 px-3 py-1 text-sm font-semibold text-primary">
            <Flame className="h-4 w-4" />
            {c.newBest}
          </p>
        )}
        <p className="relative mt-4 text-muted-foreground">{verdict}</p>
      </div>

      {/* Progress impact */}
      <div className="panel p-5">
        <div className="flex items-center justify-between gap-3">
          <p className="label-mono flex items-center gap-1.5 text-primary">
            <TrendingUp className="h-3.5 w-3.5" />
            {c.impact}
          </p>
          <p className="animate-pop font-display text-xl text-primary">+{xpGain}</p>
        </div>

        <p className="mt-3 font-semibold">
          {c.level} {after.level}
          <span className="ml-2 font-normal text-muted-foreground">{levelTitle(lang, after.level)}</span>
        </p>
        <div className="mt-2.5 h-2.5 overflow-hidden rounded-full bg-surface-2">
          <div
            className="h-full rounded-full bg-primary transition-[width] duration-1000 ease-out"
            style={{ width: `${shown}%` }}
          />
        </div>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
          <span>
            {xpGain} {c.xpEarned}
          </span>
          {!after.max && (
            <span>
              {after.toNext} XP {c.toNext}
            </span>
          )}
        </div>

        {levelUp && (
          <p className="animate-pop mt-3 inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
            <Zap className="h-4 w-4" />
            {c.levelUp} {after.level}
          </p>
        )}
      </div>

      <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
        {[
          { value: `${right}/${answers.length}`, label: c.right },
          { value: `${accuracy}%`, label: c.accuracy },
          { value: String(bestStreak), label: c.bestStreak },
        ].map((s) => (
          <div key={s.label} className="panel p-3 text-center sm:p-4">
            <p className="font-display text-xl sm:text-2xl">{s.value}</p>
            <p className="label-mono mt-1 leading-tight">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        {answers.map((a, i) => (
          <div
            key={`${a.question.id}-${i}`}
            className="flex items-center gap-3 rounded-2xl bg-surface-2 px-4 py-3 text-sm"
          >
            {a.correct ? (
              <Check className="h-4 w-4 shrink-0 text-primary" />
            ) : (
              <X className="h-4 w-4 shrink-0 text-destructive" />
            )}
            <span className="min-w-0 flex-1 truncate text-muted-foreground">{a.question.question}</span>
          </div>
        ))}
      </div>

      {onAgain && (
        <button
          type="button"
          onClick={onAgain}
          className="btn-chunky flex w-full items-center justify-center gap-2 bg-primary px-6 py-4 font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          <Play className="h-4 w-4" />
          {againLabel ?? c.again}
        </button>
      )}
      <button
        type="button"
        onClick={onSetup}
        className="w-full rounded-2xl bg-surface-2 px-6 py-3 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        {setupLabel ?? c.change}
      </button>
      <Link
        to="/$lang/academy"
        params={{ lang }}
        className="label-mono flex items-center justify-center gap-1.5 pt-2 transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        {c.backAcademy}
      </Link>
    </div>
  );
}
