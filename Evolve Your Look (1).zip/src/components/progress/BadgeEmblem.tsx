import { LockKeyhole } from "lucide-react";
import { cn } from "@/lib/utils";
import type { BadgeDefinition } from "@/lib/badges";

const tierStyles = {
  bronze: "bg-warning/15 text-warning ring-warning/30",
  silver: "bg-chart-2/15 text-chart-2 ring-chart-2/30",
  gold: "bg-highlight/25 text-foreground ring-highlight/60",
};

export function BadgeEmblem({ badge, unlocked, compact = false, lang }: { badge: BadgeDefinition; unlocked: boolean; compact?: boolean; lang: "fr" | "en" }) {
  const Icon = badge.icon;
  const copy = badge[lang];
  return (
    <div className={cn("group flex min-w-0 items-center gap-3", compact ? "p-2" : "p-3")} title={copy.detail}>
      <div className={cn("relative grid shrink-0 place-items-center rounded-md ring-1 transition-transform group-hover:-translate-y-0.5", compact ? "h-10 w-10" : "h-12 w-12", unlocked ? tierStyles[badge.tier] : "bg-surface-2 text-muted-foreground/50 ring-border")}>
        {unlocked ? <Icon className="h-5 w-5" /> : <LockKeyhole className="h-4 w-4" />}
        <span className="absolute -bottom-1 h-1 w-5 rounded-full bg-current opacity-40" />
      </div>
      <div className="min-w-0">
        <p className={cn("truncate font-semibold", !unlocked && "text-muted-foreground")}>{copy.title}</p>
        {!compact && <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{copy.detail}</p>}
      </div>
    </div>
  );
}