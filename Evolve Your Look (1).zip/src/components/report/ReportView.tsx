import { Link } from "@tanstack/react-router";
import { useReportCopy } from "@/lib/report-copy";
import { Lock } from "lucide-react";
import { useLang } from "@/lib/use-lang";
import type { Access } from "@/lib/access";
import type { Analysis, ScanRecord } from "@/lib/analysis-schema";
import { CategoryDetail, CategoryStats } from "./CategoryStats";
import { FaceMap } from "./FaceMap";
import { ProgressPanel } from "./ProgressPanel";
import { ProtocolStack } from "./ProtocolStack";
import { QuestPath } from "./QuestPath";
import { ScoreHero } from "./ScoreHero";
import { TopUpgrades } from "./TopUpgrades";
import { TransformationLab } from "./TransformationLab";

export function ReportView({
  analysis,
  access = "pro",
  completed = [],
  onToggleQuest,
  xp = 0,
  achievements = [],
  scans = [],
  interactive = true,
  photo,
}: {
  analysis: Analysis;
  access?: Access;
  completed?: string[];
  onToggleQuest?: ((id: string) => void) | undefined;
  xp?: number;
  achievements?: string[];
  scans?: ScanRecord[];
  interactive?: boolean;
  photo?: string | undefined;
}) {
  const c = useReportCopy();

  return (
    <div className="space-y-12">
      <ScoreHero analysis={analysis} blurred={access === "anon"} />

      {access === "anon" && <SignupWall />}
      {access === "free" && <Paywall />}

      {access === "pro" && (
        <>
          <section>
            <h2 className="font-display text-3xl sm:text-4xl">{c.categoryScores}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{c.categoryScoresIntro}</p>
            <div className="mt-6">
              <CategoryStats categories={analysis.categories} />
            </div>
          </section>

          <TopUpgrades upgrades={analysis.priority_actions} />

          <FaceMap
            annotations={analysis.annotations ?? []}
            photo={photo}
            completed={(analysis.annotations ?? [])
              .filter((a) => completed.includes(`lesson:${a.id}`))
              .map((a) => a.id)}
            onComplete={
              onToggleQuest ? (id) => onToggleQuest(`lesson:${id}`) : undefined
            }
            interactive={interactive}
          />

          <section>
            <h2 className="font-display text-3xl sm:text-4xl">{c.detailed}</h2>
            <div className="mt-6 grid gap-4 lg:grid-cols-2">
              {analysis.categories.map((cat) => (
                <CategoryDetail key={cat.key} category={cat} />
              ))}
            </div>
          </section>

          {interactive && (
            <ProgressPanel
              xp={xp}
              completed={completed.length}
              achievements={achievements}
              scans={scans}
              analysis={analysis}
            />
          )}
          <QuestPath
            roadmap={analysis.roadmap}
            completed={completed}
            onToggle={onToggleQuest}
            interactive={interactive}
          />
          <ProtocolStack protocols={analysis.protocols ?? []} />
          <TransformationLab analysis={analysis} />
          <section className="panel p-6 text-sm text-muted-foreground">
            <p className="label-mono">{c.readThis}</p>
            <p className="mt-2">{c.disclaimer}</p>
          </section>
        </>
      )}
    </div>
  );
}

const SIGNUP = {
  fr: {
    label: "Scan terminé — gratuit",
    title: "Crée ton compte pour voir ta note",
    body: "Le scan ne coûte rien et tu peux le refaire autant que tu veux. Un compte gratuit affiche ta note globale et ton potentiel d'amélioration, et garde l'historique de tes scans.",
    cta: "Créer mon compte gratuit",
    already: "J'ai déjà un compte",
  },
  en: {
    label: "Scan complete — free",
    title: "Create your account to see your score",
    body: "Scanning is free and you can redo it as often as you like. A free account shows your overall score and improvement potential, and keeps your scan history.",
    cta: "Create my free account",
    already: "I already have an account",
  },
} as const;

function SignupWall() {
  const lang = useLang();
  const copy = SIGNUP[lang];
  return (
    <section className="panel relative overflow-hidden p-6 sm:p-10">
      <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-primary/15 blur-3xl" />
      <div className="relative max-w-2xl">
        <p className="label-mono">{copy.label}</p>
        <h2 className="mt-2 font-display text-3xl sm:text-4xl">{copy.title}</h2>
        <p className="mt-3 text-sm text-muted-foreground">{copy.body}</p>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <Link
            to="/$lang/auth"
            params={{ lang }}
            className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            {copy.cta}
          </Link>
          <Link
            to="/$lang/auth"
            params={{ lang }}
            className="rounded-full bg-surface-2 px-6 py-3 text-sm font-medium transition-colors hover:text-primary"
          >
            {copy.already}
          </Link>
        </div>
      </div>
    </section>
  );
}


const PAYWALL = {
  fr: {
    label: "Note débloquée",
    title: "Passe à l'abonnement pour savoir quoi améliorer",
    body: "Tu vois ta note et ton potentiel. L'abonnement ouvre la carte de ton visage point par point, les leçons liées à chaque point, le plan d'amélioration complet et les re-scans illimités.",
    features: [
      "Carte du visage avec une branche par point",
      "La leçon qui règle chaque point",
      "Les 12 catégories détaillées",
      "Top 3 des améliorations à fort impact",
      "Parcours en 3 niveaux avec XP",
      "Scans et re-scans illimités",
    ],
    cta: "Voir l'abonnement",
    example: "Voir d'abord un exemple",
    note: "Le paiement par carte n'est pas encore branché : l'accès s'active localement pour que tu puisses parcourir toute l'expérience.",
  },
  en: {
    label: "Score unlocked",
    title: "Subscribe to see what to improve",
    body: "You can see your score and your potential. The subscription opens the point-by-point face map, the lesson behind every point, the full upgrade plan and unlimited re-scans.",
    features: [
      "Face map with a branch per point",
      "The lesson that fixes each point",
      "All 12 category breakdowns",
      "Top 3 highest-impact upgrades",
      "3-level upgrade path with XP",
      "Unlimited scans and re-scans",
    ],
    cta: "See the subscription",
    example: "See an example first",
    note: "Card payments are not wired up yet — access is enabled locally so you can walk the full experience.",
  },
} as const;

function Paywall() {
  const lang = useLang();
  const copy = PAYWALL[lang];

  return (
    <section className="panel relative overflow-hidden p-6 sm:p-10">
      <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-primary/15 blur-3xl" />
      <div className="relative max-w-2xl">
        <p className="label-mono">{copy.label}</p>
        <h2 className="mt-2 font-display text-3xl sm:text-4xl">{copy.title}</h2>
        <p className="mt-3 text-sm text-muted-foreground">{copy.body}</p>
        <ul className="mt-6 grid gap-2 text-sm sm:grid-cols-2">
          {copy.features.map((f) => (
            <li key={f} className="flex items-center gap-2 text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              {f}
            </li>
          ))}
        </ul>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <Link
            to="/$lang/pro"
            params={{ lang }}
            className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
          >
            {copy.cta}
          </Link>
          <Link
            to="/$lang/example"
            params={{ lang }}
            className="rounded-full bg-surface-2 px-6 py-3 text-sm font-medium transition-colors hover:text-primary"
          >
            {copy.example}
          </Link>
        </div>
        <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <Lock className="h-3.5 w-3.5" />
          {copy.note}
        </p>
      </div>
    </section>
  );
}

