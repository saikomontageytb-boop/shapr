import { useEffect, useState } from "react";
import { useReportCopy } from "@/lib/report-copy";
import type { Analysis } from "@/lib/analysis-schema";

function useCountUp(target: number, duration = 1100) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    let frame = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setValue(target * eased);
      if (t < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [target, duration]);
  return value;
}

export function ScoreDial({
  score,
  size = 220,
  label = "out of 10",
}: {
  score: number;
  size?: number;
  label?: string;
}) {
  const animated = useCountUp(score);
  const r = size / 2 - 14;
  const c = 2 * Math.PI * r;
  const offset = c - (animated / 10) * c * 0.75;

  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-[135deg]" aria-hidden="true">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="var(--surface-2)"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={`${c * 0.75} ${c}`}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke="var(--primary)"
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={`${c * 0.75} ${c}`}
          strokeDashoffset={offset}
          style={{ filter: "drop-shadow(0 0 12px oklch(0.87 0.2 124 / 0.5))" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-6xl font-bold tabular-nums text-glow">
          {animated.toFixed(1)}
        </span>
        <span className="label-mono mt-1">{label}</span>
      </div>
    </div>
  );
}

export function ScoreHero({
  analysis,
  blurred = false,
}: {
  analysis: Analysis;
  blurred?: boolean;
}) {
  const c = useReportCopy();
  const potential = useCountUp(analysis.potential_score, 1400);
  const gap = analysis.potential_score - analysis.overall_score;

  return (
    <section
      className={`panel grid gap-10 p-6 sm:p-10 md:grid-cols-[auto_1fr] md:items-center ${
        blurred ? "pointer-events-none select-none blur-md" : ""
      }`}
      aria-hidden={blurred || undefined}
    >
      <div className="flex justify-center">
        <ScoreDial score={analysis.overall_score} label={c.outOf} />
      </div>
      <div className="space-y-6">
        <div>
          <p className="label-mono">{c.profile}</p>
          <h1 className="mt-2 font-display text-3xl font-bold sm:text-4xl">
            {analysis.headline}
          </h1>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground">
            {analysis.summary}
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-border bg-surface-2/60 p-4">
            <p className="label-mono">{c.percentile}</p>
            <p className="mt-1 font-display text-2xl font-bold tabular-nums">
              {analysis.percentile}
              <span className="text-base text-muted-foreground">{c.percentileSuffix}</span>
            </p>
          </div>
          <div className="rounded-xl border border-primary/25 bg-primary/5 p-4">
            <p className="label-mono">{c.potential}</p>
            <p className="mt-1 font-display text-2xl font-bold tabular-nums text-primary">
              {potential.toFixed(1)}
              <span className="ml-2 text-sm font-medium text-muted-foreground">
                +{gap.toFixed(1)}
              </span>
            </p>
          </div>
        </div>

        <div className="h-2 overflow-hidden rounded-full bg-surface-2">
          <div
            className="h-full rounded-full bg-gradient-to-r from-accent to-primary transition-[width] duration-1000"
            style={{ width: `${(analysis.potential_score / 10) * 100}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground">
          {c.potentialNote}
        </p>
      </div>
    </section>
  );
}
