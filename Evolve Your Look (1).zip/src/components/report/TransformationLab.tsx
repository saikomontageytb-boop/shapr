import type { Analysis } from "@/lib/analysis-schema";
import { useReportCopy } from "@/lib/report-copy";
import { Scissors, Glasses, Shirt, Sparkles } from "lucide-react";

/**
 * Transformation directions.
 *
 * Deliberately NOT fake image generation. Each track renders the concrete
 * direction the analysis produced. When a real image-editing provider is
 * configured, it plugs in behind this component through the same track shape.
 */
type Track = {
  id: "hair" | "eyewear" | "facial_hair" | "style";
  icon: typeof Scissors;
  categories: Array<Analysis["categories"][number]["key"]>;
};

const TRACKS: Track[] = [
  { id: "hair", icon: Scissors, categories: ["hair"] },
  { id: "eyewear", icon: Glasses, categories: ["eyewear"] },
  { id: "facial_hair", icon: Sparkles, categories: ["facial_hair"] },
  { id: "style", icon: Shirt, categories: ["style"] },
];

export function TransformationLab({ analysis }: { analysis: Analysis }) {
  const c = useReportCopy();
  return (
    <section>
      <h2 className="font-display text-3xl sm:text-4xl">{c.tracks}</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        {c.tracksIntro}
      </p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {TRACKS.map((track) => {
          const cat = analysis.categories.find((c) => track.categories.includes(c.key));
          const Icon = track.icon;
          return (
            <article key={track.id} className="panel p-5">
              <header className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-primary/25 bg-primary/10">
                  <Icon className="h-4 w-4 text-primary" />
                </span>
                <h3 className="font-semibold">{c.trackLabels[track.id]}</h3>
                {cat && (
                  <span className="label-mono ml-auto tabular-nums">
                    {cat.score.toFixed(1)}
                  </span>
                )}
              </header>
              <p className="mt-4 text-sm text-foreground/90">
                {cat?.recommendation ?? c.nothingToChange}
              </p>
            </article>
          );
        })}
      </div>
    </section>
  );
}
