import { type RoadmapLevel } from "@/lib/analysis-schema";
import { useReportCopy } from "@/lib/report-copy";
import { useCategoryLabels } from "@/lib/use-lang";
import { Check } from "lucide-react";

export function QuestPath({
  roadmap,
  completed,
  onToggle,
  interactive = true,
}: {
  roadmap: RoadmapLevel[];
  completed: string[];
  onToggle?: ((id: string) => void) | undefined;
  interactive?: boolean | undefined;
}) {
  const labels = useCategoryLabels();
  const c = useReportCopy();
  return (
    <section>
      <h2 className="font-display text-3xl sm:text-4xl">{c.upgradePath}</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        {c.upgradePathIntro}
      </p>

      <div className="mt-6 space-y-4">
        {roadmap.map((level) => {
          const done = level.quests.filter((q) => completed.includes(q.id)).length;
          const pct = Math.round((done / level.quests.length) * 100);
          return (
            <div key={level.level} className="panel p-5 sm:p-6">
              <header className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <p className="label-mono">
                    {c.level} {String(level.level).padStart(2, "0")}
                  </p>
                  <h3 className="font-display text-xl font-bold tracking-tight">
                    {level.title}
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">{level.focus}</p>
                </div>
                <span className="label-mono tabular-nums">
                  {done}/{level.quests.length} {c.done}
                </span>
              </header>

              <div className="mt-4 h-1 overflow-hidden rounded-full bg-surface-2">
                <div
                  className="h-full rounded-full bg-primary transition-[width] duration-500"
                  style={{ width: `${pct}%` }}
                />
              </div>

              <ul className="mt-5 space-y-2">
                {level.quests.map((q) => {
                  const isDone = completed.includes(q.id);
                  const Row = interactive ? "button" : "div";
                  return (
                    <li key={q.id}>
                      <Row
                        {...(interactive
                          ? {
                              type: "button" as const,
                              onClick: () => onToggle?.(q.id),
                              "aria-pressed": isDone,
                            }
                          : {})}
                        className={`flex w-full items-center gap-3 rounded-xl border px-4 py-3 text-left transition-all ${
                          isDone
                            ? "border-primary/40 bg-primary/5"
                            : "border-border bg-surface-2/50 hover:border-primary/30"
                        }`}
                      >
                        <span
                          className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md border ${
                            isDone
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-border"
                          }`}
                          aria-hidden="true"
                        >
                          {isDone && <Check className="h-3.5 w-3.5" />}
                        </span>
                        <span
                          className={`flex-1 text-sm font-medium ${
                            isDone ? "text-muted-foreground line-through" : ""
                          }`}
                        >
                          {q.title}
                        </span>
                        <span className="hidden label-mono sm:inline">
                          {labels[q.category]}
                        </span>
                        <span className="label-mono">{q.difficulty}</span>
                        <span className="label-mono text-primary tabular-nums">
                          +{q.xp} XP
                        </span>
                      </Row>
                    </li>
                  );
                })}
              </ul>
            </div>
          );
        })}
      </div>
    </section>
  );
}
