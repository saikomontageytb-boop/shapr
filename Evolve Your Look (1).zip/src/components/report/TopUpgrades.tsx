import { type Upgrade } from "@/lib/analysis-schema";
import { useReportCopy } from "@/lib/report-copy";
import { useCategoryLabels } from "@/lib/use-lang";
import { ArrowUpRight } from "lucide-react";

export function TopUpgrades({ upgrades }: { upgrades: Upgrade[] }) {
  const labels = useCategoryLabels();
  const c = useReportCopy();
  return (
    <section>
      <h2 className="font-display text-3xl sm:text-4xl">{c.topUpgrades}</h2>
      <p className="mt-2 text-sm text-muted-foreground">
        {c.topUpgradesIntro}
      </p>

      <ol className="mt-6 space-y-3">
        {upgrades.map((u, i) => (
          <li
            key={u.title}
            className="panel group relative flex flex-col gap-4 p-5 transition-colors hover:border-primary/40 sm:flex-row sm:items-center sm:gap-6"
          >
            <span className="font-display text-4xl font-bold text-primary/40 transition-colors group-hover:text-primary sm:text-5xl">
              #{i + 1}
            </span>
            <div className="flex-1">
              <div className="flex flex-wrap items-center gap-3">
                <h3 className="text-lg font-semibold">{u.title}</h3>
                <span className="label-mono rounded-md border border-border bg-surface-2 px-2 py-1">
                  {labels[u.category]}
                </span>
                <span
                  className={`label-mono rounded-md px-2 py-1 ${
                    u.impact === "high"
                      ? "bg-primary/15 text-primary"
                      : "bg-surface-2 text-muted-foreground"
                  }`}
                >
                  {c.impact[u.impact]}
                </span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{u.why}</p>
              <p className="mt-2 flex items-start gap-2 text-sm text-foreground/90">
                <ArrowUpRight className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                {u.action}
              </p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
