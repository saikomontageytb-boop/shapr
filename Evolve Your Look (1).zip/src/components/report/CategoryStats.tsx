import { type Category } from "@/lib/analysis-schema";
import { useReportCopy } from "@/lib/report-copy";
import { useCategoryLabels } from "@/lib/use-lang";
import { Lock } from "lucide-react";

const PRIORITY_STYLES: Record<string, string> = {
  high: "border-primary/40 bg-primary/10 text-primary",
  medium: "border-warning/40 bg-warning/10 text-warning",
  low: "border-border bg-surface-2 text-muted-foreground",
};

export function PriorityTag({ priority }: { priority: string }) {
  const c = useReportCopy();
  return (
    <span
      className={`label-mono rounded-md border px-2 py-1 ${PRIORITY_STYLES[priority] ?? PRIORITY_STYLES["low"]}`}
    >
      {priority} {c.priority}
    </span>
  );
}

export function CategoryStats({
  categories,
  lockedFrom,
}: {
  categories: Category[];
  lockedFrom?: number | undefined;
}) {
  const labels = useCategoryLabels();
  return (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {categories.map((c, i) => {
        const locked = lockedFrom !== undefined && i >= lockedFrom;
        return (
          <div
            key={c.key}
            className="panel relative overflow-hidden p-4"
            style={{ animationDelay: `${i * 40}ms` }}
          >
            <div className="flex items-baseline justify-between">
              <span className="label-mono">{labels[c.key]}</span>
              <span className="font-display text-2xl font-bold tabular-nums">
                {locked ? "—" : c.score.toFixed(1)}
              </span>
            </div>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-surface-2">
              <div
                className="h-full rounded-full bg-gradient-to-r from-accent to-primary transition-[width] duration-700"
                style={{ width: locked ? "0%" : `${c.score * 10}%` }}
              />
            </div>
            {locked && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/70 backdrop-blur-[3px]">
                <Lock className="h-4 w-4 text-muted-foreground" />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export function CategoryDetail({ category }: { category: Category }) {
  const labels = useCategoryLabels();
  const c = useReportCopy();
  return (
    <details className="panel group p-5 sm:p-6 [&_summary::-webkit-details-marker]:hidden">
      <summary className="flex cursor-pointer list-none items-center gap-4">
        <span className="font-display text-2xl font-bold tabular-nums">
          {category.score.toFixed(1)}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-base font-semibold">
            {labels[category.key]}
          </span>
          <span className="mt-2 block h-1 overflow-hidden rounded-full bg-surface-2">
            <span
              className="block h-full rounded-full bg-primary/70"
              style={{ width: `${category.score * 10}%` }}
            />
          </span>
        </span>
        <span className="text-muted-foreground transition-transform group-open:rotate-45">
          +
        </span>
      </summary>

      <div className="mt-5 flex flex-wrap items-center gap-2">
        {category.fixed_trait && (
          <span className="label-mono rounded-md border border-accent/40 bg-accent/10 px-2 py-1 text-accent">
            {c.structural}
          </span>
        )}
        <PriorityTag priority={category.priority} />
      </div>

      <dl className="mt-4 space-y-4 text-sm">
        <div>
          <dt className="label-mono">{c.observation}</dt>
          <dd className="mt-1 text-foreground/90">{category.observation}</dd>
        </div>
        <div>
          <dt className="label-mono">{c.whyMatters}</dt>
          <dd className="mt-1 text-muted-foreground">{category.why_it_matters}</dd>
        </div>
        <div>
          <dt className="label-mono">
            {category.fixed_trait ? c.presentAround : c.recommendation}
          </dt>
          <dd className="mt-1 text-foreground/90">{category.recommendation}</dd>
        </div>
      </dl>
    </details>
  );
}

