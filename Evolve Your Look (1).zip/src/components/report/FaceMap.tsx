import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import type { Annotation } from "@/lib/analysis-schema";
import { trackForCategory } from "@/lib/category-track";
import { useLooksmaxCopy } from "@/lib/looksmax-copy";
import { useReportCopy } from "@/lib/report-copy";
import { useCategoryLabels, useLang } from "@/lib/use-lang";
import { ArrowRight, Check, X } from "lucide-react";

const SEVERITY_RING = {
  high: "border-primary bg-primary/25",
  medium: "border-accent bg-accent/20",
  low: "border-border bg-surface-2",
} as const;

/** Neutral face guide used when the photo is no longer in memory. */
function FaceGuide() {
  return (
    <svg
      viewBox="0 0 300 380"
      className="h-full w-full text-foreground/15"
      aria-hidden="true"
    >
      <ellipse cx="150" cy="180" rx="105" ry="140" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <path d="M45 150 Q150 120 255 150" fill="none" stroke="currentColor" strokeWidth="1" />
      <path d="M60 300 Q150 355 240 300" fill="none" stroke="currentColor" strokeWidth="1" />
      <line x1="150" y1="45" x2="150" y2="320" stroke="currentColor" strokeWidth="0.75" strokeDasharray="4 6" />
      <ellipse cx="105" cy="165" rx="22" ry="11" fill="none" stroke="currentColor" strokeWidth="1" />
      <ellipse cx="195" cy="165" rx="22" ry="11" fill="none" stroke="currentColor" strokeWidth="1" />
      <path d="M135 195 Q150 235 165 230" fill="none" stroke="currentColor" strokeWidth="1" />
      <path d="M120 268 Q150 280 180 268" fill="none" stroke="currentColor" strokeWidth="1" />
    </svg>
  );
}

/** Geometry of the branch diagram, in percent of the drawing box. */
const PHOTO_LEFT = 27;
const PHOTO_WIDTH = 46;
const ELBOW_LEFT = 24;
const ELBOW_RIGHT = 76;

type Branch = {
  a: Annotation;
  side: "left" | "right";
  px: number;
  py: number;
  ey: number;
};

function layout(annotations: Annotation[]): Branch[] {
  // Split by horizontal position but keep the two columns balanced, so the
  // branches fan out evenly instead of piling up on one side.
  const byX = [...annotations].sort((m, n) => m.x - n.x);
  const half = Math.ceil(byX.length / 2);
  const sides: Record<"left" | "right", Annotation[]> = {
    left: byX.slice(0, half),
    right: byX.slice(half),
  };

  const out: Branch[] = [];
  for (const side of ["left", "right"] as const) {
    const list = [...sides[side]].sort((m, n) => m.y - n.y);
    list.forEach((a, i) => {
      out.push({
        a,
        side,
        px: PHOTO_LEFT + (a.x / 100) * PHOTO_WIDTH,
        py: a.y,
        ey: list.length === 1 ? 50 : 10 + ((i + 0.5) / list.length) * 80,
      });
    });
  }
  return out;
}

export function FaceMap({
  annotations,
  photo,
  completed = [],
  onComplete,
  interactive = true,
}: {
  annotations: Annotation[];
  photo?: string | undefined;
  completed?: string[];
  onComplete?: ((id: string, xp: number) => void) | undefined;
  interactive?: boolean;
}) {
  const c = useLooksmaxCopy();
  const lang = useLang();
  const fr = lang === "fr";
  const [openId, setOpenId] = useState<string | null>(null);
  const open = annotations.find((a) => a.id === openId) ?? null;

  if (!annotations.length) return null;

  const branches = layout(annotations);

  return (
    <section>
      <h2 className="font-display text-3xl sm:text-4xl">{c.mapTitle}</h2>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{c.mapIntro}</p>
      <p className="mt-1 text-sm text-muted-foreground">
        {fr
          ? "Tire sur une branche : elle t'emmène droit dans le module qui règle ce point."
          : "Pull a branch: it drops you into the module that fixes that point."}
      </p>

      <div className="panel mt-6 p-3 sm:p-5">
        <div className="relative mx-auto aspect-[8/5] w-full max-w-[620px]">
          {/* Branch lines */}
          <svg
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            className="absolute inset-0 h-full w-full text-primary/45"
            aria-hidden="true"
          >
            {branches.map((b) => {
              const ex = b.side === "left" ? ELBOW_LEFT : ELBOW_RIGHT;
              return (
                <polyline
                  key={b.a.id}
                  points={`${b.px},${b.py} ${ex},${b.ey} ${
                    b.side === "left" ? ex - 3 : ex + 3
                  },${b.ey}`}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.25"
                  strokeLinejoin="round"
                  vectorEffect="non-scaling-stroke"
                />
              );
            })}
          </svg>

          {/* Photo */}
          <div
            className="absolute inset-y-0 overflow-hidden rounded-[1.4rem] bg-surface-2"
            style={{ left: `${PHOTO_LEFT}%`, width: `${PHOTO_WIDTH}%` }}
          >
            {photo ? (
              <img src={photo} alt="" className="h-full w-full object-cover" />
            ) : (
              <FaceGuide />
            )}
          </div>

          {/* Points */}
          {branches.map((b) => {
            const done = completed.includes(b.a.id);
            return (
              <button
                key={`dot-${b.a.id}`}
                type="button"
                onClick={() => setOpenId(b.a.id)}
                aria-label={b.a.label}
                style={{ left: `${b.px}%`, top: `${b.py}%` }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 rounded-full border-2 backdrop-blur-sm transition-transform hover:scale-125 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ${
                  done ? "border-primary bg-primary text-primary-foreground" : SEVERITY_RING[b.a.severity]
                }`}
              >
                <span className="flex h-5 w-5 items-center justify-center sm:h-6 sm:w-6">
                  {done ? <Check className="h-3 w-3" /> : null}
                </span>
              </button>
            );
          })}

          {/* Branch labels — each one is a door into the academy path */}
          {branches.map((b) => (
            <Link
              key={`chip-${b.a.id}`}
              to="/$lang/academy/$track"
              params={{ lang, track: trackForCategory(b.a.category) }}
              style={
                b.side === "left"
                  ? { right: `${100 - ELBOW_LEFT + 2}%`, top: `${b.ey}%` }
                  : { left: `${ELBOW_RIGHT + 2}%`, top: `${b.ey}%` }
              }
              className={`absolute w-[21%] -translate-y-1/2 rounded-xl bg-surface px-2 py-1.5 text-left text-[10px] font-semibold leading-tight shadow-[var(--shadow-panel)] transition-colors hover:text-primary sm:text-xs ${
                b.side === "left" ? "text-right" : ""
              }`}
            >
              {b.a.label}
            </Link>
          ))}
        </div>
      </div>

      <ul className="mt-6 space-y-2">
        <li className="label-mono">{c.mapPoints(annotations.length)}</li>
        {annotations.map((a) => (
          <li key={a.id}>
            <button
              type="button"
              onClick={() => setOpenId(a.id)}
              className="panel flex w-full items-center gap-3 p-4 text-left transition-colors hover:border-primary/40"
            >
              <span
                className={`h-2.5 w-2.5 shrink-0 rounded-full border-2 ${SEVERITY_RING[a.severity]}`}
              />
              <span className="flex-1">
                <span className="font-semibold">{a.label}</span>
                <span className="mt-1 block text-sm text-muted-foreground">{a.fix}</span>
              </span>
              <span className="label-mono shrink-0">
                {completed.includes(a.id) ? <Check className="h-4 w-4 text-primary" /> : `+${a.xp}`}
              </span>
            </button>
          </li>
        ))}
      </ul>

      {!photo && (
        <p className="mt-3 text-xs text-muted-foreground">{c.mapNoPhoto}</p>
      )}

      {open && (
        <LessonModal
          annotation={open}
          done={completed.includes(open.id)}
          interactive={interactive}
          onComplete={onComplete}
          onClose={() => setOpenId(null)}
        />
      )}
    </section>
  );
}

function LessonModal({
  annotation,
  done,
  interactive,
  onComplete,
  onClose,
}: {
  annotation: Annotation;
  done: boolean;
  interactive: boolean;
  onComplete?: ((id: string, xp: number) => void) | undefined;
  onClose: () => void;
}) {
  const c = useLooksmaxCopy();
  const r = useReportCopy();
  const lang = useLang();
  const labels = useCategoryLabels();
  const [step, setStep] = useState(0);
  const [picked, setPicked] = useState<number | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const { lesson } = annotation;
  const total = lesson.steps.length + 1; // steps + quiz
  const isQuiz = step === lesson.steps.length;
  const correct = picked === lesson.quiz.answer_index;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={lesson.title}
      className="fixed inset-0 z-50 flex items-end justify-center bg-background/80 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="panel max-h-[90vh] w-full max-w-2xl overflow-y-auto p-6 sm:p-8"
      >
        <div className="flex items-start gap-4">
          <div className="flex-1">
            <p className="label-mono">
              {labels[annotation.category]} · {r.impact[annotation.severity]}
            </p>
            <h3 className="mt-2 font-display text-2xl sm:text-3xl">{lesson.title}</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={c.close}
            className="soft rounded-full p-2 transition-colors hover:text-primary"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-5 grid gap-3 sm:grid-cols-2">
          <p className="soft rounded-2xl p-4 text-sm">
            <span className="label-mono block">{c.observation}</span>
            <span className="mt-1 block text-muted-foreground">{annotation.observation}</span>
          </p>
          <p className="soft rounded-2xl p-4 text-sm">
            <span className="label-mono block">{c.fix}</span>
            <span className="mt-1 block text-muted-foreground">{annotation.fix}</span>
          </p>
        </div>

        <div className="mt-6 flex gap-1.5">
          {Array.from({ length: total }).map((_, i) => (
            <span
              key={i}
              className={`h-1 flex-1 rounded-full transition-colors ${
                i <= step ? "bg-primary" : "bg-surface-2"
              }`}
            />
          ))}
        </div>

        {!isQuiz ? (
          <div className="mt-6">
            <p className="label-mono">
              {c.lessonStep} {step + 1}
            </p>
            <h4 className="mt-2 text-lg font-semibold">{lesson.steps[step]?.title}</h4>
            <p className="mt-2 text-sm text-muted-foreground">{lesson.steps[step]?.body}</p>
            <p className="mt-5 text-sm text-foreground/90">
              <span className="label-mono mr-2">{c.tip}</span>
              {lesson.tip}
            </p>
          </div>
        ) : (
          <div className="mt-6">
            <p className="label-mono">{c.quizTitle}</p>
            <h4 className="mt-2 text-lg font-semibold">{lesson.quiz.question}</h4>
            <ul className="mt-4 space-y-2">
              {lesson.quiz.options.map((opt, i) => {
                const state =
                  picked === null
                    ? "soft"
                    : i === lesson.quiz.answer_index
                      ? "bg-primary/15 text-primary"
                      : i === picked
                        ? "bg-destructive/15 text-destructive"
                        : "soft opacity-60";
                return (
                  <li key={opt}>
                    <button
                      type="button"
                      disabled={picked !== null}
                      onClick={() => setPicked(i)}
                      className={`w-full rounded-2xl px-4 py-3 text-left text-sm transition-colors ${state}`}
                    >
                      {opt}
                    </button>
                  </li>
                );
              })}
            </ul>
            {picked !== null && (
              <p className="mt-4 text-sm text-muted-foreground">
                <span className="mr-1 font-semibold text-foreground">
                  {correct ? c.quizCorrect : c.quizWrong}
                </span>
                {lesson.quiz.explanation}
              </p>
            )}
          </div>
        )}

        <div className="mt-8 flex flex-wrap items-center gap-3">
          {step > 0 && (
            <button
              type="button"
              onClick={() => setStep((s) => s - 1)}
              className="soft rounded-full px-5 py-3 text-sm font-medium transition-colors hover:text-primary"
            >
              {c.prev}
            </button>
          )}
          {!isQuiz ? (
            <button
              type="button"
              onClick={() => setStep((s) => s + 1)}
              className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110"
            >
              {c.next}
            </button>
          ) : done || !interactive ? (
            <span className="label-mono flex items-center gap-2 text-primary">
              <Check className="h-4 w-4" />
              {c.claimed}
            </span>
          ) : (
            <button
              type="button"
              disabled={picked === null || !correct}
              onClick={() => {
                onComplete?.(annotation.id, annotation.xp);
                onClose();
              }}
              className="rounded-full bg-primary px-6 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-40"
            >
              {c.claim(annotation.xp)}
            </button>
          )}
        </div>

        <Link
          to="/$lang/academy/$track"
          params={{ lang, track: trackForCategory(annotation.category) }}
          className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary"
        >
          {lang === "fr" ? "Continuer dans l'Académie" : "Continue in the Academy"}
          <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    </div>
  );
}
