import type { Protocol } from "@/lib/analysis-schema";
import { useLooksmaxCopy } from "@/lib/looksmax-copy";
import { Apple, Dumbbell, Moon, Droplets, Activity, PersonStanding } from "lucide-react";

const ICONS = {
  nutrition: Apple,
  hormones: Activity,
  sleep: Moon,
  training: Dumbbell,
  skincare: Droplets,
  posture: PersonStanding,
} as const;

export function ProtocolStack({ protocols }: { protocols: Protocol[] }) {
  const c = useLooksmaxCopy();
  if (!protocols.length) return null;

  return (
    <section>
      <h2 className="font-display text-3xl sm:text-4xl">{c.protocolsTitle}</h2>
      <p className="mt-2 max-w-2xl text-sm text-muted-foreground">{c.protocolsIntro}</p>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {protocols.map((p) => {
          const Icon = ICONS[p.id];
          return (
            <article key={p.id} className="panel p-6">
              <header className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg border border-primary/25 bg-primary/10">
                  <Icon className="h-4 w-4 text-primary" />
                </span>
                <span className="label-mono">{c.protocolLabels[p.id]}</span>
              </header>
              <h3 className="mt-4 text-lg font-semibold">{p.title}</h3>

              <p className="mt-3 text-sm text-muted-foreground">
                <span className="label-mono mr-2">{c.protocolWhy}</span>
                {p.why}
              </p>

              <p className="label-mono mt-5">{c.protocolSteps}</p>
              <ul className="mt-2 space-y-2 text-sm text-foreground/90">
                {p.steps.map((s) => (
                  <li key={s} className="flex gap-2">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    {s}
                  </li>
                ))}
              </ul>

              {p.avoid.length > 0 && (
                <>
                  <p className="label-mono mt-5">{c.protocolAvoid}</p>
                  <ul className="mt-2 space-y-2 text-sm text-muted-foreground">
                    {p.avoid.map((a) => (
                      <li key={a} className="flex gap-2">
                        <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-destructive/70" />
                        {a}
                      </li>
                    ))}
                  </ul>
                </>
              )}

              <p className="mt-5 text-xs text-muted-foreground">
                <span className="label-mono mr-2">{c.protocolTimeline}</span>
                {p.timeline}
              </p>
            </article>
          );
        })}
      </div>
    </section>
  );
}
