import type { Analysis, ScanRecord } from "@/lib/analysis-schema";
import { useReportCopy } from "@/lib/report-copy";
import { ACHIEVEMENTS, levelFor } from "@/lib/progress";
import { Trophy } from "lucide-react";

export function ProgressPanel({
  xp,
  completed,
  achievements,
  scans,
  analysis,
}: {
  xp: number;
  completed: number;
  achievements: string[];
  scans: ScanRecord[];
  analysis: Analysis;
}) {
  const c = useReportCopy();
  const { level, progress } = levelFor(xp);
  const first = scans[0];
  const current = scans[scans.length - 1];
  const delta =
    first && current && first.id !== current.id
      ? current.analysis.overall_score - first.analysis.overall_score
      : null;

  return (
    <section className="panel p-5 sm:p-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="label-mono">{c.xp}</p>
          <p className="font-display text-3xl font-bold tabular-nums">
            {xp.toLocaleString()} <span className="text-base text-muted-foreground">XP</span>
          </p>
        </div>
        <div className="text-right">
          <p className="label-mono">{c.levelShort}</p>
          <p className="font-display text-3xl font-bold tabular-nums text-primary">
            {String(level).padStart(2, "0")}
          </p>
        </div>
      </div>

      <div className="mt-4 h-2 overflow-hidden rounded-full bg-surface-2">
        <div
          className="h-full rounded-full bg-gradient-to-r from-accent to-primary transition-[width] duration-700"
          style={{ width: `${progress}%` }}
        />
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-3">
        <Stat label={c.upgradesDone} value={String(completed)} />
        <Stat label={c.currentScore} value={analysis.overall_score.toFixed(1)} />
        <Stat
          label={delta === null ? c.scans : c.sinceFirst}
          value={
            delta === null
              ? String(scans.length)
              : `${delta >= 0 ? "+" : ""}${delta.toFixed(1)}`
          }
          accent={delta !== null && delta > 0}
        />
      </div>

      {achievements.length > 0 && (
        <div className="mt-6">
          <p className="label-mono">{c.achievements}</p>
          <ul className="mt-3 flex flex-wrap gap-2">
            {achievements.map((a) => {
              const meta = ACHIEVEMENTS[a];
              if (!meta) return null;
              return (
                <li
                  key={a}
                  title={meta.detail}
                  className="flex items-center gap-2 rounded-lg border border-primary/25 bg-primary/5 px-3 py-2 text-xs font-medium"
                >
                  <Trophy className="h-3.5 w-3.5 text-primary" />
                  {meta.title}
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </section>
  );
}

function Stat({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-xl border border-border bg-surface-2/60 p-4">
      <p className="label-mono">{label}</p>
      <p
        className={`mt-1 font-display text-2xl font-bold tabular-nums ${accent ? "text-primary" : ""}`}
      >
        {value}
      </p>
    </div>
  );
}
