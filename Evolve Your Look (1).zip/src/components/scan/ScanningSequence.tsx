import { useEffect, useState } from "react";
import { useReportCopy } from "@/lib/report-copy";
import { Check, Loader2 } from "lucide-react";

export function ScanningSequence({ imageDataUrl }: { imageDataUrl: string }) {
  const c = useReportCopy();
  const STEPS = c.scanSteps;
  const [step, setStep] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setStep((s) => (s < STEPS.length - 1 ? s + 1 : s));
    }, 1400);
    return () => clearInterval(id);
  }, [STEPS.length]);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <div className="panel relative overflow-hidden">
        <img
          src={imageDataUrl}
          alt=""
          className="h-full max-h-[420px] w-full object-cover opacity-80"
        />
        <div className="pointer-events-none absolute inset-0 grid-noise" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-24 animate-sweep bg-gradient-to-b from-transparent via-primary/25 to-transparent" />
      </div>

      <div className="panel p-6 sm:p-8">
        <p className="label-mono">{c.scanning}</p>
        <h2 className="mt-2 font-display text-3xl">{c.scanningTitle}</h2>
        <ul className="mt-6 space-y-3" aria-live="polite">
          {STEPS.map((label, i) => {
            const done = i < step;
            const active = i === step;
            return (
              <li
                key={label}
                className={`flex items-center gap-3 text-sm transition-opacity ${
                  done || active ? "opacity-100" : "opacity-35"
                }`}
              >
                {done ? (
                  <Check className="h-4 w-4 text-primary" />
                ) : active ? (
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                ) : (
                  <span className="h-4 w-4 rounded-full border border-border" />
                )}
                <span className={done ? "text-muted-foreground" : ""}>{label}</span>
              </li>
            );
          })}
        </ul>
        <p className="mt-6 text-xs text-muted-foreground">
          {c.scanningNote}
        </p>
      </div>
    </div>
  );
}
