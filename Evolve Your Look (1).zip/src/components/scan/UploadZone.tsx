import { useCallback, useRef, useState } from "react";
import { ImageUp, Check } from "lucide-react";

const ACCEPTED = ["image/jpeg", "image/png", "image/webp"];
const MAX_BYTES = 8 * 1024 * 1024;
const MAX_EDGE = 1280;

export interface UploadCopy {
  dropTitle: string;
  dropHint: string;
  choose: string;
  preparing: string;
  tipsTitle: string;
  tips: readonly string[];
  privacyNote: string;
  errType: string;
  errSize: string;
  errRead: string;
}

/** Downscales client-side: smaller payload, faster analysis, less data in flight. */
async function toDataUrl(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas unavailable");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvas.toDataURL("image/jpeg", 0.9);
}

export function UploadZone({
  onReady,
  onError,
  copy,
  compact = false,
}: {
  onReady: (dataUrl: string) => void;
  onError: (message: string) => void;
  copy: UploadCopy;
  compact?: boolean;
}) {
  const [dragging, setDragging] = useState(false);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback(
    async (file: File | undefined) => {
      if (!file) return;
      if (!ACCEPTED.includes(file.type)) {
        onError(copy.errType);
        return;
      }
      if (file.size > MAX_BYTES) {
        onError(copy.errSize);
        return;
      }
      setBusy(true);
      try {
        onReady(await toDataUrl(file));
      } catch {
        onError(copy.errRead);
      } finally {
        setBusy(false);
      }
    },
    [onReady, onError, copy],
  );

  const zone = (
    <div
      onDragOver={(e) => {
        e.preventDefault();
        setDragging(true);
      }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        void handleFile(e.dataTransfer.files[0]);
      }}
      className={`panel relative flex flex-col items-center justify-center gap-4 p-8 text-center transition-colors ${
        compact ? "min-h-[280px]" : "min-h-[320px]"
      } ${dragging ? "bg-primary/10" : ""}`}
    >
      <ScanFrame />
      <span className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/12">
        <ImageUp className="h-6 w-6 text-primary" />
      </span>
      <div className="relative">
        <p className="font-display text-2xl">{copy.dropTitle}</p>
        <p className="mt-1 text-sm text-muted-foreground">{copy.dropHint}</p>
      </div>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={busy}
        className="relative rounded-full bg-primary px-7 py-3 font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-60"
      >
        {busy ? copy.preparing : copy.choose}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept={ACCEPTED.join(",")}
        className="sr-only"
        aria-label={copy.choose}
        onChange={(e) => void handleFile(e.target.files?.[0])}
      />
    </div>
  );

  if (compact) return zone;

  return (
    <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
      {zone}
      <aside className="panel p-6">
        <p className="label-mono">{copy.tipsTitle}</p>
        <ul className="mt-4 space-y-3">
          {copy.tips.map((tip) => (
            <li key={tip} className="flex items-center gap-3 text-sm">
              <Check className="h-4 w-4 shrink-0 text-primary" />
              {tip}
            </li>
          ))}
        </ul>
        <p className="mt-6 text-xs text-muted-foreground">{copy.privacyNote}</p>
      </aside>
    </div>
  );
}

/** Decorative corner brackets + sweeping scan line. */
function ScanFrame() {
  const corner =
    "pointer-events-none absolute h-10 w-10 border-primary/45 opacity-70";
  return (
    <div className="pointer-events-none absolute inset-4 overflow-hidden rounded-3xl">
      <span className={`${corner} left-0 top-0 rounded-tl-2xl border-l-2 border-t-2`} />
      <span className={`${corner} right-0 top-0 rounded-tr-2xl border-r-2 border-t-2`} />
      <span className={`${corner} bottom-0 left-0 rounded-bl-2xl border-b-2 border-l-2`} />
      <span className={`${corner} bottom-0 right-0 rounded-br-2xl border-b-2 border-r-2`} />
      <span
        className="animate-sweep absolute inset-x-6 top-0 h-16 opacity-50"
        style={{
          background:
            "linear-gradient(180deg, transparent, oklch(0.87 0.2 124 / 0.28), transparent)",
        }}
      />
    </div>
  );
}
