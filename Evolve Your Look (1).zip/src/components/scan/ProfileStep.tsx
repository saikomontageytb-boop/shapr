import { useState } from "react";
import type { SubjectProfile } from "@/lib/analysis-schema";
import { DEFAULT_PROFILE, useLooksmaxCopy } from "@/lib/looksmax-copy";

type Goal = SubjectProfile["goals"][number];

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <fieldset className="space-y-3">
      <legend className="label-mono">
        {label}
        {hint ? <span className="ml-2 text-muted-foreground/70">{hint}</span> : null}
      </legend>
      <div className="flex flex-wrap gap-2">{children}</div>
    </fieldset>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`rounded-full px-4 py-2 text-sm transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary ${
        active
          ? "bg-primary font-semibold text-primary-foreground"
          : "soft text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

export function ProfileStep({
  preview,
  onBack,
  onSubmit,
}: {
  preview?: string | undefined;
  onBack: () => void;
  onSubmit: (profile: SubjectProfile) => void;
}) {
  const c = useLooksmaxCopy();
  const [profile, setProfile] = useState<SubjectProfile>(DEFAULT_PROFILE);

  const set = <K extends keyof SubjectProfile>(key: K, value: SubjectProfile[K]) =>
    setProfile((p) => ({ ...p, [key]: value }));

  const toggleGoal = (goal: Goal) =>
    setProfile((p) => {
      const has = p.goals.includes(goal);
      const goals = has ? p.goals.filter((g) => g !== goal) : [...p.goals, goal];
      return { ...p, goals: goals.length ? goals : ["overall"] };
    });

  const entries = <T extends Record<string, string>>(o: T) =>
    Object.entries(o) as Array<[keyof T & string, string]>;

  return (
    <div className="grid gap-10 lg:grid-cols-[320px_1fr]">
      <div className="space-y-4">
        {preview ? (
          <img
            src={preview}
            alt=""
            className="w-full rounded-[1.75rem] object-cover"
          />
        ) : null}
        <button
          type="button"
          onClick={onBack}
          className="soft w-full rounded-full px-5 py-3 text-sm font-medium transition-colors hover:text-primary"
        >
          {c.back}
        </button>
      </div>

      <div className="space-y-8">
        <header>
          <p className="label-mono">{c.step}</p>
          <h1 className="mt-2 font-display text-4xl sm:text-5xl">{c.title}</h1>
          <p className="mt-3 max-w-xl text-sm text-muted-foreground">{c.body}</p>
        </header>

        <Field label={c.sex}>
          {entries(c.sexOptions).map(([k, v]) => (
            <Chip key={k} active={profile.sex === k} onClick={() => set("sex", k)}>
              {v}
            </Chip>
          ))}
        </Field>

        <Field label={c.age}>
          {entries(c.ageOptions).map(([k, v]) => (
            <Chip
              key={k}
              active={profile.age_range === k}
              onClick={() => set("age_range", k)}
            >
              {v}
            </Chip>
          ))}
        </Field>

        {profile.age_range === "under_18" && (
          <p className="panel p-4 text-sm text-muted-foreground">{c.minorNote}</p>
        )}

        <Field label={c.skin}>
          {entries(c.skinOptions).map(([k, v]) => (
            <Chip
              key={k}
              active={profile.skin_type === k}
              onClick={() => set("skin_type", k)}
            >
              {v}
            </Chip>
          ))}
        </Field>

        <Field label={c.bodyFat}>
          {entries(c.bodyFatOptions).map(([k, v]) => (
            <Chip
              key={k}
              active={profile.body_fat === k}
              onClick={() => set("body_fat", k)}
            >
              {v}
            </Chip>
          ))}
        </Field>

        <Field label={c.beard}>
          {entries(c.beardOptions).map(([k, v]) => (
            <Chip
              key={k}
              active={profile.facial_hair_goal === k}
              onClick={() => set("facial_hair_goal", k)}
            >
              {v}
            </Chip>
          ))}
        </Field>

        <Field label={c.goals} hint={c.goalsHint}>
          {entries(c.goalOptions).map(([k, v]) => (
            <Chip
              key={k}
              active={profile.goals.includes(k)}
              onClick={() => toggleGoal(k)}
            >
              {v}
            </Chip>
          ))}
        </Field>

        <Field label={c.effort}>
          {entries(c.effortOptions).map(([k, v]) => (
            <Chip key={k} active={profile.effort === k} onClick={() => set("effort", k)}>
              {v}
            </Chip>
          ))}
        </Field>

        <button
          type="button"
          onClick={() => onSubmit(profile)}
          className="rounded-full bg-primary px-8 py-4 font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          {c.submit}
        </button>
      </div>
    </div>
  );
}
