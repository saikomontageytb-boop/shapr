import { Link } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { useT } from "@/lib/use-lang";

export function SiteFooter() {
  const { lang, t } = useT();

  return (
    <footer className="mt-10 bg-surface/60">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:grid-cols-2 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <Logo className="h-5 w-5" />
            <span className="font-display text-lg">Shapr</span>
          </div>
          <p className="mt-3 text-sm text-muted-foreground">{t.footer.tagline}</p>
        </div>
        <div>
          <p className="label-mono">{t.footer.product}</p>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/$lang/scan" params={{ lang }} className="hover:text-foreground">
                {t.footer.runScan}
              </Link>
            </li>
            <li>
              <Link to="/$lang/example" params={{ lang }} className="hover:text-foreground">
                {t.footer.exampleReport}
              </Link>
            </li>
            <li>
              <Link to="/$lang/report" params={{ lang }} className="hover:text-foreground">
                {t.footer.myProgress}
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="label-mono">{t.footer.trust}</p>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li>
              <Link to="/$lang/privacy" params={{ lang }} className="hover:text-foreground">
                {t.footer.privacy}
              </Link>
            </li>
            <li>
              <Link to="/$lang" params={{ lang }} hash="faq" className="hover:text-foreground">
                {t.footer.faq}
              </Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="label-mono">{t.footer.notAdvice}</p>
          <p className="mt-3 text-sm text-muted-foreground">{t.footer.notAdviceBody}</p>
        </div>
      </div>
      <div className="py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Shapr. {t.footer.rights}
      </div>
    </footer>
  );
}
