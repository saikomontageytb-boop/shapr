import { Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  CalendarDays,
  GraduationCap,
  LayoutDashboard,
  LogIn,
  LogOut,
  Menu,
  ScanFace,
  Settings,
  Trophy,
  UserRound,
  X,
} from "lucide-react";
import { Logo } from "./Logo";
import { ArenaIcon } from "./ArenaIcon";

import { useAuth } from "@/lib/auth";
import { otherLang } from "@/lib/i18n";
import { useT } from "@/lib/use-lang";
import { supabase } from "@/integrations/supabase/client";

export function SiteHeader() {
  const { lang, t } = useT();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const fr = lang === "fr";

  /** The whole site in five categories, same order everywhere. */
  const sections = [
    { to: "/$lang/scan", icon: ScanFace, label: fr ? "Scan" : "Scan" },
    { to: "/$lang/academy", icon: GraduationCap, label: fr ? "Apprendre" : "Learn" },
    { to: "/$lang/daily", icon: CalendarDays, label: fr ? "Défi du jour" : "Daily challenge" },
    { to: "/$lang/arena", icon: ArenaIcon, label: fr ? "Arène" : "Arena" },
    { to: "/$lang/leaderboard", icon: Trophy, label: fr ? "Classement" : "Leaderboard" },
  ] as const;

  const account = [
    { to: "/$lang/dashboard", icon: LayoutDashboard, label: t.nav.dashboard },
    { to: "/$lang/settings", icon: Settings, label: fr ? "Paramètres" : "Settings" },
  ] as const;

  const signOut = async () => {
    await supabase.auth.signOut();
    void navigate({ to: "/$lang", params: { lang } });
  };

  return (
    <header className="sticky top-0 z-50 bg-background/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5">
        <Link to="/$lang" params={{ lang }} className="flex shrink-0 items-center gap-2.5" aria-label={t.nav.home}>
          <Logo className="h-8 w-8" />
          <span className="font-display text-xl font-bold tracking-tight">Shapr</span>
        </Link>

        <nav className="hidden items-center gap-6 whitespace-nowrap lg:flex" aria-label="Main">
          {sections.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              params={{ lang }}
              activeProps={{ className: "text-foreground font-medium" }}
              className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
          <Link
            to="/$lang/pro"
            params={{ lang }}
            className="text-sm font-semibold text-primary transition-opacity hover:opacity-80"
          >
            Pro
          </Link>
        </nav>

        <div className="flex shrink-0 items-center gap-2">
          <LangSwitch />
          {user ? (
            <>
              <Link
                to="/$lang/dashboard"
                params={{ lang }}
                className="hidden items-center gap-2 rounded-full bg-surface-2 px-4 py-2 text-sm sm:inline-flex"
              >
                <UserRound className="h-4 w-4 text-primary" />
                {t.nav.dashboard}
              </Link>
              <Link
                to="/$lang/settings"
                params={{ lang }}
                aria-label={fr ? "Paramètres" : "Settings"}
                className="hidden rounded-full bg-surface-2 p-2 text-muted-foreground transition-colors hover:text-foreground sm:inline-flex"
              >
                <Settings className="h-4 w-4" />
              </Link>
            </>
          ) : (
            <Link
              to="/$lang/auth"
              params={{ lang }}
              className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:inline-flex"
            >
              {t.nav.signIn}
            </Link>
          )}
          <Link
            to="/$lang/scan"
            params={{ lang }}
            className="hidden rounded-full bg-primary px-5 py-2 text-sm font-semibold text-primary-foreground transition-all hover:brightness-110 sm:inline-flex"
          >
            {t.nav.scan}
          </Link>
          <button
            className="rounded-full bg-surface-2 p-2 lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? t.nav.menuClose : t.nav.menuOpen}
            aria-expanded={open}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <nav className="border-t border-border bg-surface px-5 py-4 lg:hidden" aria-label="Mobile">
          <ul className="space-y-1">
            {sections.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  params={{ lang }}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 rounded-md px-3 py-3 text-sm transition-colors hover:bg-surface-2"
                >
                  <item.icon className="h-4 w-4 text-primary" />
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>

          <p className="label-mono mt-4 px-3">{fr ? "Mon compte" : "My account"}</p>
          <ul className="mt-1 space-y-1">
            {account.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  params={{ lang }}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 rounded-md px-3 py-3 text-sm transition-colors hover:bg-surface-2"
                >
                  <item.icon className="h-4 w-4 text-primary" />
                  {item.label}
                </Link>
              </li>
            ))}
            <li>
              {user ? (
                <button
                  onClick={() => {
                    setOpen(false);
                    void signOut();
                  }}
                  className="flex w-full items-center gap-3 rounded-md px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-surface-2"
                >
                  <LogOut className="h-4 w-4" />
                  {t.nav.signOut}
                </button>
              ) : (
                <Link
                  to="/$lang/auth"
                  params={{ lang }}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 rounded-md px-3 py-3 text-sm transition-colors hover:bg-surface-2"
                >
                  <LogIn className="h-4 w-4 text-primary" />
                  {t.nav.signIn}
                </Link>
              )}
            </li>
          </ul>

          <Link
            to="/$lang/scan"
            params={{ lang }}
            onClick={() => setOpen(false)}
            className="mt-4 block rounded-full bg-primary px-4 py-3 text-center text-sm font-semibold text-primary-foreground"
          >
            {t.nav.scan}
          </Link>
        </nav>
      )}
    </header>
  );
}

function LangSwitch() {
  const { lang } = useT();
  const next = otherLang(lang);
  return (
    <div className="flex items-center rounded-full bg-surface-2 p-0.5 text-xs font-medium uppercase">
      <span className="rounded-full bg-primary px-2.5 py-1 text-primary-foreground">{lang}</span>
      <Link
        to="/$lang"
        params={{ lang: next }}
        className="px-2.5 py-1 text-muted-foreground transition-colors hover:text-foreground"
        aria-label={next === "fr" ? "Passer en français" : "Switch to English"}
      >
        {next}
      </Link>
    </div>
  );
}
