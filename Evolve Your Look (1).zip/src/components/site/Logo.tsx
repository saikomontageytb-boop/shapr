import wolf from "@/assets/wolf-mark.png";

export function Logo({ className = "h-8 w-8" }: { className?: string }) {
  return (
    <img
      src={wolf}
      alt=""
      aria-hidden="true"
      width={1024}
      height={1024}
      className={`${className} object-contain`}
    />
  );
}
