/**
 * Arena mark: a crest holding two crossed blades with a spark above.
 * Drawn with currentColor so it inherits the design tokens everywhere.
 */
export function ArenaIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden
    >
      {/* crest */}
      <path
        d="M12 2.4 20 5v6.6c0 4.2-3.1 7.9-8 10-4.9-2.1-8-5.8-8-10V5l8-2.6Z"
        className="opacity-30"
        fill="currentColor"
        stroke="none"
      />
      <path d="M12 2.4 20 5v6.6c0 4.2-3.1 7.9-8 10-4.9-2.1-8-5.8-8-10V5l8-2.6Z" />
      {/* crossed blades */}
      <path d="M8.4 8.2 15 15.4" />
      <path d="M15.6 8.2 9 15.4" />
      <path d="M14.2 7.2h2.2v2.2" />
      <path d="M9.8 7.2H7.6v2.2" />
      {/* spark */}
      <path d="M12 10.4 11 13h2l-1 2.6" strokeWidth={1.3} />
    </svg>
  );
}
