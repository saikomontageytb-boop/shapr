import { trackArt } from "@/lib/track-art";

/** Module illustration. Falls back to a soft panel if the id is unknown. */
export function TrackArt({
  trackId,
  alt,
  className = "aspect-[16/10] w-full",
  rounded = "rounded-2xl",
}: {
  trackId: string;
  alt: string;
  className?: string;
  rounded?: string;
}) {
  const src = trackArt(trackId);

  if (!src) {
    return <div aria-hidden className={`${className} ${rounded} bg-surface-2`} />;
  }

  return (
    <img
      src={src}
      alt={alt}
      loading="lazy"
      decoding="async"
      className={`${className} ${rounded} object-cover`}
    />
  );
}
