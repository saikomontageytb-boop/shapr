import { useState } from "react";
import { academyImage } from "@/lib/academy-images";
import { TrackArt } from "./TrackArt";

/**
 * Real photograph (CC0 / commercial-use stock indexed by Openverse).
 * If the remote file disappears — or the lesson has no photo — we fall back to
 * the module's own illustration so a lesson never shows an empty box.
 */
export function LessonImage({
  image,
  alt,
  trackId,
  className = "aspect-[16/10]",
  rounded = "rounded-3xl",
}: {
  image: string;
  alt: string;
  trackId?: string | undefined;
  className?: string;
  rounded?: string;
}) {
  const [broken, setBroken] = useState(false);
  const img = academyImage(image);

  if (!img || broken) {
    return (
      <TrackArt
        trackId={trackId ?? ""}
        alt={alt}
        className={`${className} w-full`}
        rounded={rounded}
      />
    );
  }

  return (
    <img
      src={img.url}
      alt={alt || img.title}
      loading="lazy"
      decoding="async"
      onError={() => setBroken(true)}
      className={`${className} ${rounded} w-full object-cover`}
    />
  );
}
