/**
 * The Shapr padlock. A drawn mark used everywhere a lesson is part of the
 * subscription, instead of a generic icon.
 */
export function LockBadge({
  className = "h-6 w-6",
  tone = "muted",
}: {
  className?: string;
  /** `muted` sits on a light surface, `solid` sits on a dark chip. */
  tone?: "muted" | "solid" | "primary";
}) {
  const body =
    tone === "solid"
      ? "currentColor"
      : tone === "primary"
        ? "var(--primary)"
        : "var(--muted-foreground)";

  return (
    <svg
      viewBox="0 0 24 24"
      role="img"
      aria-hidden="true"
      focusable="false"
      className={className}
    >
      {/* shackle */}
      <path
        d="M8 10V7.6C8 5.06 9.79 3 12 3s4 2.06 4 4.6V10"
        fill="none"
        stroke={body}
        strokeWidth="2.1"
        strokeLinecap="round"
      />
      {/* body */}
      <rect x="4.2" y="10" width="15.6" height="11" rx="3.6" fill={body} />
      {/* keyhole */}
      <circle cx="12" cy="14.9" r="1.7" fill="var(--surface)" />
      <path
        d="M12 15.6v2.6"
        stroke="var(--surface)"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  );
}
