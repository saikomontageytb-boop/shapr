import { useState } from "react";
import { AlertTriangle, Check, ExternalLink, Timer, X } from "lucide-react";
import type { Block } from "@/lib/academy-types";
import { useAcademyCopy } from "@/lib/academy-copy";
import { LessonImage } from "./LessonImage";

/** One block of a lesson. Every kind gets its own visual shape on purpose. */
export function BlockView({
  block,
  trackId,
  onAnswered,
}: {
  block: Block;
  trackId?: string | undefined;
  onAnswered?: (correct: boolean) => void;
}) {
  const c = useAcademyCopy();

  switch (block.kind) {
    case "text":
      return (
        <div className="animate-rise">
          <h3 className="font-display text-3xl sm:text-4xl">{block.title}</h3>
          <p className="mt-5 text-lg leading-relaxed text-muted-foreground">{block.body}</p>
        </div>
      );

    case "image":
      return (
        <figure className="animate-rise">
          <LessonImage image={block.image} alt={block.caption} trackId={trackId} />
          <figcaption className="mt-3 text-sm text-muted-foreground">{block.caption}</figcaption>
        </figure>
      );


    case "list":
      return (
        <div className="animate-rise">
          <h3 className="font-display text-2xl sm:text-3xl">{block.title}</h3>
          <ul className="mt-5 space-y-3">
            {block.items.map((item) => (
              <li key={item} className="flex gap-3 rounded-2xl bg-surface-2 px-4 py-3 text-sm">
                <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                <span className="text-muted-foreground">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      );

    case "steps":
      return (
        <div className="animate-rise">
          <h3 className="font-display text-2xl sm:text-3xl">{block.title}</h3>
          <ol className="mt-5 space-y-3">
            {block.items.map((item, i) => (
              <li key={item} className="flex gap-4 rounded-2xl bg-surface-2 px-4 py-3">
                <span className="label-mono shrink-0 text-primary">{String(i + 1).padStart(2, "0")}</span>
                <span className="text-sm text-muted-foreground">{item}</span>
              </li>
            ))}
          </ol>
        </div>
      );

    case "stat":
      return (
        <div className="animate-rise text-center">
          <p className="font-display text-6xl text-primary text-glow sm:text-7xl">{block.value}</p>
          <p className="label-mono mt-3">{block.label}</p>
          <p className="mx-auto mt-6 max-w-md text-lg leading-relaxed text-muted-foreground">
            {block.body}
          </p>
        </div>
      );

    case "myth":
      return (
        <div className="animate-rise space-y-4">
          <div className="rounded-3xl bg-surface-2 p-5">
            <p className="label-mono">{c.myth}</p>
            <p className="mt-2 text-lg text-muted-foreground line-through decoration-muted-foreground/40">
              {block.myth}
            </p>
          </div>
          <div className="rounded-3xl bg-primary/10 p-5">
            <p className="label-mono text-primary">{c.truth}</p>
            <p className="mt-2 text-lg leading-relaxed">{block.truth}</p>
          </div>
        </div>
      );

    case "compare":
      return (
        <div className="animate-rise">
          <h3 className="font-display text-2xl sm:text-3xl">{block.title}</h3>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {[block.left, block.right].map((col, idx) => (
              <div
                key={col.label}
                className={`rounded-3xl p-5 ${idx === 0 ? "bg-primary/10" : "bg-surface-2"}`}
              >
                <p className={`label-mono ${idx === 0 ? "text-primary" : ""}`}>{col.label}</p>
                <ul className="mt-3 space-y-2">
                  {col.items.map((item) => (
                    <li key={item} className="flex gap-2 text-sm text-muted-foreground">
                      {idx === 0 ? (
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                      ) : (
                        <X className="mt-0.5 h-4 w-4 shrink-0" />
                      )}
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      );

    case "warn":
      return (
        <div className="animate-rise rounded-3xl border border-accent/30 bg-accent/10 p-6">
          <p className="flex items-center gap-2 label-mono text-accent">
            <AlertTriangle className="h-4 w-4" />
            {block.title}
          </p>
          <p className="mt-3 text-lg leading-relaxed text-muted-foreground">{block.body}</p>
        </div>
      );

    case "drill":
      return (
        <div className="animate-rise rounded-3xl bg-surface-2 p-6">
          <p className="flex items-center gap-2 label-mono text-primary">
            <Timer className="h-4 w-4" />
            {c.drill} · {block.duration}
          </p>
          <h3 className="mt-3 font-display text-2xl">{block.title}</h3>
          <p className="mt-3 text-base leading-relaxed text-muted-foreground">{block.body}</p>
        </div>
      );

    case "checklist":
      return <Checklist title={block.title} items={block.items} />;

    case "quiz":
      return <QuizBlock block={block} {...(onAnswered ? { onAnswered } : {})} />;

    case "sources":
      return (
        <div className="animate-rise">
          <p className="label-mono">{c.sources}</p>
          <ul className="mt-4 space-y-2">
            {block.items.map((s) => (
              <li key={s.url}>
                <a
                  href={s.url}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex items-start gap-2 rounded-2xl bg-surface-2 px-4 py-3 text-sm text-muted-foreground transition-colors hover:text-primary"
                >
                  <ExternalLink className="mt-0.5 h-4 w-4 shrink-0" />
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        </div>
      );
  }
}

function Checklist({ title, items }: { title: string; items: string[] }) {
  const [ticked, setTicked] = useState<string[]>([]);
  return (
    <div className="animate-rise">
      <h3 className="font-display text-2xl sm:text-3xl">{title}</h3>
      <ul className="mt-5 space-y-2">
        {items.map((item) => {
          const on = ticked.includes(item);
          return (
            <li key={item}>
              <button
                type="button"
                onClick={() =>
                  setTicked((t) => (on ? t.filter((x) => x !== item) : [...t, item]))
                }
                className={`flex w-full items-center gap-3 rounded-2xl px-4 py-3 text-left text-sm transition-colors ${
                  on ? "bg-primary/15 text-primary" : "bg-surface-2 text-muted-foreground"
                }`}
              >
                <span
                  className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-md ${
                    on ? "bg-primary text-primary-foreground" : "bg-background/60"
                  }`}
                >
                  {on && <Check className="h-3.5 w-3.5" />}
                </span>
                {item}
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function QuizBlock({
  block,
  onAnswered,
}: {
  block: Extract<Block, { kind: "quiz" }>;
  onAnswered?: (correct: boolean) => void;
}) {
  const c = useAcademyCopy();
  const [choice, setChoice] = useState<number | null>(null);
  const correct = choice !== null && choice === block.answer;

  return (
    <div className="animate-rise">
      <p className="label-mono">{c.quiz}</p>
      <h3 className="mt-3 font-display text-2xl sm:text-3xl">{block.question}</h3>
      <div className="mt-6 space-y-3">
        {block.options.map((option, i) => {
          const picked = choice === i;
          const state =
            choice === null
              ? "bg-surface-2 hover:text-primary"
              : i === block.answer
                ? "bg-primary/15 text-primary"
                : picked
                  ? "bg-surface-2 text-muted-foreground line-through"
                  : "bg-surface-2 text-muted-foreground";
          return (
            <button
              key={option}
              type="button"
              disabled={choice !== null}
              onClick={() => {
                setChoice(i);
                onAnswered?.(i === block.answer);
              }}
              className={`w-full rounded-2xl px-5 py-4 text-left text-sm transition-colors ${state}`}
            >
              {option}
            </button>
          );
        })}
      </div>
      {choice !== null && (
        <p className="mt-5 flex items-start gap-2 text-sm text-muted-foreground">
          {correct ? (
            <Check className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
          ) : (
            <X className="mt-0.5 h-4 w-4 shrink-0" />
          )}
          <span>
            <strong className="text-foreground">{correct ? c.correct : c.wrong}.</strong>{" "}
            {block.explanation}
          </span>
        </p>
      )}
    </div>
  );
}
