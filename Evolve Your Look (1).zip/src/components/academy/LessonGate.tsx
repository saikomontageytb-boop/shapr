import { Link } from "@tanstack/react-router";
import { X } from "lucide-react";
import wolf from "@/assets/wolf-hero.png";
import type { Lesson } from "@/lib/academy-types";
import { FREE_LESSON_COUNT } from "@/lib/free-lessons";
import { useLang } from "@/lib/use-lang";
import { LockBadge } from "./LockBadge";

const COPY = {
  fr: {
    label: "Leçon réservée aux membres",
    body: (n: number) =>
      `Seules ${n} leçons sont offertes à tout le monde, les mêmes pour tous. Celle-ci fait partie de l'abonnement, avec des centaines d'autres.`,
    pro: "Prendre l'abonnement",
    close: "Fermer",
  },
  en: {
    label: "Members-only lesson",
    body: (n: number) =>
      `Only ${n} lessons are free, the same ones for everybody. This one is part of the subscription, along with hundreds of others.`,
    pro: "Get the subscription",
    close: "Close",
  },
} as const;

/** Shown when a free member taps a locked lesson. */
export function LessonGate({
  lesson,
  onClose,
}: {
  lesson: Lesson;
  onClose: () => void;
}) {
  const lang = useLang();
  const c = COPY[lang];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={lesson.title}
      className="fixed inset-0 z-[70] flex items-end justify-center bg-foreground/40 p-0 backdrop-blur-sm sm:items-center sm:p-6"
    >
      <div className="panel relative w-full max-w-md p-6">
        <button
          type="button"
          onClick={onClose}
          aria-label={c.close}
          className="absolute right-4 top-4 rounded-full bg-surface-2 p-2 text-muted-foreground transition-colors hover:text-foreground"
        >
          <X className="h-4 w-4" />
        </button>
        <img src={wolf} alt="" width={1024} height={1024} className="h-24 w-auto" />
        <p className="label-mono mt-4 flex items-center gap-1.5">
          <LockBadge className="h-4 w-4" />
          {c.label}
        </p>
        <h2 className="mt-1 text-xl font-bold">{lesson.title}</h2>
        <p className="mt-3 text-sm text-muted-foreground">{c.body(FREE_LESSON_COUNT)}</p>

        <Link
          to="/$lang/pro"
          params={{ lang }}
          className="btn-chunky mt-6 block w-full rounded-full bg-primary px-6 py-3.5 text-center font-semibold text-primary-foreground transition-all hover:brightness-110"
        >
          {c.pro}
        </Link>
      </div>
    </div>
  );
}
