import { useEffect, useMemo, useState } from "react";
import { Sparkles, X } from "lucide-react";
import type { Lesson } from "@/lib/academy-types";
import { useAcademyCopy } from "@/lib/academy-copy";
import { BlockView } from "./BlockView";

/**
 * One lesson, one block at a time. Blocks alternate shape (photo, figure,
 * myth, drill, question) so a long lesson never reads like one long page.
 */
export function LessonPlayer({
  lesson,
  trackId,
  onClose,
  onComplete,
}: {
  lesson: Lesson;
  trackId?: string | undefined;
  onClose: () => void;
  onComplete: (bonusXp: number) => void;
}) {
  const c = useAcademyCopy();
  const [step, setStep] = useState(0);
  const [answered, setAnswered] = useState<Record<number, boolean>>({});
  const total = lesson.blocks.length;
  const block = lesson.blocks[step]!;
  const last = step === total - 1;
  const needsAnswer = block.kind === "quiz" && answered[step] === undefined;

  const bonusXp = useMemo(
    () => Object.values(answered).filter(Boolean).length * 10,
    [answered],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    window.scrollTo({ top: 0 });
  }, [step]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={lesson.title}
      className="fixed inset-0 z-[70] flex flex-col overflow-y-auto bg-background/98 backdrop-blur-xl"
    >
      <header className="sticky top-0 z-10 bg-background/90 backdrop-blur">
        <div className="mx-auto flex w-full max-w-2xl items-center gap-4 px-5 py-5">
          <button
            type="button"
            onClick={onClose}
            aria-label={c.back}
            className="rounded-full bg-surface-2 p-2 text-muted-foreground transition-colors hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full rounded-full bg-primary transition-[width] duration-500"
              style={{ width: `${((step + 1) / total) * 100}%` }}
            />
          </div>
          <span className="label-mono">{lesson.xp + bonusXp} XP</span>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-2xl flex-1 flex-col justify-center px-5 py-8">
        <p className="label-mono mb-6">
          {lesson.title} · {step + 1}/{total}
        </p>
        <BlockView
          key={step}
          block={block}
          trackId={trackId}
          onAnswered={(correct) => setAnswered((a) => ({ ...a, [step]: correct }))}
        />
      </div>

      <footer className="sticky bottom-0 bg-gradient-to-t from-background via-background to-transparent">
        <div className="mx-auto w-full max-w-2xl px-5 pb-10 pt-4">
          {!last ? (
            <button
              type="button"
              disabled={needsAnswer}
              onClick={() => setStep((s) => s + 1)}
              className="w-full rounded-full bg-primary px-6 py-4 font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-30"
            >
              {c.next}
            </button>
          ) : (
            <button
              type="button"
              disabled={needsAnswer}
              onClick={() => onComplete(bonusXp)}
              className="flex w-full items-center justify-center gap-2 rounded-full bg-primary px-6 py-4 font-semibold text-primary-foreground transition-all hover:brightness-110 disabled:opacity-30"
            >
              <Sparkles className="h-4 w-4" />
              {c.finish} · +{lesson.xp + bonusXp} XP
            </button>
          )}
        </div>
      </footer>
    </div>
  );
}
