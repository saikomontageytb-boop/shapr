import type { Track } from "@/lib/academy-types";

export const photo: Track = {
  id: "photo",
  title: "Photos & image",
  tagline: "Des photos qui te représentent vraiment.",
  intro:
    "Lumière, angles, expression, tenues : les bases techniques pour des photos naturelles et flatteuses, sans filtre ni artifice.",
  icon: "sparkles",
  cover: "photo-cover",
  lessons: [
    {
      id: "photo-1",
      title: "La lumière, ton meilleur allié",
      summary: "Pourquoi une bonne lumière change tout, plus que n'importe quel filtre.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "photo-light",
      blocks: [
        {
          kind: "text",
          title: "La lumière avant tout",
          body: "Une photo réussie dépend à 80 % de la lumière. Le meilleur téléphone ne rattrape jamais une lumière dure ou insuffisante.",
        },
        {
          kind: "image",
          image: "photo-light",
          caption: "Lumière naturelle et douce en fin de journée.",
        },
        {
          kind: "list",
          title: "Les meilleures lumières",
          items: [
            "Lumière naturelle indirecte, près d'une fenêtre",
            "Golden hour, une heure avant le coucher du soleil",
            "Ciel couvert : diffuse et flatteuse",
            "Ombre légère plutôt que plein soleil",
          ],
        },
        {
          kind: "myth",
          myth: "Le flash du téléphone sauve une photo mal éclairée.",
          truth: "Le flash direct écrase les traits et crée des ombres dures. Mieux vaut chercher une autre source de lumière.",
        },
        {
          kind: "compare",
          title: "Bonne lumière vs mauvaise lumière",
          left: { label: "Lumière douce", items: ["Traits adoucis", "Couleurs fidèles", "Regard net"] },
          right: { label: "Lumière dure", items: ["Ombres marquées", "Plissement des yeux", "Contrastes agressifs"] },
        },
        {
          kind: "steps",
          title: "Trouver la bonne lumière",
          items: [
            "Place-toi face à une fenêtre, jamais dos à elle",
            "Évite le plein soleil de midi",
            "Teste plusieurs orientations avant de shooter",
          ],
        },
        {
          kind: "checklist",
          title: "Avant de prendre la photo",
          items: [
            "Je vérifie la source de lumière",
            "Je ne suis pas à contre-jour",
            "Je teste 2-3 positions",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle est la meilleure lumière pour une photo naturelle ?",
          options: ["Plein soleil de midi", "Flash direct", "Lumière douce et indirecte", "Néon blanc"],
          answer: 2,
          explanation: "Une lumière douce et indirecte adoucit les traits sans créer d'ombres dures.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-2",
      title: "Angles : trouver ton meilleur profil",
      summary: "Un léger changement d'angle peut transformer une photo.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "photo-angle",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi l'angle compte",
          body: "Personne n'est parfaitement symétrique. Trouver ton angle, c'est trouver la position où ton visage paraît le plus harmonieux.",
        },
        {
          kind: "image",
          image: "photo-angle",
          caption: "Un léger trois-quarts, souvent plus flatteur que la face totale.",
        },
        {
          kind: "steps",
          title: "Tester tes angles",
          items: [
            "Prends 5 photos avec des rotations légères de la tête",
            "Compare de face, trois-quarts gauche, trois-quarts droit",
            "Repère celui qui allonge le visage sans l'écraser",
          ],
        },
        {
          kind: "list",
          title: "Repères utiles",
          items: [
            "Le menton légèrement en avant évite le double menton",
            "L'appareil légèrement au-dessus du regard allonge le visage",
            "Un angle trop bas accentue le nez et le menton",
          ],
        },
        {
          kind: "myth",
          myth: "Il faut toujours être pris de face pour paraître naturel.",
          truth: "Le trois-quarts est souvent plus flatteur et plus naturel que la face stricte, qui aplatit les traits.",
        },
        {
          kind: "drill",
          title: "Test des 5 angles",
          body: "Devant un miroir ou en selfie, teste 5 angles différents et note lequel te semble le plus naturel.",
          duration: "3 min",
        },
        {
          kind: "checklist",
          title: "Réflexes angle",
          items: [
            "Je connais mon meilleur profil",
            "J'évite la contre-plongée trop marquée",
            "Je garde le menton légèrement avancé",
          ],
        },
        {
          kind: "quiz",
          question: "Quel angle a tendance à accentuer le nez et le menton ?",
          options: ["Vue de dessus", "Vue de face stricte", "Vue de dessous (contre-plongée)", "Trois-quarts"],
          answer: 2,
          explanation: "La contre-plongée accentue le nez et le menton, un effet rarement flatteur.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-3",
      title: "Focale et distorsion : comprendre l'effet du téléphone",
      summary: "Pourquoi un selfie déforme ton visage, et comment l'éviter.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "photo-lens",
      blocks: [
        {
          kind: "text",
          title: "L'effet grand-angle",
          body: "Les objectifs de téléphone sont souvent grand-angle. Pris de trop près, ils élargissent le centre de l'image : nez agrandi, oreilles reculées.",
        },
        {
          kind: "image",
          image: "photo-lens",
          caption: "Plus la distance augmente, moins la distorsion est marquée.",
        },
        {
          kind: "stat",
          value: "50-85 mm",
          label: "Focale équivalente la plus flatteuse pour un portrait",
          body: "C'est la plage utilisée en photographie de portrait car elle respecte les proportions naturelles du visage.",
        },
        {
          kind: "myth",
          myth: "Un selfie rapproché donne toujours l'image la plus fidèle.",
          truth: "C'est l'inverse : plus l'appareil est proche du visage, plus la distorsion optique déforme les proportions.",
        },
        {
          kind: "compare",
          title: "Selfie rapproché vs photo à distance",
          left: { label: "Photo à distance (zoom léger)", items: ["Proportions respectées", "Moins de distorsion", "Rendu plus naturel"] },
          right: { label: "Selfie très rapproché", items: ["Nez agrandi", "Visage aplati", "Oreilles reculées"] },
        },
        {
          kind: "steps",
          title: "Réduire la distorsion",
          items: [
            "Recule d'au moins un bras de distance",
            "Utilise le zoom léger plutôt que de t'approcher",
            "Demande à quelqu'un de prendre la photo si possible",
          ],
        },
        {
          kind: "warn",
          title: "Zoom numérique, attention",
          body: "Un zoom trop poussé sur un petit capteur de téléphone dégrade la netteté. Cherche l'équilibre entre distance et qualité.",
        },
        {
          kind: "drill",
          title: "Comparaison distance",
          body: "Prends deux photos du même visage : une en selfie rapproché, une à 1,5 m avec zoom léger. Compare les proportions.",
          duration: "3 min",
        },
        {
          kind: "quiz",
          question: "Pourquoi un selfie très rapproché déforme le visage ?",
          options: [
            "Le téléphone a un défaut technique",
            "L'objectif grand-angle élargit ce qui est proche",
            "L'écran ment sur les couleurs",
            "C'est un effet du cerveau uniquement",
          ],
          answer: 1,
          explanation: "L'effet grand-angle exagère la taille des éléments proches de l'objectif, comme le nez.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-4",
      title: "L'expression : le vrai secret d'une bonne photo",
      summary: "Un sourire forcé se voit toujours. Voici comment paraître naturel.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "photo-expression",
      blocks: [
        {
          kind: "text",
          title: "L'expression prime sur la technique",
          body: "Une photo techniquement parfaite mais avec un regard vide ou un sourire crispé ne fonctionnera jamais aussi bien qu'une photo simple mais authentique.",
        },
        {
          kind: "image",
          image: "photo-expression",
          caption: "Un sourire qui atteint les yeux change toute la photo.",
        },
        {
          kind: "list",
          title: "Signes d'un sourire authentique",
          items: [
            "Les yeux se plissent légèrement",
            "Les joues remontent",
            "La mâchoire reste détendue",
          ],
        },
        {
          kind: "myth",
          myth: "Il faut toujours sourire grand pour paraître sympathique.",
          truth: "Un léger sourire, ou même une expression neutre mais détendue, peut être plus flatteur et plus crédible qu'un grand sourire figé.",
        },
        {
          kind: "steps",
          title: "Se détendre avant la photo",
          items: [
            "Respire profondément, détends la mâchoire",
            "Pense à quelque chose d'amusant juste avant",
            "Enchaîne plusieurs photos plutôt qu'une seule pose figée",
          ],
        },
        {
          kind: "compare",
          title: "Sourire figé vs sourire naturel",
          left: { label: "Naturel", items: ["Spontané", "Yeux impliqués", "Rassure et attire"] },
          right: { label: "Figé", items: ["Forcé, visible", "Regard absent", "Donne une impression de malaise"] },
        },
        {
          kind: "drill",
          title: "Série de photos",
          body: "Fais-toi prendre en photo pendant une conversation naturelle plutôt qu'en pose statique. Regarde laquelle sort la meilleure.",
          duration: "5 min",
        },
        {
          kind: "checklist",
          title: "Avant de poser",
          items: [
            "Je détends mes épaules et ma mâchoire",
            "Je pense à un souvenir agréable",
            "J'enchaîne plusieurs prises",
          ],
        },
        {
          kind: "quiz",
          question: "Qu'est-ce qui trahit le plus un sourire forcé ?",
          options: ["La couleur des dents", "L'absence de plissement des yeux", "La position des mains", "La luminosité"],
          answer: 1,
          explanation: "Un vrai sourire mobilise les muscles autour des yeux, pas seulement la bouche.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Expressions faciales", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-5",
      title: "Tenues sur photo : ce qui rend visible ou invisible",
      summary: "Couleurs, coupes et motifs : ce qui capte le regard sur une photo.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "photo-outfit",
      blocks: [
        {
          kind: "text",
          title: "La tenue influence la lecture de la photo",
          body: "Sur une photo, une tenue trop chargée ou mal ajustée détourne l'attention du visage. L'objectif est que le regard aille d'abord à toi, pas à ton t-shirt.",
        },
        {
          kind: "image",
          image: "photo-outfit",
          caption: "Des couleurs unies et une coupe ajustée mettent le visage en valeur.",
        },
        {
          kind: "list",
          title: "Ce qui fonctionne bien en photo",
          items: [
            "Couleurs unies plutôt que motifs chargés",
            "Coupe ajustée à la carrure, ni trop large ni trop serrée",
            "Cols qui dégagent légèrement le visage",
            "Contraste net avec l'arrière-plan",
          ],
        },
        {
          kind: "compare",
          title: "Tenue qui aide vs tenue qui dessert",
          left: { label: "Tenue efficace", items: ["Couleur unie", "Coupe ajustée", "Contraste avec le fond"] },
          right: { label: "Tenue qui dessert", items: ["Motifs voyants", "Logos larges", "Couleur qui se fond dans le décor"] },
        },
        {
          kind: "myth",
          myth: "Une tenue de marque visible rend automatiquement plus stylé sur une photo.",
          truth: "Les gros logos détournent l'attention du visage et datent vite visuellement. La coupe et la couleur comptent bien plus.",
        },
        {
          kind: "steps",
          title: "Choisir sa tenue avant une photo importante",
          items: [
            "Vérifie le contraste avec le fond prévu",
            "Privilégie une couleur unie proche du haut du corps",
            "Évite les vêtements neufs jamais testés en photo",
          ],
        },
        {
          kind: "warn",
          title: "Attention au fond",
          body: "Une tenue peut être parfaite mais se fondre complètement dans un arrière-plan de la même couleur. Vérifie toujours le contraste avant.",
        },
        {
          kind: "drill",
          title: "Test devant le miroir",
          body: "Prends une photo test avec ta tenue prévue et le fond réel. Regarde si ton visage reste le point central.",
          duration: "3 min",
        },
        {
          kind: "quiz",
          question: "Pourquoi éviter les gros logos sur une photo importante ?",
          options: [
            "Ils sont interdits légalement",
            "Ils détournent l'attention du visage",
            "Ils rendent la photo plus lumineuse",
            "Ils n'ont aucun effet visuel",
          ],
          answer: 1,
          explanation: "Les logos et motifs voyants attirent l'œil au détriment du visage, qui doit rester le point focal.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-6",
      title: "Choisir ses photos de profil : la méthode",
      summary: "Comment sélectionner objectivement les meilleures photos, sans se fier au feeling seul.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "photo-selection",
      blocks: [
        {
          kind: "text",
          title: "Sortir du jugement solitaire",
          body: "On est souvent mauvais juge de ses propres photos, à force de les regarder. Une méthode simple et un avis extérieur valent mieux que l'intuition seule.",
        },
        {
          kind: "image",
          image: "photo-selection",
          caption: "Varier les contextes donne une image plus complète et plus crédible.",
        },
        {
          kind: "steps",
          title: "Construire une bonne sélection",
          items: [
            "Choisis une photo nette en gros plan, visage bien visible",
            "Ajoute une photo en pied, pour montrer ta silhouette réelle",
            "Inclus une photo en contexte social ou d'activité",
            "Évite les photos de groupe en premier visuel",
          ],
        },
        {
          kind: "list",
          title: "Critères à vérifier sur chaque photo",
          items: [
            "Le visage est net et bien identifiable",
            "La lumière est flatteuse",
            "L'expression semble naturelle",
            "La tenue ne détourne pas l'attention",
          ],
        },
        {
          kind: "compare",
          title: "Bonne sélection vs sélection au hasard",
          left: { label: "Sélection réfléchie", items: ["Variée", "Cohérente", "Montre plusieurs facettes"] },
          right: { label: "Sélection au hasard", items: ["Photos trop similaires", "Visage peu visible", "Qualité inégale"] },
        },
        {
          kind: "myth",
          myth: "Plus il y a de photos, mieux c'est.",
          truth: "Une sélection courte mais cohérente est plus efficace qu'un grand nombre de photos redondantes ou de mauvaise qualité.",
        },
        {
          kind: "drill",
          title: "Demande un avis extérieur",
          body: "Montre 5 photos à une personne de confiance et demande-lui de classer les 3 meilleures, sans expliquer pourquoi au préalable.",
          duration: "5 min",
        },
        {
          kind: "checklist",
          title: "Check finale avant publication",
          items: [
            "J'ai une photo nette du visage",
            "J'ai une photo en pied",
            "J'ai une photo en contexte",
            "J'ai demandé un avis extérieur",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi demander un avis extérieur sur ses photos ?",
          options: [
            "Parce que c'est plus rapide",
            "Parce qu'on juge mal ses propres photos à force de les revoir",
            "Parce que c'est obligatoire",
            "Parce que ça améliore la qualité de l'image",
          ],
          answer: 1,
          explanation: "La familiarité avec sa propre image biaise le jugement ; un regard extérieur est plus objectif.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception de soi", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-7",
      title: "Les erreurs classiques à éviter",
      summary: "Les pièges les plus fréquents qui plombent une photo autrement correcte.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "photo-mistakes",
      blocks: [
        {
          kind: "text",
          title: "Des petites erreurs, un grand impact",
          body: "La plupart des mauvaises photos ne viennent pas d'un manque de matériel, mais de détails simples négligés.",
        },
        {
          kind: "image",
          image: "photo-mistakes",
          caption: "Un fond encombré détourne l'attention même sur une bonne photo.",
        },
        {
          kind: "list",
          title: "Erreurs fréquentes",
          items: [
            "Selfie en miroir avec le téléphone visible",
            "Fond encombré ou désordonné",
            "Photo floue ou pixelisée",
            "Lunettes de soleil qui cachent le regard",
            "Filtre excessif qui déforme les traits",
          ],
        },
        {
          kind: "myth",
          myth: "Un bon filtre peut sauver n'importe quelle photo.",
          truth: "Un filtre trop marqué se voit immédiatement et donne une impression d'artifice, souvent contre-productive.",
        },
        {
          kind: "compare",
          title: "Photo soignée vs photo négligée",
          left: { label: "Photo soignée", items: ["Fond neutre", "Netteté correcte", "Regard visible"] },
          right: { label: "Photo négligée", items: ["Fond chargé", "Flou", "Visage partiellement caché"] },
        },
        {
          kind: "warn",
          title: "Attention aux photos trop vieilles",
          body: "Utiliser une photo qui ne te ressemble plus crée un décalage gênant en vrai. Privilégie des photos récentes.",
        },
        {
          kind: "steps",
          title: "Vérification rapide avant de publier",
          items: [
            "Le fond est-il propre et neutre ?",
            "Le visage est-il net et visible ?",
            "La photo date-t-elle de moins d'un an ?",
          ],
        },
        {
          kind: "checklist",
          title: "Derniers réflexes",
          items: [
            "Pas de selfie miroir avec téléphone visible",
            "Pas de lunettes de soleil sur la photo principale",
            "Filtre léger ou absent",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi éviter les lunettes de soleil sur une photo principale ?",
          options: [
            "Elles ne sont pas à la mode",
            "Elles cachent le regard, élément clé de l'expression",
            "Elles coûtent cher",
            "Elles changent la couleur de la photo",
          ],
          answer: 1,
          explanation: "Le regard est central dans la lecture d'une expression ; le cacher rend la photo moins engageante.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-8",
      title: "Construire une série cohérente",
      summary: "Penser tes photos comme un ensemble, pas comme des clichés isolés.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "photo-series",
      blocks: [
        {
          kind: "text",
          title: "L'effet d'ensemble compte",
          body: "Une série de photos cohérente raconte une histoire plus crédible qu'une accumulation de clichés déconnectés les uns des autres.",
        },
        {
          kind: "image",
          image: "photo-series",
          caption: "Varier les décors tout en gardant une cohérence de qualité.",
        },
        {
          kind: "list",
          title: "Éléments de cohérence",
          items: [
            "Qualité d'image homogène entre les photos",
            "Diversité des contextes (intérieur, extérieur, activité)",
            "Une seule photo de groupe maximum",
            "Pas de doublon de pose ou d'angle",
          ],
        },
        {
          kind: "steps",
          title: "Construire sa série",
          items: [
            "Sélectionne 4 à 6 photos maximum",
            "Vérifie qu'aucune ne se ressemble trop",
            "Place la meilleure photo en premier",
            "Fais valider par un regard extérieur",
          ],
        },
        {
          kind: "compare",
          title: "Série cohérente vs série disparate",
          left: { label: "Cohérente", items: ["Qualité stable", "Contextes variés", "Histoire lisible"] },
          right: { label: "Disparate", items: ["Qualité inégale", "Photos redondantes", "Pas de fil conducteur"] },
        },
        {
          kind: "myth",
          myth: "Toutes les photos doivent être prises le même jour pour être cohérentes.",
          truth: "La cohérence vient de la qualité et du ton général, pas de la date de prise de vue.",
        },
        {
          kind: "drill",
          title: "Test de la série",
          body: "Aligne tes 5 meilleures photos côte à côte et vérifie qu'elles racontent des choses différentes de toi.",
          duration: "5 min",
        },
        {
          kind: "quiz",
          question: "Qu'est-ce qui définit une série de photos cohérente ?",
          options: [
            "Toutes les photos prises le même jour",
            "Une qualité homogène et des contextes variés",
            "Le même filtre partout",
            "Uniquement des photos en intérieur",
          ],
          answer: 1,
          explanation: "La cohérence tient à la qualité stable et à la diversité des contextes, pas à la date ou au filtre.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-9",
      title: "Retouche : où placer la limite",
      summary: "Améliorer une photo sans tomber dans l'artifice qui se voit.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "photo-editing",
      blocks: [
        {
          kind: "text",
          title: "Retoucher n'est pas mentir",
          body: "Ajuster la luminosité ou le contraste, c'est normal. Le problème commence quand la retouche modifie la morphologie réelle du visage ou du corps.",
        },
        {
          kind: "image",
          image: "photo-editing",
          caption: "Un ajustement léger de lumière reste honnête et flatteur.",
        },
        {
          kind: "list",
          title: "Retouches acceptables",
          items: [
            "Ajustement de luminosité et de contraste",
            "Correction légère de la balance des couleurs",
            "Recadrage",
          ],
        },
        {
          kind: "warn",
          title: "Ce qui pose problème",
          body: "Modifier la forme du visage, la carrure ou la taille crée un écart avec la réalité qui se remarque immédiatement en personne, et nuit à la confiance.",
        },
        {
          kind: "myth",
          myth: "Tout le monde retouche fortement ses photos, donc c'est normal de le faire aussi.",
          truth: "La retouche excessive est justement identifiée rapidement par l'œil humain et associée à un manque d'authenticité.",
        },
        {
          kind: "compare",
          title: "Retouche légère vs retouche excessive",
          left: { label: "Légère", items: ["Reste crédible", "Corrige la lumière", "Ne change pas la morphologie"] },
          right: { label: "Excessive", items: ["Se voit à l'œil nu", "Crée un décalage avec le réel", "Nuit à la confiance en rencontre"] },
        },
        {
          kind: "steps",
          title: "Checklist retouche",
          items: [
            "Je corrige la lumière et le contraste seulement",
            "Je ne modifie pas les proportions du visage",
            "Je me demande si la photo me ressemble encore en vrai",
          ],
        },
        {
          kind: "drill",
          title: "Test miroir",
          body: "Compare ta photo retouchée à ton reflet dans un miroir : si l'écart est flagrant, réduis la retouche.",
          duration: "3 min",
        },
        {
          kind: "quiz",
          question: "Quelle retouche pose le plus problème ?",
          options: [
            "Ajuster la luminosité",
            "Recadrer l'image",
            "Modifier la morphologie du visage",
            "Corriger la balance des couleurs",
          ],
          answer: 2,
          explanation: "Modifier la morphologie crée un décalage avec la réalité, repérable en personne.",
        },
        {
          kind: "quiz",
          question: "Pourquoi la retouche excessive est-elle risquée sur le long terme ?",
          options: [
            "Elle coûte cher en applications",
            "Elle crée un décalage qui nuit à la confiance en rencontre",
            "Elle est illégale",
            "Elle prend du temps à réaliser",
          ],
          answer: 1,
          explanation: "L'écart entre photo et réalité se remarque vite et fragilise la confiance dès la première rencontre.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception de soi", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-10",
      title: "Composition : cadrage et arrière-plan",
      summary: "Les règles simples de composition qui rendent une photo plus lisible.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "photo-composition",
      blocks: [
        {
          kind: "text",
          title: "Le cadrage guide le regard",
          body: "Une bonne composition dirige naturellement l'œil vers le visage. Un cadrage maladroit disperse l'attention sur des éléments secondaires.",
        },
        {
          kind: "image",
          image: "photo-composition",
          caption: "La règle des tiers place le sujet hors du centre strict.",
        },
        {
          kind: "list",
          title: "Principes de base",
          items: [
            "Règle des tiers : place les yeux sur une ligne de force",
            "Laisse de l'espace au-dessus de la tête, sans excès",
            "Évite de couper les membres à des endroits inhabituels",
            "Choisis un fond qui ne rivalise pas avec le sujet",
          ],
        },
        {
          kind: "compare",
          title: "Cadrage travaillé vs cadrage négligé",
          left: { label: "Travaillé", items: ["Sujet bien positionné", "Fond dégagé", "Regard guidé naturellement"] },
          right: { label: "Négligé", items: ["Sujet centré au hasard", "Fond distrayant", "Cadrage trop serré ou trop large"] },
        },
        {
          kind: "myth",
          myth: "Centrer parfaitement le sujet donne toujours la meilleure photo.",
          truth: "Un centrage strict peut sembler statique. La règle des tiers crée souvent une composition plus dynamique et agréable.",
        },
        {
          kind: "warn",
          title: "Attention aux éléments parasites",
          body: "Un poteau qui semble sortir de la tête, un objet flou au premier plan : ces détails passent inaperçus sur le moment mais sautent aux yeux ensuite.",
        },
        {
          kind: "steps",
          title: "Vérifier son cadrage",
          items: [
            "Balaie le fond du regard avant de shooter",
            "Positionne le sujet sur un tiers de l'image",
            "Vérifie qu'aucun élément ne coupe le corps de façon gênante",
          ],
        },
        {
          kind: "drill",
          title: "Exercice de cadrage",
          body: "Prends la même photo avec le sujet centré, puis décalé selon la règle des tiers. Compare les deux rendus.",
          duration: "5 min",
        },
        {
          kind: "quiz",
          question: "Que propose la règle des tiers ?",
          options: [
            "Centrer parfaitement le sujet",
            "Placer le sujet sur une ligne de force, hors du centre strict",
            "Toujours photographier en gros plan",
            "Utiliser trois flashs différents",
          ],
          answer: 1,
          explanation: "La règle des tiers positionne le sujet sur des lignes de force pour une composition plus dynamique.",
        },
        {
          kind: "quiz",
          question: "Pourquoi vérifier le fond avant de prendre la photo ?",
          options: [
            "Pour gagner du temps",
            "Pour éviter des éléments parasites qui distraient",
            "Parce que c'est obligatoire",
            "Pour changer la météo",
          ],
          answer: 1,
          explanation: "Un fond mal vérifié peut inclure des éléments distrayants ou disgracieux, invisibles sur le moment.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-11",
      title: "Photo de groupe : s'y démarquer intelligemment",
      summary: "Comment ne pas disparaître, ni sembler artificiel, sur une photo à plusieurs.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "photo-group",
      blocks: [
        {
          kind: "text",
          title: "Le piège de la photo de groupe",
          body: "Sur une photo à plusieurs, l'œil ne sait pas toujours où se poser. Se démarquer subtilement aide sans que ça se voie.",
        },
        {
          kind: "image",
          image: "photo-group",
          caption: "Une position légèrement avancée capte davantage l'attention.",
        },
        {
          kind: "list",
          title: "Astuces simples",
          items: [
            "Se positionner légèrement en avant du groupe",
            "Garder une posture ouverte, épaules droites",
            "Éviter d'être coupé sur le bord de la photo",
            "Regarder l'objectif plutôt que le vide",
          ],
        },
        {
          kind: "compare",
          title: "Position centrale vs position en bord",
          left: { label: "Position centrale ou légèrement avancée", items: ["Plus visible", "Regard naturellement attiré", "Meilleure lisibilité"] },
          right: { label: "Bord de photo", items: ["Souvent coupé", "Moins visible", "Angle déformé"] },
        },
        {
          kind: "myth",
          myth: "Être au centre exact du groupe garantit d'être le plus visible.",
          truth: "La position légèrement avancée ou la posture comptent souvent davantage que la position centrale stricte.",
        },
        {
          kind: "steps",
          title: "Avant une photo de groupe",
          items: [
            "Repère où se place la lumière principale",
            "Choisis une position dégagée, pas sur le bord",
            "Garde une posture droite et détendue",
          ],
        },
        {
          kind: "warn",
          title: "Ne pas forcer artificiellement",
          body: "Vouloir trop se démarquer (pose exagérée, sourire forcé) produit l'effet inverse et attire l'attention pour de mauvaises raisons.",
        },
        {
          kind: "drill",
          title: "Observation",
          body: "Regarde une photo de groupe où tu ressors bien et identifie ce qui fait que ton regard s'y pose en premier.",
          duration: "3 min",
        },
        {
          kind: "quiz",
          question: "Qu'est-ce qui aide vraiment à se démarquer sur une photo de groupe ?",
          options: [
            "Une pose exagérée",
            "Une posture ouverte et une bonne position",
            "Se placer tout au bord",
            "Ne pas regarder l'objectif",
          ],
          answer: 1,
          explanation: "Une posture ouverte et une position bien choisie sont plus efficaces qu'une pose forcée.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-12",
      title: "Constance dans le temps : garder des photos à jour",
      summary: "Pourquoi actualiser régulièrement ses photos change la perception que les autres ont de toi.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "photo-timeline",
      blocks: [
        {
          kind: "text",
          title: "L'écart photo-réalité coûte cher",
          body: "Une photo qui ne correspond plus à ton apparence actuelle crée un décalage gênant lors d'une rencontre en personne, même sans mauvaise intention de ta part.",
        },
        {
          kind: "image",
          image: "photo-timeline",
          caption: "Mettre à jour ses photos tous les 6 à 12 mois reste un bon repère.",
        },
        {
          kind: "stat",
          value: "6 à 12 mois",
          label: "Fréquence raisonnable de mise à jour des photos",
          body: "Un repère pratique pour rester représentatif, surtout après un changement de coupe, de poids ou de style.",
        },
        {
          kind: "myth",
          myth: "Une bonne photo reste valable indéfiniment si elle est de bonne qualité technique.",
          truth: "La qualité technique ne suffit pas si la photo ne reflète plus ton apparence actuelle.",
        },
        {
          kind: "list",
          title: "Signaux qu'il faut actualiser",
          items: [
            "Changement de coiffure ou de barbe notable",
            "Changement de poids visible",
            "La photo a plus d'un an",
            "Tu ne te reconnais plus vraiment dessus",
          ],
        },
        {
          kind: "compare",
          title: "Photos à jour vs photos datées",
          left: { label: "À jour", items: ["Cohérence avec la réalité", "Confiance renforcée", "Pas de surprise en rencontre"] },
          right: { label: "Datées", items: ["Décalage à la rencontre", "Perte de confiance", "Effet parfois négatif à long terme"] },
        },
        {
          kind: "warn",
          title: "Ne pas tomber dans l'excès inverse",
          body: "Changer ses photos trop souvent sans raison peut aussi donner une image instable. L'objectif est la justesse, pas la fréquence maximale.",
        },
        {
          kind: "steps",
          title: "Routine simple",
          items: [
            "Fixe-toi un rappel tous les 6 mois pour vérifier tes photos",
            "Remplace les photos qui ne te ressemblent plus",
            "Garde toujours au moins une photo récente en priorité",
          ],
        },
        {
          kind: "quiz",
          question: "Que risque une photo trop ancienne malgré une bonne qualité technique ?",
          options: [
            "Rien, la qualité suffit",
            "Un décalage avec la réalité lors d'une rencontre",
            "Une meilleure impression",
            "Un flou technique",
          ],
          answer: 1,
          explanation: "Une photo datée peut être techniquement bonne mais créer un décalage gênant en rencontre réelle.",
        },
        {
          kind: "quiz",
          question: "Quel est le bon réflexe concernant la fréquence de mise à jour ?",
          options: [
            "Changer les photos chaque semaine",
            "Ne jamais changer les photos",
            "Actualiser environ tous les 6 à 12 mois ou après un changement notable",
            "Attendre 5 ans minimum",
          ],
          answer: 2,
          explanation: "Un repère de 6 à 12 mois, ajusté selon les changements physiques, garde les photos représentatives.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception de soi", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "photo-13",
      title: "Bonus : construire son shooting complet",
      summary: "Une méthode complète pour organiser une séance photo efficace, seul ou accompagné.",
      difficulty: "hard",
      minutes: 12,
      xp: 200,
      tier: "pro",
      requiresLevel: 4,
      cover: "photo-shoot",
      blocks: [
        {
          kind: "text",
          title: "Penser la séance en amont",
          body: "Une bonne séance photo se prépare : lumière, tenues, lieux et enchaînement des prises. L'improvisation totale donne rarement le meilleur résultat.",
        },
        {
          kind: "image",
          image: "photo-shoot",
          caption: "Varier les lieux dans une même séance enrichit la sélection finale.",
        },
        {
          kind: "steps",
          title: "Préparer sa séance",
          items: [
            "Choisis un créneau avec une lumière naturelle favorable",
            "Prépare 2 à 3 tenues différentes mais cohérentes",
            "Prévois 2 lieux : un extérieur, un plus posé",
            "Planifie environ 30 à 45 minutes, sans te presser",
          ],
        },
        {
          kind: "list",
          title: "Déroulé type",
          items: [
            "Échauffement : quelques photos sans enjeu pour se détendre",
            "Série portrait rapproché",
            "Série en pied",
            "Série en contexte ou activité",
          ],
        },
        {
          kind: "compare",
          title: "Séance préparée vs improvisée",
          left: { label: "Préparée", items: ["Variété maîtrisée", "Moins de déchet", "Sélection plus riche"] },
          right: { label: "Improvisée", items: ["Résultats inégaux", "Peu de variété", "Souvent moins abouties"] },
        },
        {
          kind: "myth",
          myth: "Il faut un photographe professionnel pour obtenir de bonnes photos.",
          truth: "Un ami avec un bon téléphone, une lumière correcte et un peu de méthode suffit largement dans la majorité des cas.",
        },
        {
          kind: "warn",
          title: "Ne pas viser la perfection immédiate",
          body: "Les meilleures photos viennent souvent après plusieurs dizaines de prises, une fois que la gêne initiale est passée.",
        },
        {
          kind: "drill",
          title: "Séance test",
          body: "Organise une mini-séance de 20 minutes avec un proche, en suivant le déroulé type. Sélectionne ensuite tes 3 meilleures photos.",
          duration: "20 min",
        },
        {
          kind: "checklist",
          title: "Checklist séance complète",
          items: [
            "Lumière vérifiée à l'avance",
            "Tenues préparées et cohérentes",
            "Deux lieux prévus",
            "Temps suffisant sans précipitation",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi prévoir un temps d'échauffement en début de séance ?",
          options: [
            "Pour économiser la batterie",
            "Pour se détendre avant les photos importantes",
            "Parce que c'est obligatoire techniquement",
            "Pour tester la météo",
          ],
          answer: 1,
          explanation: "Les premières minutes servent à relâcher la gêne, ce qui améliore naturellement les photos suivantes.",
        },
        {
          kind: "quiz",
          question: "Que privilégier plutôt qu'un photographe professionnel dans la plupart des cas ?",
          options: [
            "Aucune photo n'est possible sans professionnel",
            "Un proche, une lumière correcte et de la méthode",
            "Uniquement des photos de studio",
            "Un logiciel de retouche avancé",
          ],
          answer: 1,
          explanation: "Avec de la lumière, de la méthode et un peu de temps, un résultat solide est accessible sans professionnel.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Perception visuelle", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
  ],
};
