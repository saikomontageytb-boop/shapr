import type { Track } from "@/lib/academy-types";

export const supplements: Track = {
  id: "supplements",
  title: "Compléments",
  tagline: "Ce qui marche, ce qui ne sert à rien.",
  intro:
    "La créatine, la vitamine D, les oméga-3 : tri entre ce qui a des preuves solides et ce qui n'est que du marketing.",
  icon: "apple",
  cover: "supplements-cover",
  lessons: [
    {
      id: "supplements-1",
      title: "Créatine : le plus étudié de tous",
      summary: "Un complément peu coûteux avec une montagne de preuves derrière lui.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "supplements-creatine",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi la créatine fonctionne",
          body: "Elle augmente les réserves de phosphocréatine dans le muscle, ce qui améliore la performance sur les efforts courts et intenses et favorise la prise de masse maigre avec l'entraînement.",
        },
        {
          kind: "image",
          image: "supplements-creatine",
          caption: "Poudre de créatine monohydrate : la forme la plus étudiée et la moins chère.",
        },
        {
          kind: "stat",
          value: "3 à 5 g/jour",
          label: "Dose d'entretien recommandée",
          body: "Pas besoin de phase de charge : une dose quotidienne stable suffit à saturer les réserves en 3 à 4 semaines.",
        },
        {
          kind: "list",
          title: "Bénéfices documentés",
          items: [
            "Force et puissance en musculation",
            "Récupération entre les séries",
            "Léger effet possible sur la cognition",
          ],
        },
        {
          kind: "myth",
          myth: "La créatine est un stéroïde déguisé.",
          truth: "C'est une molécule que ton corps produit déjà naturellement, présente aussi dans la viande et le poisson. Rien à voir avec les hormones anabolisantes.",
        },
        {
          kind: "myth",
          myth: "La créatine abîme les reins chez une personne saine.",
          truth: "Les études sur plusieurs années chez des personnes sans pathologie rénale ne montrent pas de dommage.",
        },
        {
          kind: "steps",
          title: "Comment la prendre",
          items: [
            "Choisis de la créatine monohydrate, forme la plus étudiée",
            "3 à 5 g par jour, tous les jours, peu importe l'heure",
            "Bois suffisamment d'eau dans la journée",
          ],
        },
        {
          kind: "checklist",
          title: "Avant de commencer",
          items: [
            "Je vise 3 à 5 g par jour",
            "Je prends un produit simple (monohydrate seul)",
            "Je ne m'attends pas à un miracle sans entraînement",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle est la dose d'entretien courante de créatine ?",
          options: ["0,5 g/jour", "3 à 5 g/jour", "20 g/jour", "50 g/jour"],
          answer: 1,
          explanation: "3 à 5 g par jour suffisent à maintenir des réserves musculaires saturées.",
        },
        {
          kind: "sources",
          items: [
            { label: "Examine.com – Creatine", url: "https://examine.com/" },
            { label: "NCBI", url: "https://www.ncbi.nlm.nih.gov/" },
          ],
        },
      ],
    },
    {
      id: "supplements-2",
      title: "Vitamine D : le manque le plus fréquent",
      summary: "Pourquoi une bonne partie de la population en manque, surtout en hiver.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "supplements-vitamind",
      blocks: [
        {
          kind: "text",
          title: "Un rôle qui dépasse les os",
          body: "La vitamine D participe à la santé osseuse, immunitaire et musculaire. Ton corps la produit principalement grâce au soleil sur la peau, pas via l'alimentation.",
        },
        {
          kind: "image",
          image: "supplements-vitamind",
          caption: "L'exposition solaire reste la première source de vitamine D.",
        },
        {
          kind: "stat",
          value: "~40 à 60 %",
          label: "Part de la population avec un statut insuffisant en hiver",
          body: "Dans les pays à latitude élevée, le manque d'ensoleillement en hiver réduit fortement la synthèse cutanée.",
        },
        {
          kind: "list",
          title: "Facteurs de risque de carence",
          items: [
            "Peau mate ou foncée sous climat peu ensoleillé",
            "Vie principalement en intérieur",
            "Hiver et latitude élevée",
            "Âge avancé",
          ],
        },
        {
          kind: "myth",
          myth: "Manger du poisson suffit à couvrir tes besoins en vitamine D.",
          truth: "L'alimentation ne couvre qu'une petite partie des besoins ; le soleil reste la source principale, la supplémentation un complément utile en hiver.",
        },
        {
          kind: "steps",
          title: "Réflexes simples",
          items: [
            "Sors à la lumière du jour régulièrement, même en hiver",
            "Envisage une supplémentation d'octobre à mars sous conseil médical",
            "Fais doser ta vitamine D si tu as des doutes",
          ],
        },
        {
          kind: "warn",
          title: "Ne pas se supplémenter au hasard",
          body: "Un surdosage prolongé de vitamine D peut être toxique. Vérifie tes apports avec un professionnel de santé, surtout à forte dose.",
        },
        {
          kind: "checklist",
          title: "Ton bilan hiver",
          items: [
            "Je m'expose à la lumière naturelle chaque jour si possible",
            "Je connais mon statut si j'ai des symptômes de fatigue chronique",
            "Je ne dépasse pas les doses recommandées sans avis médical",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle est la principale source naturelle de vitamine D ?",
          options: ["Les fruits", "L'exposition au soleil", "Le pain", "L'eau"],
          answer: 1,
          explanation: "La synthèse cutanée sous l'effet du soleil est la source principale, loin devant l'alimentation.",
        },
        {
          kind: "sources",
          items: [
            { label: "ODS NIH – Vitamin D", url: "https://ods.od.nih.gov/" },
            { label: "ANSES", url: "https://www.anses.fr/" },
          ],
        },
      ],
    },
    {
      id: "supplements-3",
      title: "Oméga-3 : bénéfices réels, nuances importantes",
      summary: "Un allié cardiovasculaire, mais pas la potion magique vendue partout.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "supplements-omega3",
      blocks: [
        {
          kind: "text",
          title: "EPA et DHA, les deux à connaître",
          body: "Ce sont les acides gras oméga-3 actifs, présents surtout dans les poissons gras. Ils participent à la santé cardiovasculaire et à la structure des membranes cellulaires, notamment cérébrales.",
        },
        {
          kind: "image",
          image: "supplements-omega3",
          caption: "Saumon, maquereau, sardines : les meilleures sources naturelles d'EPA et DHA.",
        },
        {
          kind: "stat",
          value: "2 portions/semaine",
          label: "Repère de poisson gras recommandé",
          body: "Un apport régulier via l'alimentation couvre les besoins pour la plupart des adultes en bonne santé.",
        },
        {
          kind: "compare",
          title: "Poisson vs complément",
          left: { label: "Poisson gras", items: ["EPA/DHA + protéines", "Effet de satiété", "Moins de risque d'oxydation"] },
          right: { label: "Gélules d'huile de poisson", items: ["Utile si peu de poisson consommé", "Qualité variable selon marque", "Peut s'oxyder si mal stocké"] },
        },
        {
          kind: "myth",
          myth: "Les oméga-3 en gélule remplacent totalement le poisson.",
          truth: "Les compléments apportent EPA/DHA mais pas les autres nutriments du poisson (protéines, iode, sélénium).",
        },
        {
          kind: "list",
          title: "Bénéfices avec un niveau de preuve correct",
          items: [
            "Réduction modérée des triglycérides sanguins",
            "Soutien à la santé cardiovasculaire chez les personnes à risque",
            "Rôle dans le développement cérébral (grossesse, petite enfance)",
          ],
        },
        {
          kind: "warn",
          title: "Pas une protection universelle",
          body: "Les effets sur la prévention des maladies cardiovasculaires chez une personne en bonne santé sont plus modestes que ce que le marketing laisse penser.",
        },
        {
          kind: "steps",
          title: "Comment faire simple",
          items: [
            "Mange du poisson gras deux fois par semaine si possible",
            "Complète avec une huile de poisson de qualité si tu manges peu de poisson",
            "Vérifie la teneur réelle en EPA/DHA sur l'étiquette, pas juste 'huile de poisson'",
          ],
        },
        {
          kind: "quiz",
          question: "Quels sont les deux oméga-3 actifs à privilégier ?",
          options: ["ALA et oméga-6", "EPA et DHA", "Oméga-9 et fibres", "Vitamine E et fer"],
          answer: 1,
          explanation: "L'EPA et le DHA sont les formes actives les mieux documentées, présentes surtout dans les poissons gras.",
        },
        {
          kind: "sources",
          items: [
            { label: "ODS NIH – Omega-3", url: "https://ods.od.nih.gov/" },
            { label: "Cochrane", url: "https://www.cochrane.org/" },
          ],
        },
      ],
    },
    {
      id: "supplements-4",
      title: "Magnésium : utile mais mal ciblé",
      summary: "Souvent pris pour la fatigue, rarement pris de la bonne forme.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "supplements-magnesium",
      blocks: [
        {
          kind: "text",
          title: "Un minéral impliqué dans des centaines de réactions",
          body: "Le magnésium intervient dans la fonction musculaire, nerveuse et énergétique. Une carence franche est rare chez une personne qui mange varié, mais des apports limites sont fréquents.",
        },
        {
          kind: "image",
          image: "supplements-magnesium",
          caption: "Oléagineux, légumineuses et céréales complètes sont de bonnes sources.",
        },
        {
          kind: "list",
          title: "Signes possibles d'apport insuffisant",
          items: ["Crampes musculaires", "Fatigue", "Irritabilité", "Troubles du sommeil"],
        },
        {
          kind: "myth",
          myth: "Toutes les formes de magnésium se valent.",
          truth: "L'oxyde de magnésium, très courant et peu cher, est mal absorbé. Le bisglycinate ou le citrate sont mieux tolérés et mieux assimilés.",
        },
        {
          kind: "compare",
          title: "Formes de magnésium",
          left: { label: "Bien absorbées", items: ["Bisglycinate", "Citrate", "Malate"] },
          right: { label: "Moins bien absorbées", items: ["Oxyde", "Sulfate (effet laxatif)"] },
        },
        {
          kind: "stat",
          value: "300 à 400 mg/jour",
          label: "Apport recommandé pour un adulte",
          body: "Variable selon le poids et le sexe ; une alimentation variée couvre souvent une bonne partie du besoin.",
        },
        {
          kind: "warn",
          title: "Pas un somnifère",
          body: "Le magnésium peut aider en cas de carence réelle, mais ce n'est pas un traitement du stress ou de l'insomnie en soi.",
        },
        {
          kind: "steps",
          title: "Avant de te supplémenter",
          items: [
            "Regarde d'abord ton alimentation (oléagineux, légumineuses, chocolat noir)",
            "Choisis une forme bien absorbée si tu complètes",
            "N'attends pas un effet immédiat, laisse quelques semaines",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle forme de magnésium est généralement mal absorbée ?",
          options: ["Bisglycinate", "Citrate", "Oxyde", "Malate"],
          answer: 2,
          explanation: "L'oxyde de magnésium a une biodisponibilité faible comparée aux autres formes.",
        },
        {
          kind: "sources",
          items: [
            { label: "ODS NIH – Magnesium", url: "https://ods.od.nih.gov/" },
            { label: "ANSES", url: "https://www.anses.fr/" },
          ],
        },
      ],
    },
    {
      id: "supplements-5",
      title: "Whey : un outil pratique, pas magique",
      summary: "La whey n'est qu'une protéine en poudre, ni plus ni moins.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "supplements-whey",
      blocks: [
        {
          kind: "text",
          title: "Ce qu'est vraiment la whey",
          body: "C'est une protéine issue du lactosérum, riche en acides aminés essentiels et rapidement digérée. Elle sert avant tout à atteindre plus facilement ton total quotidien de protéines.",
        },
        {
          kind: "image",
          image: "supplements-whey",
          caption: "Un shaker de whey peut remplacer une collation protéinée, pas un repas complet.",
        },
        {
          kind: "compare",
          title: "Whey vs aliments entiers",
          left: { label: "Whey", items: ["Pratique et rapide", "Peu de calories superflues", "Utile en déplacement"] },
          right: { label: "Aliments entiers", items: ["Apportent aussi vitamines et fibres", "Plus rassasiants", "Moins chers au gramme de protéine"] },
        },
        {
          kind: "myth",
          myth: "Sans whey, impossible de prendre du muscle.",
          truth: "La whey est un outil de confort, pas un ingrédient indispensable. Le total de protéines sur la journée compte bien plus que sa source.",
        },
        {
          kind: "list",
          title: "Quand elle est utile",
          items: [
            "Juste après l'entraînement si le repas suivant est loin",
            "Pour atteindre ton total protéique sans trop manger",
            "En déplacement, quand cuisiner n'est pas possible",
          ],
        },
        {
          kind: "steps",
          title: "Bien choisir sa whey",
          items: [
            "Vérifie la teneur en protéines pour 30 g de poudre (vise 20 g et plus)",
            "Regarde la liste des ingrédients, pas juste le marketing",
            "Teste la tolérance digestive (le lactose peut gêner certains)",
          ],
        },
        {
          kind: "warn",
          title: "Pas un besoin universel",
          body: "Si tu manges déjà suffisamment de protéines via l'alimentation, la whey n'apporte rien de plus déterminant.",
        },
        {
          kind: "quiz",
          question: "À quoi sert principalement la whey ?",
          options: [
            "Elle remplace le sommeil",
            "Elle aide à atteindre ton total de protéines plus facilement",
            "Elle brûle les graisses directement",
            "Elle est indispensable pour progresser",
          ],
          answer: 1,
          explanation: "La whey est un moyen pratique d'augmenter ses apports en protéines, rien de plus.",
        },
        {
          kind: "sources",
          items: [
            { label: "Examine.com – Whey Protein", url: "https://examine.com/" },
            { label: "ANSES", url: "https://www.anses.fr/" },
          ],
        },
      ],
    },
    {
      id: "supplements-6",
      title: "Caféine : le stimulant le plus utilisé au monde",
      summary: "Efficace, mais avec une fenêtre de dose et de timing à respecter.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "supplements-caffeine",
      blocks: [
        {
          kind: "text",
          title: "Comment elle agit",
          body: "La caféine bloque les récepteurs à l'adénosine, la molécule qui te donne envie de dormir. Résultat : plus de vigilance perçue et un léger gain de performance physique et cognitive.",
        },
        {
          kind: "image",
          image: "supplements-caffeine",
          caption: "Café, thé, ou complément pur : la dose compte plus que la source.",
        },
        {
          kind: "stat",
          value: "3 à 6 mg/kg",
          label: "Dose efficace pour la performance sportive",
          body: "Pour un homme de 75 kg, ça représente environ 225 à 450 mg, à prendre 30 à 60 minutes avant l'effort.",
        },
        {
          kind: "list",
          title: "Effets documentés",
          items: [
            "Amélioration de l'endurance et de la puissance",
            "Réduction de la perception de l'effort",
            "Meilleure vigilance en cas de manque de sommeil (mais ne le remplace pas)",
          ],
        },
        {
          kind: "myth",
          myth: "La caféine déshydrate fortement.",
          truth: "À dose modérée et chez un consommateur régulier, l'effet diurétique est faible et ne cause pas de déshydratation notable.",
        },
        {
          kind: "compare",
          title: "Bon usage vs mauvais usage",
          left: { label: "Bon usage", items: ["Dose stable et connue", "Pas après 14-16h", "Pause régulière pour garder l'effet"] },
          right: { label: "Mauvais usage", items: ["Multiplier les sources sans compter", "Consommation tard le soir", "Utiliser pour compenser un manque de sommeil chronique"] },
        },
        {
          kind: "warn",
          title: "Attention au cumul et au sommeil",
          body: "La caféine a une demi-vie de 5 à 6 heures : une prise l'après-midi peut encore perturber ton endormissement le soir.",
        },
        {
          kind: "drill",
          title: "Test de fenêtre",
          body: "Note l'heure de ta dernière prise de caféine pendant une semaine et observe l'effet sur ton endormissement.",
          duration: "1 semaine",
        },
        {
          kind: "quiz",
          question: "Quelle est la demi-vie approximative de la caféine ?",
          options: ["30 minutes", "1 heure", "5 à 6 heures", "24 heures"],
          answer: 2,
          explanation: "Une demi-vie de 5 à 6 heures explique pourquoi une prise tardive perturbe le sommeil.",
        },
        {
          kind: "quiz",
          question: "Quelle dose de caféine est associée à un gain de performance sportive ?",
          options: ["0,1 mg/kg", "3 à 6 mg/kg", "20 mg/kg", "50 mg/kg"],
          answer: 1,
          explanation: "3 à 6 mg/kg est la fourchette la plus documentée pour un effet ergogénique.",
        },
        {
          kind: "sources",
          items: [
            { label: "Examine.com – Caffeine", url: "https://examine.com/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "supplements-7",
      title: "Ce qui ne sert (probablement) à rien",
      summary: "Le tri entre effet marginal, effet nul et pur marketing.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "supplements-useless",
      blocks: [
        {
          kind: "text",
          title: "Le marché des compléments va vite",
          body: "Beaucoup de produits sont vendus avec des promesses qui dépassent largement ce que montrent les études, souvent réalisées sur peu de personnes ou financées par les fabricants eux-mêmes.",
        },
        {
          kind: "image",
          image: "supplements-useless",
          caption: "Un rayon de compléments alimentaires : tout n'a pas le même niveau de preuve.",
        },
        {
          kind: "list",
          title: "Effet le plus souvent décevant",
          items: [
            "BCAA seuls si tes apports en protéines totales sont déjà suffisants",
            "Brûleurs de graisse 'thermogéniques' à base de plantes exotiques",
            "Testo-boosters en vente libre",
            "Détox et 'nettoyants' divers",
          ],
        },
        {
          kind: "myth",
          myth: "Un produit vendu en pharmacie ou en salle de sport est forcément validé scientifiquement.",
          truth: "Le lieu de vente ne garantit rien sur l'efficacité ; seule la littérature scientifique indépendante permet de juger.",
        },
        {
          kind: "compare",
          title: "Preuve solide vs marketing",
          left: { label: "Preuve solide", items: ["Créatine", "Vitamine D en cas de carence", "Caféine à dose connue"] },
          right: { label: "Marketing surtout", items: ["Testo-boosters en vente libre", "Détox express", "Brûleurs de graisse miracle"] },
        },
        {
          kind: "warn",
          title: "Le vrai coût, c'est souvent l'opportunité",
          body: "L'argent et l'attention mis dans un produit inutile auraient souvent plus d'impact investis dans le sommeil, l'entraînement ou l'alimentation de base.",
        },
        {
          kind: "steps",
          title: "Ta grille de tri avant d'acheter",
          items: [
            "Cherche le nom de la molécule sur une base indépendante (Examine.com, Cochrane)",
            "Regarde si l'effet est mesuré sur l'humain, pas seulement en laboratoire",
            "Méfie-toi des promesses '100 % naturel' ou 'sans effort'",
          ],
        },
        {
          kind: "checklist",
          title: "Avant chaque nouvel achat",
          items: [
            "Je vérifie l'existence d'études indépendantes",
            "Je regarde la dose réelle par portion",
            "Je me demande si l'alimentation ne suffit pas déjà",
          ],
        },
        {
          kind: "quiz",
          question: "Quel est le meilleur réflexe avant d'acheter un complément à la mode ?",
          options: [
            "Se fier au packaging",
            "Vérifier les preuves sur une base indépendante",
            "Regarder le prix uniquement",
            "Se fier à un influenceur",
          ],
          answer: 1,
          explanation: "Les bases indépendantes comme Examine.com ou Cochrane résument le niveau de preuve réel, loin du marketing.",
        },
        {
          kind: "sources",
          items: [
            { label: "Cochrane", url: "https://www.cochrane.org/" },
            { label: "Examine.com", url: "https://examine.com/" },
          ],
        },
      ],
    },
    {
      id: "supplements-8",
      title: "Qualité et dosage : ce qui fait la différence",
      summary: "Deux produits avec le même nom peuvent ne pas se valoir du tout.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "supplements-quality",
      blocks: [
        {
          kind: "text",
          title: "Deux failles fréquentes",
          body: "Un complément peut être inefficace non pas parce que la molécule ne marche pas, mais parce que la dose est trop faible ou la qualité du produit douteuse.",
        },
        {
          kind: "image",
          image: "supplements-quality",
          caption: "Vérifier l'étiquette prend 30 secondes et évite bien des déceptions.",
        },
        {
          kind: "list",
          title: "Ce qu'il faut vérifier sur l'étiquette",
          items: [
            "La dose exacte de la molécule active, pas juste du 'complexe propriétaire'",
            "La forme chimique utilisée (certaines sont mieux absorbées)",
            "La présence de labels de contrôle qualité indépendants",
          ],
        },
        {
          kind: "myth",
          myth: "Un prix élevé garantit une meilleure qualité.",
          truth: "Le prix reflète surtout le marketing et le packaging ; seule l'étiquette et les contrôles indépendants renseignent sur la qualité réelle.",
        },
        {
          kind: "compare",
          title: "Étiquette claire vs floue",
          left: { label: "Étiquette claire", items: ["Dose précise en mg ou g", "Forme chimique indiquée", "Ingrédients limités"] },
          right: { label: "Étiquette floue", items: ["'Complexe propriétaire' sans détail", "Multiples ingrédients à dose infime", "Promesses vagues"] },
        },
        {
          kind: "warn",
          title: "Le risque de contamination",
          body: "Certains compléments, notamment ceux visant la performance sportive, ont été trouvés contaminés par des substances non déclarées. Privilégie les marques contrôlées par des labels indépendants.",
        },
        {
          kind: "steps",
          title: "Réflexe avant l'achat",
          items: [
            "Compare la dose annoncée à la dose efficace documentée",
            "Cherche un label de contrôle tiers si tu es sportif testé",
            "Évite les mélanges à rallonge avec de multiples ingrédients sous-dosés",
          ],
        },
        {
          kind: "quiz",
          question: "Que signifie souvent un 'complexe propriétaire' sur une étiquette ?",
          options: [
            "Une garantie de haute qualité",
            "Le dosage exact de chaque ingrédient",
            "Un mélange dont les doses individuelles ne sont pas précisées",
            "Un produit certifié par un laboratoire indépendant",
          ],
          answer: 2,
          explanation: "Ce terme permet souvent de ne pas révéler la dose réelle de chaque ingrédient, un signal d'alerte.",
        },
        {
          kind: "sources",
          items: [
            { label: "ODS NIH", url: "https://ods.od.nih.gov/" },
            { label: "ANSES", url: "https://www.anses.fr/" },
          ],
        },
      ],
    },
    {
      id: "supplements-9",
      title: "Interactions et prudence : ce qu'il faut savoir",
      summary: "Un complément n'est jamais neutre à 100 %, même vendu sans ordonnance.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "supplements-caution",
      blocks: [
        {
          kind: "text",
          title: "'Naturel' ne veut pas dire 'sans risque'",
          body: "Certains compléments interagissent avec des médicaments courants (anticoagulants, antidépresseurs) ou peuvent poser problème en cas de pathologie préexistante.",
        },
        {
          kind: "image",
          image: "supplements-caution",
          caption: "Un avis médical ou pharmaceutique évite les mauvaises surprises.",
        },
        {
          kind: "list",
          title: "Situations qui demandent un avis médical",
          items: [
            "Traitement médicamenteux en cours",
            "Grossesse ou allaitement",
            "Insuffisance rénale ou hépatique",
            "Avant une intervention chirurgicale",
          ],
        },
        {
          kind: "myth",
          myth: "Puisque c'est vendu librement, un complément ne peut pas être dangereux.",
          truth: "La vente libre ne garantit ni l'innocuité ni l'absence d'interaction avec un traitement en cours.",
        },
        {
          kind: "compare",
          title: "Exemples de vigilance",
          left: { label: "Interactions connues", items: ["Oméga-3 à forte dose et anticoagulants", "Millepertuis et pilule contraceptive", "Vitamine K et anticoagulants"] },
          right: { label: "Bon réflexe", items: ["Demander l'avis d'un pharmacien", "Signaler tout complément pris à son médecin", "Éviter l'automédication à forte dose"] },
        },
        {
          kind: "warn",
          title: "Cumul de vitamines liposolubles",
          body: "Les vitamines A, D, E et K se stockent dans le corps. Un cumul de plusieurs compléments peut mener à un surdosage, contrairement aux vitamines hydrosolubles éliminées plus facilement.",
        },
        {
          kind: "steps",
          title: "Avant toute nouvelle prise",
          items: [
            "Liste tous les compléments et médicaments que tu prends déjà",
            "Demande conseil à un pharmacien ou un médecin en cas de doute",
            "Introduis un seul nouveau complément à la fois pour repérer les effets",
          ],
        },
        {
          kind: "checklist",
          title: "Réflexes de prudence",
          items: [
            "Je signale mes compléments à mon médecin",
            "Je respecte les doses maximales indiquées",
            "Je n'associe pas plusieurs produits similaires sans vérifier",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi les vitamines liposolubles demandent plus de prudence en cumul ?",
          options: [
            "Elles n'ont aucun effet",
            "Elles s'éliminent instantanément",
            "Elles se stockent dans le corps et peuvent s'accumuler",
            "Elles sont toujours interdites",
          ],
          answer: 2,
          explanation: "Contrairement aux vitamines hydrosolubles, les liposolubles (A, D, E, K) s'accumulent dans les tissus, ce qui augmente le risque de surdosage.",
        },
        {
          kind: "sources",
          items: [
            { label: "ANSES", url: "https://www.anses.fr/" },
            { label: "Ameli", url: "https://www.ameli.fr/" },
          ],
        },
      ],
    },
    {
      id: "supplements-10",
      title: "Construire ta propre stack, étape par étape",
      summary: "Une méthode pour choisir sans te perdre dans l'offre pléthorique.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "supplements-stack",
      blocks: [
        {
          kind: "text",
          title: "Partir du besoin, pas du produit",
          body: "La meilleure stratégie est de partir de tes objectifs et lacunes réelles (alimentation, sommeil, entraînement) avant de chercher un produit à ajouter.",
        },
        {
          kind: "image",
          image: "supplements-stack",
          caption: "Une stack simple et justifiée vaut mieux qu'une étagère pleine de pots à moitié utilisés.",
        },
        {
          kind: "steps",
          title: "Méthode en 4 étapes",
          items: [
            "Identifie un besoin réel (peu de poisson, peu de soleil, entraînement intense)",
            "Cherche la molécule avec le meilleur niveau de preuve pour ce besoin précis",
            "Vérifie la dose et la qualité du produit choisi",
            "Réévalue après plusieurs semaines, arrête ce qui n'apporte rien de perceptible",
          ],
        },
        {
          kind: "list",
          title: "Base solide pour la plupart des hommes actifs",
          items: [
            "Créatine monohydrate, 3 à 5 g/jour",
            "Vitamine D en hiver si peu d'exposition au soleil",
            "Oméga-3 si peu de poisson gras dans l'alimentation",
          ],
        },
        {
          kind: "compare",
          title: "Stack minimaliste vs stack surchargée",
          left: { label: "Stack minimaliste", items: ["2 à 3 produits justifiés", "Facile à suivre", "Budget maîtrisé"] },
          right: { label: "Stack surchargée", items: ["10+ produits", "Effets impossibles à isoler", "Coût élevé pour peu de bénéfice"] },
        },
        {
          kind: "myth",
          myth: "Plus tu prends de compléments, plus vite tu progresses.",
          truth: "Au-delà de quelques bases bien choisies, l'ajout de produits supplémentaires apporte des rendements de plus en plus faibles.",
        },
        {
          kind: "warn",
          title: "Rien ne remplace les fondamentaux",
          body: "Sommeil, entraînement régulier et alimentation correcte pèsent largement plus lourd que n'importe quelle stack de compléments.",
        },
        {
          kind: "drill",
          title: "Audit de ta stack actuelle",
          body: "Liste tout ce que tu prends actuellement et note en face le besoin réel que ça couvre. Élimine ce qui n'a pas de justification claire.",
          duration: "10 min",
        },
        {
          kind: "quiz",
          question: "Quelle est la première étape avant d'ajouter un complément ?",
          options: [
            "Regarder ce que prennent les influenceurs",
            "Identifier un besoin réel et documenté",
            "Acheter le produit le plus cher",
            "Prendre tout ce qui est disponible en magasin",
          ],
          answer: 1,
          explanation: "Partir d'un besoin réel évite les achats inutiles et permet de mesurer un effet concret.",
        },
        {
          kind: "quiz",
          question: "Que faut-il faire après avoir testé un complément plusieurs semaines ?",
          options: [
            "Rien, continuer indéfiniment",
            "Doubler la dose systématiquement",
            "Réévaluer son utilité et arrêter si aucun effet perceptible",
            "En racheter davantage par précaution",
          ],
          answer: 2,
          explanation: "Une réévaluation régulière évite de garder des produits inutiles dans sa routine.",
        },
        {
          kind: "sources",
          items: [
            { label: "Examine.com", url: "https://examine.com/" },
            { label: "ANSES", url: "https://www.anses.fr/" },
          ],
        },
      ],
    },
    {
      id: "supplements-11",
      title: "Idées reçues qui ont la vie dure",
      summary: "Des croyances persistantes, malgré les preuves disponibles.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "supplements-myths2",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi ces croyances persistent",
          body: "Le marketing, les témoignages individuels et l'effet placebo entretiennent des idées qui ne résistent pas à un examen sérieux des données disponibles.",
        },
        {
          kind: "image",
          image: "supplements-myths2",
          caption: "Un témoignage n'est jamais une preuve scientifique.",
        },
        {
          kind: "myth",
          myth: "Les compléments 'détox' nettoient le foie et les reins.",
          truth: "Le foie et les reins font déjà ce travail en continu chez une personne en bonne santé ; aucun produit ne l'améliore de façon démontrée.",
        },
        {
          kind: "myth",
          myth: "Le collagène en poudre rajeunit visiblement la peau.",
          truth: "Les effets mesurés sont modestes et variables selon les études, loin des promesses marketing habituelles.",
        },
        {
          kind: "myth",
          myth: "Un complément multivitamine remplace une alimentation équilibrée.",
          truth: "Les multivitamines comblent des écarts ponctuels mais n'apportent pas les fibres, protéines et composés bénéfiques des aliments entiers.",
        },
        {
          kind: "list",
          title: "Signaux qui doivent alerter",
          items: [
            "Promesse de résultat 'garanti' ou 'immédiat'",
            "Témoignages avant/après sans autre contexte",
            "Absence totale de dose précise indiquée",
          ],
        },
        {
          kind: "compare",
          title: "Croyance populaire vs donnée disponible",
          left: { label: "Croyance populaire", items: ["Plus c'est cher, mieux c'est", "Naturel = sans danger", "Un produit peut tout résoudre"] },
          right: { label: "Donnée disponible", items: ["Le prix ne reflète pas l'efficacité", "Le naturel peut aussi interagir ou doser fort", "Aucun produit ne compense un mode de vie déséquilibré"] },
        },
        {
          kind: "warn",
          title: "L'effet placebo existe aussi ici",
          body: "Ressentir un effet après une prise ne prouve pas que le produit agit réellement ; c'est pour ça que les études comparent à un placebo.",
        },
        {
          kind: "quiz",
          question: "Pourquoi les études comparent-elles un complément à un placebo ?",
          options: [
            "Pour rendre l'étude plus longue",
            "Pour isoler l'effet réel du produit de l'effet psychologique",
            "Parce que c'est obligatoire par la loi partout",
            "Pour réduire les coûts de l'étude",
          ],
          answer: 1,
          explanation: "Le placebo permet de distinguer l'effet réel de la molécule de l'effet d'attente du participant.",
        },
        {
          kind: "sources",
          items: [
            { label: "Cochrane", url: "https://www.cochrane.org/" },
            { label: "Examine.com", url: "https://examine.com/" },
          ],
        },
      ],
    },
    {
      id: "supplements-12",
      title: "Ce que dit vraiment la recherche sur le long terme",
      summary: "Regard critique sur ce qu'on sait vraiment au-delà de quelques mois.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "supplements-longterm",
      blocks: [
        {
          kind: "text",
          title: "La limite des études disponibles",
          body: "Beaucoup d'essais cliniques sur les compléments durent quelques semaines à quelques mois. Les données sur 5, 10 ou 20 ans sont beaucoup plus rares, ce qui impose une certaine humilité.",
        },
        {
          kind: "image",
          image: "supplements-longterm",
          caption: "La recherche progresse, mais toutes les questions n'ont pas encore de réponse ferme.",
        },
        {
          kind: "list",
          title: "Compléments avec un bon recul long terme",
          items: [
            "Créatine : décennies de suivi sans signal d'alarme chez le sujet sain",
            "Vitamine D à dose raisonnable",
            "Oméga-3 alimentaires",
          ],
        },
        {
          kind: "list",
          title: "Compléments avec un recul plus limité",
          items: [
            "Nouveaux extraits de plantes 'exotiques'",
            "Nootropiques récents",
            "Mélanges multi-ingrédients récents",
          ],
        },
        {
          kind: "myth",
          myth: "Un complément sur le marché depuis longtemps est forcément bien étudié.",
          truth: "L'ancienneté commerciale ne garantit pas l'existence d'études rigoureuses ; certains produits anciens n'ont jamais été bien testés.",
        },
        {
          kind: "compare",
          title: "Niveau de preuve solide vs préliminaire",
          left: { label: "Preuve solide", items: ["Multiples essais randomisés", "Effets reproductibles", "Recul de plusieurs années"] },
          right: { label: "Preuve préliminaire", items: ["Une ou deux petites études", "Résultats contradictoires", "Recul de quelques mois seulement"] },
        },
        {
          kind: "warn",
          title: "Prudence avec les nouveautés",
          body: "Un produit tout juste lancé, même appuyé par une étude, mérite d'attendre confirmation par d'autres recherches indépendantes avant d'y consacrer un budget régulier.",
        },
        {
          kind: "steps",
          title: "Évaluer le niveau de preuve d'un produit",
          items: [
            "Cherche combien d'études existent, pas juste une",
            "Regarde si les résultats sont reproduits par des équipes différentes",
            "Vérifie la durée de suivi des participants",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi la durée de suivi d'une étude compte autant ?",
          options: [
            "Elle n'a aucune importance",
            "Elle permet de détecter des effets ou risques qui n'apparaissent qu'à long terme",
            "Elle sert uniquement à réduire les coûts",
            "Elle est imposée uniquement pour le marketing",
          ],
          answer: 1,
          explanation: "Certains effets, positifs comme négatifs, ne se manifestent qu'après plusieurs mois ou années d'usage.",
        },
        {
          kind: "quiz",
          question: "Quel complément a le plus long recul scientifique parmi ceux cités ?",
          options: ["Nootropique récent", "Créatine", "Extrait de plante exotique", "Mélange multi-ingrédients récent"],
          answer: 1,
          explanation: "La créatine est étudiée depuis des décennies, avec un profil de sécurité bien documenté chez le sujet sain.",
        },
        {
          kind: "sources",
          items: [
            { label: "Cochrane", url: "https://www.cochrane.org/" },
            { label: "NCBI", url: "https://www.ncbi.nlm.nih.gov/" },
          ],
        },
      ],
    },
    {
      id: "supplements-13",
      title: "Bonus : ta checklist finale avant tout achat",
      summary: "Un condensé pour ne plus jamais te faire avoir par le marketing.",
      difficulty: "hard",
      minutes: 12,
      xp: 200,
      tier: "pro",
      requiresLevel: 4,
      cover: "supplements-final",
      blocks: [
        {
          kind: "text",
          title: "Récapitulatif avant de sortir la carte bancaire",
          body: "Après ce parcours, tu as tous les outils pour juger un complément par toi-même plutôt que de suivre une tendance ou une publicité.",
        },
        {
          kind: "image",
          image: "supplements-final",
          caption: "Un choix éclairé vaut mieux qu'une étagère pleine de promesses non tenues.",
        },
        {
          kind: "list",
          title: "Les bases à privilégier en priorité",
          items: [
            "Créatine monohydrate si tu t'entraînes régulièrement",
            "Vitamine D en cas de faible exposition au soleil",
            "Oméga-3 si tu manges peu de poisson gras",
            "Whey si pratique pour atteindre ton total de protéines",
          ],
        },
        {
          kind: "compare",
          title: "À faire vs à éviter",
          left: { label: "À faire", items: ["Vérifier le niveau de preuve", "Contrôler la dose réelle", "Réévaluer après plusieurs semaines"] },
          right: { label: "À éviter", items: ["Acheter sur une promesse marketing", "Cumuler des produits similaires", "Ignorer les interactions médicamenteuses"] },
        },
        {
          kind: "myth",
          myth: "Il existe un complément indispensable pour tout le monde.",
          truth: "Le besoin dépend entièrement de ton alimentation, ton mode de vie et ton entraînement ; aucun produit n'est universellement indispensable.",
        },
        {
          kind: "warn",
          title: "Toujours vérifier en cas de traitement",
          body: "Avant d'ajouter quoi que ce soit à ta routine, vérifie l'absence d'interaction si tu prends un traitement médical régulier.",
        },
        {
          kind: "steps",
          title: "Ta routine de décision finale",
          items: [
            "Identifie le besoin réel derrière l'envie d'achat",
            "Vérifie la preuve scientifique indépendante",
            "Contrôle la dose et la qualité du produit précis",
            "Fixe une date pour réévaluer l'intérêt réel",
          ],
        },
        {
          kind: "drill",
          title: "Bilan complet de ta routine actuelle",
          body: "Reprends chaque complément que tu utilises et applique-lui cette checklist en entier. Élimine ce qui ne passe pas le test.",
          duration: "15 min",
        },
        {
          kind: "checklist",
          title: "Check final avant achat",
          items: [
            "Le besoin est clairement identifié",
            "La preuve scientifique est solide",
            "La dose et la forme sont vérifiées",
            "Aucune interaction connue avec mes traitements",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle est la meilleure définition d'une stack de compléments réussie ?",
          options: [
            "La plus longue liste de produits possible",
            "Celle basée sur des besoins réels et des preuves solides",
            "Celle qui coûte le plus cher",
            "Celle recommandée par le plus d'influenceurs",
          ],
          answer: 1,
          explanation: "Une bonne stack part toujours d'un besoin réel appuyé par des preuves, pas d'une tendance ou d'un budget élevé.",
        },
        {
          kind: "quiz",
          question: "Que faire avant d'ajouter un complément si tu prends déjà un traitement médical ?",
          options: [
            "Rien de particulier",
            "Demander l'avis d'un professionnel de santé",
            "Doubler la dose du médicament",
            "Arrêter le traitement sans en parler",
          ],
          answer: 1,
          explanation: "Un avis médical ou pharmaceutique permet d'éviter les interactions dangereuses.",
        },
        {
          kind: "sources",
          items: [
            { label: "Examine.com", url: "https://examine.com/" },
            { label: "ANSES", url: "https://www.anses.fr/" },
            { label: "Ameli", url: "https://www.ameli.fr/" },
          ],
        },
      ],
    },
  ],
};
