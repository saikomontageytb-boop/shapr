import type { Track } from "@/lib/academy-types";

export const skin: Track = {
  id: "skin",
  title: "Peau",
  tagline: "Une routine simple, basée sur la science, pas sur le marketing.",
  intro:
    "Ta peau est un organe, pas un accessoire. Ici tu apprends ce qui marche vraiment : nettoyage, hydratation, protection solaire, et ce qu'il faut ignorer.",
  icon: "droplet",
  cover: "skin-cover",
  lessons: [
    {
      id: "skin-1",
      title: "Comprendre ta peau : la barrière cutanée",
      summary: "Ce que fait vraiment ta peau, et pourquoi la respecter change tout.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "skin-face",
      blocks: [
        {
          kind: "text",
          title: "Un organe, pas un décor",
          body: "La peau est le plus grand organe du corps. Sa couche externe, la barrière cutanée, empêche l'eau de s'échapper et les agressions extérieures d'entrer. La casser, c'est s'exposer aux rougeurs, tiraillements et boutons.",
        },
        {
          kind: "image",
          image: "skin-face",
          caption: "La peau du visage est plus fine et plus sensible que celle du reste du corps.",
        },
        {
          kind: "list",
          title: "Ce qui abîme la barrière cutanée",
          items: [
            "Se laver le visage trop souvent ou avec de l'eau trop chaude",
            "Frotter fort avec une serviette ou un gant",
            "Multiplier les produits actifs en même temps",
            "Le savon classique, trop décapant pour le visage",
          ],
        },
        {
          kind: "stat",
          value: "~0,1 mm",
          label: "Épaisseur de l'épiderme du visage",
          body: "C'est très fin comparé à la paume de la main (environ 1,5 mm). D'où l'intérêt d'y être doux.",
        },
        {
          kind: "myth",
          myth: "Plus ça pique, plus ça nettoie en profondeur.",
          truth: "Une sensation de tiraillement après nettoyage signifie que le produit est trop agressif, pas plus efficace.",
        },
        {
          kind: "compare",
          title: "Bon geste vs mauvais geste",
          left: { label: "Ça aide", items: ["Eau tiède", "Nettoyant doux sans savon", "Sécher en tamponnant"] },
          right: { label: "Ça abîme", items: ["Eau brûlante", "Gant de crin", "Frotter fort avec la serviette"] },
        },
        {
          kind: "checklist",
          title: "À retenir aujourd'hui",
          items: [
            "Je nettoie mon visage avec de l'eau tiède",
            "Je sèche en tamponnant, sans frotter",
            "Je limite le nettoyage à 2 fois par jour",
          ],
        },
        {
          kind: "quiz",
          question: "Que fait la barrière cutanée ?",
          options: [
            "Elle produit la mélanine",
            "Elle retient l'eau et bloque les agressions extérieures",
            "Elle fabrique les poils",
          ],
          answer: 1,
          explanation: "La barrière cutanée (couche cornée) est une protection physique : elle garde l'hydratation à l'intérieur et les agresseurs à l'extérieur.",
        },
        {
          kind: "sources",
          items: [
            { label: "American Academy of Dermatology — Skin basics", url: "https://www.aad.org/public/everyday-care/skin-care-basics" },
            { label: "NHS — Skin conditions", url: "https://www.nhs.uk/conditions/" },
          ],
        },
      ],
    },
    {
      id: "skin-2",
      title: "La routine minimale qui suffit",
      summary: "3 gestes, tous les jours, rien de plus.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "skin-mirror",
      blocks: [
        {
          kind: "text",
          title: "La règle des 3 gestes",
          body: "Nettoyer, hydrater, protéger du soleil. C'est la base recommandée par les dermatologues, avant tout produit spécialisé.",
        },
        {
          kind: "steps",
          title: "Routine du matin",
          items: [
            "Nettoyant doux à l'eau tiède",
            "Sécher en tamponnant",
            "Crème hydratante adaptée à ta peau",
            "Crème solaire SPF 30 minimum si tu sors",
          ],
        },
        {
          kind: "steps",
          title: "Routine du soir",
          items: [
            "Nettoyant doux pour retirer la journée (pollution, sébum)",
            "Crème hydratante ou soin ciblé si tu en utilises un",
          ],
        },
        {
          kind: "image",
          image: "skin-mirror",
          caption: "Deux minutes chrono suffisent pour une routine efficace.",
        },
        {
          kind: "warn",
          title: "Pas la peine d'empiler",
          body: "Ajouter 6 sérums différents ne va pas plus vite ni plus loin qu'une routine simple bien tenue. Le risque principal, c'est l'irritation.",
        },
        {
          kind: "drill",
          title: "Mets en place ta routine",
          body: "Choisis un nettoyant doux et une crème hydratante non parfumée. Utilise-les matin et soir pendant 2 semaines avant de juger le résultat.",
          duration: "2 semaines",
        },
        {
          kind: "list",
          title: "Signes qu'un produit ne te convient pas",
          items: ["Rougeurs après application", "Sensation de brûlure", "Boutons qui apparaissent en quelques jours"],
        },
        {
          kind: "quiz",
          question: "Combien de temps minimum avant de juger l'effet d'une routine ?",
          options: ["2-3 jours", "2 à 4 semaines", "6 mois"],
          answer: 1,
          explanation: "Le cycle de renouvellement cutané prend plusieurs semaines : il faut ce délai pour voir un vrai effet.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Comment bien se laver le visage", url: "https://www.aad.org/public/everyday-care/skin-care-basics/care/how-to-wash-face" },
          ],
        },
      ],
    },
    {
      id: "skin-3",
      title: "Choisir sa crème solaire",
      summary: "SPF, UVA/UVB, texture : ce qui compte vraiment.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-sun",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi le soleil est l'ennemi n°1",
          body: "Les UV sont la première cause de vieillissement cutané prématuré (rides, taches) et un facteur de risque majeur de cancer de la peau. C'est le geste le plus rentable de toute la routine.",
        },
        {
          kind: "stat",
          value: "SPF 30",
          label: "Seuil minimum recommandé",
          body: "Un SPF 30 filtre environ 97% des UVB. Le SPF 50 filtre environ 98%. Au-delà, le gain est marginal.",
        },
        {
          kind: "compare",
          title: "UVA vs UVB",
          left: { label: "UVB", items: ["Provoquent les coups de soleil", "Filtrés par le SPF"] },
          right: { label: "UVA", items: ["Pénètrent plus profond", "Responsables du vieillissement", "Cherche la mention 'UVA'"] },
        },
        {
          kind: "image",
          image: "skin-sun",
          caption: "L'exposition solaire cumulée marque la peau, même sans coup de soleil visible.",
        },
        {
          kind: "myth",
          myth: "Peau mate ou foncée, pas besoin de crème solaire.",
          truth: "La mélanine protège partiellement mais ne suffit pas : toutes les carnations bénéficient d'une protection solaire.",
        },
        {
          kind: "list",
          title: "Comment bien l'utiliser",
          items: [
            "Une noisette pour le visage, appliquée généreusement",
            "À renouveler toutes les 2 heures si exposition prolongée",
            "Même par temps nuageux : les UV traversent les nuages",
          ],
        },
        {
          kind: "checklist",
          title: "Check avant de sortir",
          items: ["SPF 30 minimum appliqué", "Mention UVA présente sur le tube", "Casquette ou lunettes si forte exposition"],
        },
        {
          kind: "quiz",
          question: "Que protège principalement le SPF indiqué sur le tube ?",
          options: ["Les UVA", "Les UVB", "La lumière bleue des écrans"],
          answer: 1,
          explanation: "Le chiffre SPF mesure la protection contre les UVB. Il faut vérifier séparément la mention de protection UVA.",
        },
        {
          kind: "sources",
          items: [
            { label: "WHO — Ultraviolet radiation", url: "https://www.who.int/news-room/questions-and-answers/item/radiation-ultraviolet-(uv)" },
            { label: "AAD — Sunscreen FAQs", url: "https://www.aad.org/media/stats-sunscreen" },
          ],
        },
      ],
    },
    {
      id: "skin-4",
      title: "Rasage sans irritation",
      summary: "Le geste technique qui évite feu du rasoir et poils incarnés.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-closeup",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi ça irrite",
          body: "Le rasage retire une fine couche de peau en plus du poil. Sur peau sèche ou avec une lame usée, la friction abîme la barrière cutanée et cause rougeurs et poils incarnés.",
        },
        {
          kind: "steps",
          title: "Protocole anti-irritation",
          items: [
            "Se raser après la douche, peau chaude et détendue",
            "Appliquer une mousse ou un gel, jamais à sec",
            "Raser dans le sens du poil en premier passage",
            "Rincer à l'eau froide et changer de lame régulièrement",
            "Hydrater juste après, sans alcool",
          ],
        },
        {
          kind: "image",
          image: "skin-closeup",
          caption: "Une lame usée force à repasser plusieurs fois au même endroit : c'est ça qui irrite.",
        },
        {
          kind: "compare",
          title: "Sens du poil vs contre le poil",
          left: { label: "Avec le poil", items: ["Moins de risque d'irritation", "Rasage un peu moins net"] },
          right: { label: "Contre le poil", items: ["Rasage plus net", "Plus de risque de poils incarnés"] },
        },
        {
          kind: "warn",
          title: "Poils incarnés à répétition",
          body: "Si ça devient douloureux ou infecté régulièrement, consulte un médecin ou un dermatologue plutôt que d'insister avec des produits maison.",
        },
        {
          kind: "list",
          title: "Signes d'une lame à changer",
          items: ["Tiraillement pendant le rasage", "Rougeurs qui apparaissent plus vite qu'avant", "Lame utilisée depuis plus de 5-7 rasages"],
        },
        {
          kind: "checklist",
          title: "Avant chaque rasage",
          items: ["Peau chaude / après douche", "Mousse ou gel appliqué", "Lame propre et pas trop vieille"],
        },
        {
          kind: "quiz",
          question: "Pourquoi vaut-il mieux se raser après la douche ?",
          options: [
            "Parce que la peau est chaude et le poil ramolli",
            "Parce que ça sent meilleur",
            "Parce que la mousse tient moins bien avant",
          ],
          answer: 0,
          explanation: "La chaleur et l'humidité assouplissent le poil, ce qui réduit la résistance et donc l'irritation.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Shaving tips", url: "https://www.aad.org/public/everyday-care/skin-care-basics/care/shaving" },
          ],
        },
      ],
    },
    {
      id: "skin-5",
      title: "Acné : mythes et réalités",
      summary: "Ce qui cause vraiment les boutons, et ce qui n'y change rien.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-face",
      blocks: [
        {
          kind: "text",
          title: "D'où viennent les boutons",
          body: "L'acné vient d'un excès de sébum, de cellules mortes qui bouchent les pores, et d'une bactérie (C. acnes) qui en profite. Les hormones (adolescence, stress) augmentent la production de sébum.",
        },
        {
          kind: "myth",
          myth: "Le chocolat et la friture donnent des boutons.",
          truth: "Le lien alimentaire est faible et débattu. Certains travaux pointent les aliments à index glycémique élevé, mais ce n'est pas la cause principale pour la majorité des gens.",
        },
        {
          kind: "myth",
          myth: "Il faut assécher la peau pour faire partir l'acné.",
          truth: "Assécher excessivement pousse la peau à produire encore plus de sébum en réaction, et abîme la barrière cutanée.",
        },
        {
          kind: "list",
          title: "Ce qui aide réellement",
          items: [
            "Nettoyant doux, 2 fois par jour, pas plus",
            "Hydratant non comédogène (n'obstrue pas les pores)",
            "Actifs validés : acide salicylique, peroxyde de benzoyle, à faible dose au début",
            "Ne jamais percer ou triturer un bouton",
          ],
        },
        {
          kind: "image",
          image: "skin-face",
          caption: "Toucher ou percer un bouton augmente le risque de cicatrice.",
        },
        {
          kind: "warn",
          title: "Quand consulter",
          body: "En cas d'acné inflammatoire persistante, de kystes douloureux ou de cicatrices qui s'installent, un dermatologue peut prescrire un traitement adapté. Ne t'auto-prescris pas d'antibiotiques ou de rétinoïdes oraux.",
        },
        {
          kind: "checklist",
          title: "Réflexes anti-acné",
          items: ["Je ne touche pas mes boutons", "Je change de taie d'oreiller régulièrement", "Je nettoie mon téléphone qui touche ma joue"],
        },
        {
          kind: "quiz",
          question: "Que fait un nettoyant trop agressif sur une peau à boutons ?",
          options: [
            "Il réduit durablement le sébum",
            "Il peut pousser la peau à produire plus de sébum en réaction",
            "Il n'a aucun effet",
          ],
          answer: 1,
          explanation: "Une peau agressée compense souvent en sécrétant plus de sébum, ce qui aggrave le problème sur la durée.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Acne resource center", url: "https://www.aad.org/public/diseases/acne" },
            { label: "NHS — Acne", url: "https://www.nhs.uk/conditions/acne/" },
          ],
        },
      ],
    },
    {
      id: "skin-6",
      title: "La science du vieillissement cutané",
      summary: "Collagène, radicaux libres, glycation : les mécanismes derrière les rides.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "skin-closeup",
      blocks: [
        {
          kind: "text",
          title: "Deux vieillissements distincts",
          body: "Le vieillissement intrinsèque (génétique, temps qui passe) est lent et inévitable. Le vieillissement extrinsèque (soleil, tabac, pollution) est en grande partie évitable et représente la majorité des dégâts visibles.",
        },
        {
          kind: "stat",
          value: "~80%",
          label: "Part du vieillissement visible attribuée au soleil",
          body: "C'est l'estimation généralement citée par les dermatologues pour le photovieillissement, ce qui explique pourquoi la protection solaire est le geste anti-âge le plus efficace.",
        },
        {
          kind: "text",
          title: "Le rôle du collagène",
          body: "Le collagène et l'élastine donnent à la peau sa fermeté. Leur production ralentit avec l'âge, et les UV accélèrent leur dégradation via des enzymes appelées métalloprotéinases.",
        },
        {
          kind: "image",
          image: "skin-closeup",
          caption: "La texture de peau se transforme progressivement avec la perte de collagène.",
        },
        {
          kind: "compare",
          title: "Intrinsèque vs extrinsèque",
          left: { label: "Intrinsèque", items: ["Déterminé génétiquement", "Progressif, uniforme", "Peu modifiable"] },
          right: { label: "Extrinsèque", items: ["Soleil, tabac, pollution", "Taches, rides marquées", "Largement évitable"] },
        },
        {
          kind: "warn",
          title: "Limites des preuves sur les cosmétiques anti-âge",
          body: "Beaucoup de crèmes 'anti-rides' ont des preuves d'efficacité modestes ou de court terme. Les rétinoïdes et la protection solaire sont les interventions les mieux documentées, le reste est souvent du marketing.",
        },
        {
          kind: "list",
          title: "Facteurs aggravants documentés",
          items: ["Tabac (réduit l'oxygénation de la peau)", "Exposition solaire cumulée", "Sucre en excès (glycation du collagène)", "Manque de sommeil chronique"],
        },
        {
          kind: "quiz",
          question: "Quelle est la principale cause évitable du vieillissement cutané visible ?",
          options: ["Le sommeil", "L'exposition solaire", "L'hydratation insuffisante"],
          answer: 1,
          explanation: "Le photovieillissement lié aux UV est considéré comme la cause majeure et la plus évitable du vieillissement cutané visible.",
        },
        {
          kind: "quiz",
          question: "Que fait la glycation au collagène ?",
          options: [
            "Elle le renforce",
            "Elle rigidifie les fibres et réduit l'élasticité",
            "Elle n'a aucun effet démontré",
          ],
          answer: 1,
          explanation: "L'excès de sucre se fixe sur les fibres de collagène, les rend plus rigides et moins élastiques.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Anti-aging skin care", url: "https://www.aad.org/public/everyday-care/skin-care-secrets/anti-aging" },
            { label: "NCBI / PubMed — Skin aging (recherche)", url: "https://www.ncbi.nlm.nih.gov/pmc/?term=skin+photoaging" },
          ],
        },
      ],
    },
    {
      id: "skin-7",
      title: "Bonus — Rétinoïdes : ce que dit la science",
      summary: "L'actif le plus étudié en dermatologie, et comment l'introduire sans tout irriter.",
      difficulty: "hard",
      minutes: 12,
      xp: 200,
      tier: "pro",
      requiresLevel: 4,
      cover: "skin-mirror",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi les rétinoïdes sont à part",
          body: "Dérivés de la vitamine A, les rétinoïdes (rétinol en vente libre, trétinoïne sur ordonnance) accélèrent le renouvellement cellulaire et stimulent la production de collagène. C'est l'un des actifs cosmétiques les plus solidement documentés.",
        },
        {
          kind: "stat",
          value: "4-12 semaines",
          label: "Délai avant les premiers effets visibles",
          body: "Le renouvellement cutané prend du temps : patience nécessaire avant de juger l'efficacité.",
        },
        {
          kind: "compare",
          title: "Rétinol vs trétinoïne",
          left: { label: "Rétinol (vente libre)", items: ["Moins puissant", "Moins irritant", "Bon point de départ"] },
          right: { label: "Trétinoïne (ordonnance)", items: ["Plus puissant", "Plus irritant au début", "Nécessite un avis médical"] },
        },
        {
          kind: "steps",
          title: "Comment l'introduire sans tout irriter",
          items: [
            "Commencer 1 à 2 fois par semaine, le soir uniquement",
            "Appliquer sur peau bien sèche pour limiter l'irritation",
            "Augmenter progressivement la fréquence sur plusieurs semaines",
            "Toujours protéger sa peau du soleil le lendemain",
          ],
        },
        {
          kind: "warn",
          title: "Précautions importantes",
          body: "Les rétinoïdes rendent la peau plus sensible au soleil : la protection solaire n'est plus optionnelle. Ils sont déconseillés en cas de grossesse. La trétinoïne nécessite une prescription : consulte un médecin ou un dermatologue.",
        },
        {
          kind: "list",
          title: "Effets secondaires fréquents au démarrage",
          items: ["Rougeurs et desquamation ('purge' des premières semaines)", "Sensibilité accrue au soleil", "Sensation de tiraillement"],
        },
        {
          kind: "image",
          image: "skin-mirror",
          caption: "L'introduction progressive limite la fameuse 'purge' du début de traitement.",
        },
        {
          kind: "checklist",
          title: "Avant de commencer les rétinoïdes",
          items: ["Je démarre à faible fréquence", "J'ai une crème solaire pour le lendemain matin", "Je n'associe pas avec trop d'autres actifs en même temps"],
        },
        {
          kind: "quiz",
          question: "Pourquoi la protection solaire devient essentielle sous rétinoïdes ?",
          options: [
            "Parce qu'ils décolorent la peau au soleil",
            "Parce qu'ils augmentent la sensibilité de la peau aux UV",
            "Ce n'est pas nécessaire",
          ],
          answer: 1,
          explanation: "Les rétinoïdes accélèrent le renouvellement cellulaire, ce qui rend la peau plus fine et plus vulnérable aux UV.",
        },
        {
          kind: "quiz",
          question: "Quel est le principal facteur qui différencie rétinol et trétinoïne ?",
          options: ["Le prix uniquement", "La puissance et le besoin de prescription médicale", "Aucune différence"],
          answer: 1,
          explanation: "La trétinoïne est plus puissante et disponible uniquement sur ordonnance, contrairement au rétinol en vente libre.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Retinoids/retinol guide", url: "https://www.aad.org/public/everyday-care/skin-care-secrets/anti-aging" },
            { label: "NHS — Vitamin A and skin treatments", url: "https://www.nhs.uk/medicines/" },
          ],
        },
      ],
    },
    {
      id: "skin-8",
      title: "Acné adulte : pourquoi ça continue après 25 ans",
      summary: "Hormones, stress, cosmétiques : les causes spécifiques de l'acné adulte.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-face",
      blocks: [
        {
          kind: "text",
          title: "Une acné différente de celle de l'adolescence",
          body: "L'acné adulte touche surtout le bas du visage (mâchoire, menton) et suit souvent un cycle hormonal. Elle est fréquente chez les femmes, mais existe aussi chez les hommes, liée au stress ou à certains cosmétiques trop riches.",
        },
        {
          kind: "image",
          image: "skin-face",
          caption: "L'acné adulte se concentre souvent autour de la mâchoire et du menton.",
        },
        {
          kind: "stat",
          value: "~1 adulte sur 4",
          label: "Part des adultes touchés par de l'acné après 25 ans",
          body: "L'estimation varie selon les études, mais le phénomène est loin d'être marginal ou réservé aux ados.",
        },
        {
          kind: "myth",
          myth: "L'acné adulte, c'est juste un manque d'hygiène.",
          truth: "L'hygiène joue un rôle mineur. Les causes principales sont hormonales, le stress, certains médicaments et des produits cosmétiques trop occlusifs.",
        },
        {
          kind: "compare",
          title: "Acné ado vs acné adulte",
          left: { label: "Acné adolescente", items: ["Zone T (front, nez, menton)", "Liée à la puberté", "S'améliore souvent avec l'âge"] },
          right: { label: "Acné adulte", items: ["Bas du visage, mâchoire", "Liée au cycle hormonal ou au stress", "Peut apparaître pour la première fois après 25 ans"] },
        },
        {
          kind: "list",
          title: "Facteurs aggravants fréquents",
          items: [
            "Stress chronique et manque de sommeil",
            "Cosmétiques ou crèmes solaires comédogènes",
            "Cycle hormonal (chez la femme, souvent avant les règles)",
            "Frottement répété (masque, téléphone, casque)",
          ],
        },
        {
          kind: "warn",
          title: "Quand consulter",
          body: "Une acné adulte persistante ou douloureuse mérite une consultation dermatologique : certains traitements hormonaux ou topiques sur ordonnance sont efficaces, mais nécessitent un avis médical.",
        },
        {
          kind: "checklist",
          title: "Réflexes à adopter",
          items: ["Je vérifie que mes cosmétiques sont non comédogènes", "Je nettoie les surfaces qui touchent mon visage (téléphone, taies)", "Je note si mes poussées suivent un cycle"],
        },
        {
          kind: "quiz",
          question: "Où se situe le plus souvent l'acné adulte sur le visage ?",
          options: ["Le front", "Le bas du visage et la mâchoire", "Les tempes uniquement"],
          answer: 1,
          explanation: "L'acné adulte touche préférentiellement le bas du visage, souvent liée au cycle hormonal.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Adult acne", url: "https://www.aad.org/public/diseases/acne" },
            { label: "NHS — Acne", url: "https://www.nhs.uk/conditions/acne/" },
          ],
        },
      ],
    },
    {
      id: "skin-9",
      title: "Pores et sébum : ce qu'on peut vraiment changer",
      summary: "Pourquoi tes pores ne 'rétrécissent' pas, et ce qui aide vraiment.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "skin-closeup",
      blocks: [
        {
          kind: "text",
          title: "La taille des pores est en grande partie génétique",
          body: "La taille d'un pore dépend de la génétique, de l'âge et de la production de sébum locale. Aucun produit ne 'referme' un pore de façon permanente : on peut seulement en réduire l'apparence.",
        },
        {
          kind: "myth",
          myth: "L'eau froide resserre les pores durablement.",
          truth: "L'eau froide peut donner un effet visuel temporaire par vasoconstriction, mais n'a aucun effet structurel durable sur la taille des pores.",
        },
        {
          kind: "image",
          image: "skin-closeup",
          caption: "Un pore paraît plus visible quand il est dilaté par du sébum ou des cellules mortes accumulées.",
        },
        {
          kind: "list",
          title: "Ce qui rend les pores plus visibles",
          items: [
            "Excès de sébum non nettoyé",
            "Accumulation de cellules mortes",
            "Perte d'élasticité de la peau avec l'âge",
            "Exposition solaire cumulée",
          ],
        },
        {
          kind: "compare",
          title: "Ce qui aide vs ce qui ne change rien",
          left: { label: "Aide un peu", items: ["Nettoyage régulier et doux", "Exfoliation chimique légère (acide salicylique)", "Protection solaire"] },
          right: { label: "N'a pas d'effet durable", items: ["Eau froide ou glaçons", "Bandes nettoyantes seules", "Masques 'resserrants' en vente libre"] },
        },
        {
          kind: "stat",
          value: "Facteur génétique majeur",
          label: "Détermination de la taille des pores",
          body: "La génétique fixe une bonne partie de la donne ; les soins n'agissent que sur leur aspect superficiel.",
        },
        {
          kind: "steps",
          title: "Routine réaliste anti-pores dilatés",
          items: [
            "Nettoie ta peau matin et soir sans excès",
            "Introduis un exfoliant chimique doux 1 à 2 fois par semaine si toléré",
            "Protège ta peau du soleil tous les jours",
          ],
        },
        {
          kind: "quiz",
          question: "Que peut-on réellement faire pour la taille des pores ?",
          options: [
            "Les refermer définitivement avec de l'eau froide",
            "Réduire leur aspect visible avec un nettoyage et une exfoliation adaptés",
            "Rien du tout, aucun soin n'a d'effet visible",
          ],
          answer: 1,
          explanation: "On ne change pas la taille structurelle des pores, mais un entretien régulier réduit leur aspect dilaté.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Skin care basics", url: "https://www.aad.org/public/everyday-care/skin-care-basics" },
          ],
        },
      ],
    },
    {
      id: "skin-10",
      title: "Marques post-acné et hyperpigmentation",
      summary: "Cicatrices, taches brunes ou rouges : comment elles se forment et s'estompent.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-face",
      blocks: [
        {
          kind: "text",
          title: "Marque n'est pas égale à cicatrice",
          body: "Après un bouton, une tache rouge ou brune peut rester plusieurs semaines à plusieurs mois : c'est de l'hyperpigmentation post-inflammatoire, pas une vraie cicatrice. Les cicatrices creusées sont un phénomène différent et plus durable.",
        },
        {
          kind: "image",
          image: "skin-face",
          caption: "Les marques post-acné s'estompent naturellement, mais lentement.",
        },
        {
          kind: "myth",
          myth: "Percer un bouton fait partir la marque plus vite.",
          truth: "Percer ou gratter augmente l'inflammation locale et le risque de marque durable ou de vraie cicatrice.",
        },
        {
          kind: "compare",
          title: "Hyperpigmentation vs cicatrice creusée",
          left: { label: "Hyperpigmentation", items: ["Tache plane, brune ou rouge", "S'estompe en quelques mois", "Le soleil la fonce et la prolonge"] },
          right: { label: "Cicatrice creusée", items: ["Relief modifié durablement", "Ne s'efface pas seule", "Nécessite parfois un traitement dermatologique"] },
        },
        {
          kind: "list",
          title: "Ce qui accélère l'estompage",
          items: [
            "Protection solaire quotidienne (le soleil fonce les marques)",
            "Actifs éclaircissants validés (vitamine C, niacinamide) en usage régulier",
            "Ne pas gratter ou percer les boutons actifs",
            "Patience : plusieurs semaines à quelques mois",
          ],
        },
        {
          kind: "warn",
          title: "Pour les cicatrices creusées",
          body: "Les cicatrices d'acné creusées nécessitent souvent une prise en charge dermatologique spécialisée (laser, peeling médical). Un dermatologue peut évaluer ce qui est adapté à ton cas.",
        },
        {
          kind: "steps",
          title: "Routine anti-marques",
          items: [
            "Applique une protection solaire chaque matin",
            "Introduis progressivement un actif éclaircissant toléré",
            "Laisse les boutons actifs cicatriser sans y toucher",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi la protection solaire est-elle essentielle contre les marques post-acné ?",
          options: [
            "Elle empêche totalement l'acné de revenir",
            "Le soleil fonce et prolonge l'hyperpigmentation",
            "Elle n'a aucun lien avec les marques",
          ],
          answer: 1,
          explanation: "Les UV stimulent la mélanine, ce qui fonce et prolonge les marques déjà présentes.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Acne scars", url: "https://www.aad.org/public/diseases/acne" },
            { label: "NHS — Skin conditions", url: "https://www.nhs.uk/conditions/" },
          ],
        },
      ],
    },
    {
      id: "skin-11",
      title: "Barrière cutanée abîmée : reconnaître et réparer",
      summary: "Rougeurs, tiraillements, sensibilité soudaine : comment relancer la réparation.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-mirror",
      blocks: [
        {
          kind: "text",
          title: "Reconnaître une barrière abîmée",
          body: "Tiraillements permanents, rougeurs diffuses, sensibilité nouvelle à des produits pourtant bien tolérés avant : ce sont les signes classiques d'une barrière cutanée fragilisée par un excès d'actifs ou un nettoyage trop agressif.",
        },
        {
          kind: "image",
          image: "skin-mirror",
          caption: "Une peau qui pique en permanence signale une barrière abîmée, pas un manque de soin.",
        },
        {
          kind: "list",
          title: "Causes fréquentes",
          items: [
            "Trop d'actifs exfoliants ou de rétinoïdes cumulés",
            "Nettoyage trop fréquent ou trop décapant",
            "Air très sec ou froid prolongé",
            "Arrêt brutal d'une routine hydratante",
          ],
        },
        {
          kind: "myth",
          myth: "Il faut continuer les actifs pour que la peau 's'habitue'.",
          truth: "Face à une barrière déjà abîmée, continuer aggrave l'irritation. La priorité est d'arrêter les actifs et de réparer avant de les réintroduire.",
        },
        {
          kind: "steps",
          title: "Protocole de réparation (routine minimaliste)",
          items: [
            "Stoppe tous les actifs (rétinoïdes, exfoliants, parfums) pendant 1 à 2 semaines",
            "Nettoie uniquement à l'eau tiède ou avec un nettoyant très doux",
            "Applique une crème réparatrice riche en céramides plusieurs fois par jour",
            "Réintroduis les actifs un par un, très progressivement, une fois la peau apaisée",
          ],
        },
        {
          kind: "compare",
          title: "Peau saine vs barrière abîmée",
          left: { label: "Barrière saine", items: ["Tolère bien les produits habituels", "Pas de tiraillement", "Aspect uniforme"] },
          right: { label: "Barrière abîmée", items: ["Picotements même avec des produits doux", "Rougeurs diffuses", "Sensation de peau qui tire en permanence"] },
        },
        {
          kind: "warn",
          title: "Quand consulter",
          body: "Si les rougeurs persistent plus de 2-3 semaines malgré une routine minimaliste, ou s'accompagnent de démangeaisons fortes, consulte un dermatologue pour écarter une autre cause (eczéma, dermatite).",
        },
        {
          kind: "checklist",
          title: "Pendant la phase de réparation",
          items: ["J'ai arrêté tous les actifs", "J'utilise une crème riche en céramides", "Je limite mon exposition au vent et au froid"],
        },
        {
          kind: "quiz",
          question: "Que faire en priorité face à une barrière cutanée abîmée ?",
          options: [
            "Continuer les actifs pour habituer la peau",
            "Arrêter les actifs et simplifier la routine pour réparer",
            "Exfolier davantage pour accélérer le renouvellement",
          ],
          answer: 1,
          explanation: "La priorité est de retirer les facteurs irritants et de laisser la peau réparer sa barrière avant de réintroduire des actifs.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Skin care basics", url: "https://www.aad.org/public/everyday-care/skin-care-basics" },
            { label: "NHS — Skin conditions", url: "https://www.nhs.uk/conditions/" },
          ],
        },
      ],
    },
    {
      id: "skin-12",
      title: "Transpiration et acné du corps (dos, torse)",
      summary: "Pourquoi le sport et la chaleur favorisent les boutons sur le corps, et comment limiter ça.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "skin-closeup",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi le dos et le torse trinquent",
          body: "La peau du dos et du torse a plus de glandes sébacées que le visage. Combinée à la transpiration, aux frottements de vêtements et à un rinçage tardif après le sport, elle favorise les boutons d'acné mécanique.",
        },
        {
          kind: "image",
          image: "skin-closeup",
          caption: "Les frottements répétés (sac à dos, équipement de sport) peuvent déclencher des boutons localisés.",
        },
        {
          kind: "list",
          title: "Facteurs déclenchants courants",
          items: [
            "Vêtements de sport synthétiques trop serrés",
            "Douche tardive après une séance de sport",
            "Sac à dos ou équipement qui frotte au même endroit",
            "Crèmes solaires ou lotions corporelles comédogènes",
          ],
        },
        {
          kind: "myth",
          myth: "Transpirer beaucoup 'nettoie' la peau de l'intérieur.",
          truth: "La transpiration en elle-même n'est pas nettoyante ; c'est le mélange sueur + sébum + friction laissé sur la peau qui favorise les boutons si on ne se rince pas rapidement.",
        },
        {
          kind: "steps",
          title: "Limiter l'acné du corps",
          items: [
            "Douche dans les 30-60 minutes après le sport",
            "Change de vêtement de sport humide rapidement",
            "Privilégie des textiles respirants",
            "Utilise un nettoyant doux, pas un savon décapant, sur le corps",
          ],
        },
        {
          kind: "compare",
          title: "Bonnes vs mauvaises habitudes post-sport",
          left: { label: "Bonnes habitudes", items: ["Douche rapide après l'effort", "Vêtements secs et propres", "Nettoyant doux"] },
          right: { label: "Mauvaises habitudes", items: ["Rester en tenue de sport humide", "Douche tardive (plusieurs heures après)", "Frotter fort pour 'bien nettoyer'"] },
        },
        {
          kind: "checklist",
          title: "Après chaque séance de sport",
          items: ["Je me change rapidement", "Je me douche dans l'heure", "Je nettoie mon équipement (casque, épaulières) régulièrement"],
        },
        {
          kind: "quiz",
          question: "Quel est le facteur le plus efficace pour limiter l'acné du dos liée au sport ?",
          options: [
            "Transpirer le plus possible",
            "Se doucher rapidement après l'effort",
            "Porter des vêtements très serrés",
          ],
          answer: 1,
          explanation: "Rincer rapidement sueur et sébum limite l'accumulation qui bouche les pores après l'effort.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Body acne", url: "https://www.aad.org/public/diseases/acne" },
          ],
        },
      ],
    },
    {
      id: "skin-14",
      title: "Bien choisir sa crème hydratante",
      summary: "Humectant, émollient, occlusif : comprendre les étiquettes pour arrêter de deviner.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "skin-14-moisturizer",
      blocks: [
        {
          kind: "text",
          title: "Trois familles d'ingrédients, trois rôles",
          body: "Une bonne crème hydratante combine souvent trois types d'ingrédients : les humectants qui attirent l'eau, les émollients qui lissent la texture, et les occlusifs qui empêchent l'eau de s'évaporer. Comprendre ça évite d'acheter au hasard.",
        },
        {
          kind: "list",
          title: "Les trois familles en pratique",
          items: [
            "Humectants : glycérine, acide hyaluronique — attirent l'eau vers la peau",
            "Émollients : squalane, huiles végétales — adoucissent et lissent",
            "Occlusifs : vaseline, beurre de karité — bloquent l'évaporation",
          ],
        },
        {
          kind: "image",
          image: "skin-face",
          caption: "Une texture qui convient à ta peau se choisit par essai, pas par la mode.",
        },
        {
          kind: "myth",
          myth: "Peau grasse veut dire pas besoin de crème hydratante.",
          truth: "Une peau grasse peut manquer d'eau tout en produisant du sébum en excès. Sauter l'hydratant pousse souvent la peau à sursécréter davantage.",
        },
        {
          kind: "compare",
          title: "Peau grasse vs peau sèche",
          left: { label: "Peau grasse/mixte", items: ["Texture légère, gel-crème", "Éviter les occlusifs épais", "Formule non comédogène"] },
          right: { label: "Peau sèche", items: ["Texture riche, crème", "Occlusifs bienvenus le soir", "Recherche 'céramides' sur l'étiquette"] },
        },
        {
          kind: "steps",
          title: "Tester une nouvelle crème sans risque",
          items: [
            "Applique une petite quantité sur l'avant-bras pendant 2-3 jours",
            "Vérifie l'absence de rougeur ou de démangeaison",
            "Passe au visage progressivement si tout va bien",
          ],
        },
        {
          kind: "stat",
          value: "3 ingrédients",
          label: "Suffisent souvent à une bonne formule",
          body: "Une liste d'ingrédients courte avec un humectant, un émollient et éventuellement un occlusif fait généralement le travail, sans besoin d'une formule à 20 actifs.",
        },
        {
          kind: "checklist",
          title: "Avant d'acheter une crème",
          items: ["Je connais ma texture de peau (grasse, sèche, mixte)", "Je vérifie la présence d'un humectant", "Je teste sur une petite zone avant le visage entier"],
        },
        {
          kind: "quiz",
          question: "Quel est le rôle d'un ingrédient occlusif comme la vaseline ?",
          options: [
            "Attirer l'eau dans la peau",
            "Empêcher l'eau de s'évaporer de la peau",
            "Exfolier les cellules mortes",
          ],
          answer: 1,
          explanation: "Les occlusifs forment un film qui limite la perte en eau transépidermique, complétant l'action des humectants.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Skin care basics", url: "https://www.aad.org/public/everyday-care/skin-care-basics" },
            { label: "NHS — Dry skin", url: "https://www.nhs.uk/conditions/" },
          ],
        },
      ],
    },
    {
      id: "skin-15",
      title: "Sommeil et peau : le lien réel",
      summary: "Ce que le manque de sommeil change vraiment sur ton visage, sans exagération marketing.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "skin-15-sleep",
      blocks: [
        {
          kind: "text",
          title: "La nuit, la peau se régénère",
          body: "Pendant le sommeil, le renouvellement cellulaire et la production de collagène augmentent, et le flux sanguin cutané se réorganise. Un sommeil insuffisant ou irrégulier perturbe ce processus de réparation.",
        },
        {
          kind: "stat",
          value: "7-9 heures",
          label: "Durée de sommeil recommandée chez l'adulte",
          body: "En dessous de ce repère régulièrement, les études associent le manque de sommeil à un teint plus terne et une récupération cutanée plus lente.",
        },
        {
          kind: "image",
          image: "skin-mirror",
          caption: "Cernes et teint terne sont parmi les premiers signes visibles d'un sommeil insuffisant.",
        },
        {
          kind: "myth",
          myth: "Une crème de nuit compense un manque de sommeil chronique.",
          truth: "Aucun soin topique ne remplace le sommeil : les cosmétiques agissent en surface, alors que la réparation cutanée profonde dépend des cycles de sommeil eux-mêmes.",
        },
        {
          kind: "list",
          title: "Effets documentés du manque de sommeil sur la peau",
          items: [
            "Teint plus terne et cernes plus marqués",
            "Récupération plus lente après une irritation",
            "Barrière cutanée un peu plus perméable à l'eau",
          ],
        },
        {
          kind: "compare",
          title: "Bonne nuit vs nuit courte",
          left: { label: "Sommeil suffisant", items: ["Teint plus uniforme", "Meilleure récupération cutanée", "Cernes moins marqués"] },
          right: { label: "Sommeil insuffisant", items: ["Teint terne", "Cernes accentués", "Peau plus sensible aux irritants"] },
        },
        {
          kind: "steps",
          title: "Habitudes simples pour un meilleur sommeil",
          items: [
            "Horaires de coucher réguliers",
            "Écrans coupés 30 minutes avant de dormir",
            "Chambre fraîche et sombre",
          ],
        },
        {
          kind: "checklist",
          title: "Ce soir",
          items: ["Je me couche à une heure régulière", "Je nettoie ma peau avant de dormir", "Je vise 7 à 9 heures de sommeil"],
        },
        {
          kind: "quiz",
          question: "Que fait principalement le sommeil pour la peau ?",
          options: [
            "Il remplace le besoin de nettoyage",
            "Il favorise le renouvellement cellulaire et la réparation cutanée",
            "Il n'a aucun effet mesurable",
          ],
          answer: 1,
          explanation: "Le sommeil est une fenêtre de réparation et de renouvellement cellulaire pour la peau, difficile à compenser autrement.",
        },
        {
          kind: "sources",
          items: [
            { label: "Sleep Foundation — Sleep and skin health", url: "https://www.sleepfoundation.org/" },
            { label: "NHS — Sleep and tiredness", url: "https://www.nhs.uk/live-well/sleep-and-tiredness/" },
          ],
        },
      ],
    },
    {
      id: "skin-16",
      title: "Exfoliation : physique vs chimique",
      summary: "Gommage granuleux ou acides : lequel choisir sans abîmer ta barrière cutanée.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-16-exfoliation",
      blocks: [
        {
          kind: "text",
          title: "Deux façons de retirer les cellules mortes",
          body: "L'exfoliation physique frotte mécaniquement la surface (grains, brosse). L'exfoliation chimique utilise des acides (AHA, BHA) qui dissolvent les liens entre cellules mortes, souvent de façon plus douce et plus uniforme.",
        },
        {
          kind: "compare",
          title: "Physique vs chimique",
          left: { label: "Exfoliation physique", items: ["Effet immédiat visible", "Risque de micro-lésions si grains trop gros", "Facile à surdoser"] },
          right: { label: "Exfoliation chimique", items: ["Action plus uniforme", "AHA pour la surface, BHA pour les pores gras", "Nécessite une protection solaire renforcée"] },
        },
        {
          kind: "image",
          image: "skin-closeup",
          caption: "Un gommage trop granuleux peut créer des micro-déchirures invisibles à l'œil nu.",
        },
        {
          kind: "myth",
          myth: "Exfolier tous les jours donne une peau plus nette plus vite.",
          truth: "Une exfoliation quotidienne fragilise la barrière cutanée. 1 à 3 fois par semaine suffit pour la majorité des peaux.",
        },
        {
          kind: "list",
          title: "Repères de fréquence",
          items: [
            "Peau sensible : 1 fois par semaine, chimique douce (acide lactique)",
            "Peau normale : 2 fois par semaine",
            "Peau grasse/à pores dilatés : jusqu'à 3 fois par semaine avec du BHA",
          ],
        },
        {
          kind: "warn",
          title: "Ne jamais cumuler avec des actifs forts",
          body: "Exfolier le même soir qu'un rétinoïde ou un peroxyde de benzoyle multiplie le risque d'irritation sévère. Espace ces actifs sur des jours différents.",
        },
        {
          kind: "steps",
          title: "Introduire un exfoliant chimique sans risque",
          items: [
            "Commence à 1 application par semaine",
            "Applique le soir, jamais avant une exposition solaire",
            "Augmente la fréquence seulement si aucune irritation après 2 semaines",
            "Protège ta peau du soleil le lendemain matin",
          ],
        },
        {
          kind: "checklist",
          title: "Avant d'exfolier",
          items: ["Ma peau n'est pas déjà irritée", "Je n'utilise pas un autre actif fort ce soir-là", "J'ai une crème solaire pour le lendemain"],
        },
        {
          kind: "quiz",
          question: "Pourquoi éviter d'exfolier tous les jours ?",
          options: [
            "Ça n'a aucun risque, plus c'est fréquent mieux c'est",
            "Ça fragilise la barrière cutanée à force",
            "Ça rend la peau plus grasse immédiatement",
          ],
          answer: 1,
          explanation: "Une exfoliation trop fréquente use la barrière cutanée et provoque irritation, rougeurs et sensibilité accrue.",
        },
        {
          kind: "quiz",
          question: "Quelle association d'actifs le même soir est à éviter ?",
          options: [
            "Hydratant et exfoliant chimique",
            "Exfoliant chimique et rétinoïde",
            "Nettoyant doux et crème hydratante",
          ],
          answer: 1,
          explanation: "Cumuler exfoliant et rétinoïde le même soir augmente fortement le risque d'irritation ; mieux vaut les alterner.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD — Skin care basics", url: "https://www.aad.org/public/everyday-care/skin-care-basics" },
            { label: "Examine.com — Base de données sur les actifs", url: "https://examine.com/" },
          ],
        },
      ],
    },
    {
      id: "skin-17",
      title: "Alimentation et peau : ce que dit vraiment la science",
      summary: "Sucre, produits laitiers, oméga-3 : le tri entre effet réel et rumeur.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "skin-17-nutrition",
      blocks: [
        {
          kind: "text",
          title: "Un lien réel, mais souvent surestimé",
          body: "L'alimentation influence la peau, mais elle est rarement la cause unique d'un problème cutané. Certains liens sont bien documentés, d'autres restent débattus ou marginaux.",
        },
        {
          kind: "list",
          title: "Liens avec un niveau de preuve correct",
          items: [
            "Index glycémique élevé (sucre, produits raffinés) associé à plus d'acné chez certaines personnes",
            "Certains produits laitiers (notamment le lait écrémé) associés à l'acné dans plusieurs études",
            "Oméga-3 associés à une meilleure barrière cutanée et moins d'inflammation",
          ],
        },
        {
          kind: "image",
          image: "skin-face",
          caption: "L'alimentation est un facteur parmi d'autres, pas une solution miracle contre l'acné.",
        },
        {
          kind: "myth",
          myth: "Boire beaucoup d'eau suffit à effacer les boutons.",
          truth: "L'hydratation générale est utile pour la santé globale, mais aucune preuve solide ne montre qu'elle suffit à traiter l'acné à elle seule.",
        },
        {
          kind: "compare",
          title: "Ce qui a du poids vs ce qui est surestimé",
          left: { label: "Effet documenté", items: ["Excès de sucre raffiné", "Certains produits laitiers", "Carence en oméga-3"] },
          right: { label: "Effet surestimé ou anecdotique", items: ["Chocolat noir en soi", "Un seul repas 'gras'", "Boire plus d'eau que la soif ne le demande"] },
        },
        {
          kind: "warn",
          title: "Pas de régime miracle",
          body: "Éliminer des groupes entiers d'aliments sans avis médical peut créer des carences sans garantie de résultat sur la peau. Un ajustement progressif et raisonnable est plus sûr.",
        },
        {
          kind: "steps",
          title: "Ajustements raisonnables à tester",
          items: [
            "Réduis progressivement les sucres raffinés et sodas",
            "Ajoute des sources d'oméga-3 (poisson gras, graines de lin)",
            "Observe sur plusieurs semaines, pas quelques jours",
            "N'élimine pas un groupe alimentaire entier sans avis professionnel",
          ],
        },
        {
          kind: "checklist",
          title: "Bon réflexe alimentation-peau",
          items: ["Je limite les sucres raffinés sans les bannir totalement", "J'intègre des oméga-3 régulièrement", "Je laisse plusieurs semaines avant de juger un changement"],
        },
        {
          kind: "quiz",
          question: "Quel facteur alimentaire a le lien le mieux documenté avec l'acné ?",
          options: [
            "Le chocolat noir",
            "L'index glycémique élevé",
            "Le café sans sucre",
          ],
          answer: 1,
          explanation: "Plusieurs études associent une alimentation à index glycémique élevé à une aggravation de l'acné, plus que le chocolat en tant que tel.",
        },
        {
          kind: "sources",
          items: [
            { label: "ANSES — Alimentation et santé", url: "https://www.anses.fr/" },
            { label: "Examine.com — Nutrition et peau", url: "https://examine.com/" },
            { label: "Inserm — Nutrition", url: "https://www.inserm.fr/" },
          ],
        },
      ],
    },
    {
      id: "skin-18",
      title: "Stress, cortisol et peau : le lien cerveau-peau",
      summary: "Comment le stress chronique se voit sur ta peau, et ce qui casse vraiment le cercle.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "skin-18-stress",
      blocks: [
        {
          kind: "text",
          title: "Un axe biologique réel",
          body: "Le stress chronique élève le cortisol, qui augmente la production de sébum, ralentit la réparation de la barrière cutanée et amplifie l'inflammation locale. C'est ce qu'on appelle l'axe cerveau-peau.",
        },
        {
          kind: "stat",
          value: "Cortisol ↑",
          label: "Effet mesuré du stress chronique",
          body: "Des niveaux de cortisol chroniquement élevés sont associés dans la littérature à une production accrue de sébum et à une cicatrisation plus lente.",
        },
        {
          kind: "image",
          image: "skin-closeup",
          caption: "Poussées d'acné avant un examen ou une échéance : ce n'est pas qu'une impression.",
        },
        {
          kind: "myth",
          myth: "Le stress ne joue aucun rôle direct sur la peau, c'est juste psychologique.",
          truth: "Le stress a un effet biologique mesurable sur la peau via le cortisol et l'inflammation, en plus des effets indirects (sommeil, alimentation, grattage).",
        },
        {
          kind: "compare",
          title: "Effets directs vs indirects du stress",
          left: { label: "Effets directs", items: ["Hausse du cortisol", "Sébum en excès", "Inflammation locale accrue"] },
          right: { label: "Effets indirects", items: ["Moins bon sommeil", "Grattage ou triturage de la peau", "Alimentation moins régulière"] },
        },
        {
          kind: "list",
          title: "Signes cutanés associés au stress chronique",
          items: [
            "Poussées d'acné localisées avant des périodes chargées",
            "Démangeaisons ou rougeurs sans cause apparente",
            "Cicatrisation plus lente qu'habituellement",
          ],
        },
        {
          kind: "warn",
          title: "Le cercle vicieux à casser",
          body: "Le stress abîme la peau, et une peau qui va mal peut à son tour générer du stress social ou de l'anxiété. Traiter uniquement la peau sans agir sur le stress limite souvent les résultats.",
        },
        {
          kind: "steps",
          title: "Réduire l'impact du stress sur la peau",
          items: [
            "Identifie 1 à 2 techniques de gestion du stress qui te conviennent (respiration, marche, sport)",
            "Stabilise ton sommeil en priorité",
            "Simplifie ta routine peau en période de stress intense plutôt que d'en rajouter",
            "Évite de trituler ta peau comme exutoire",
          ],
        },
        {
          kind: "checklist",
          title: "En période de stress élevé",
          items: ["Je garde une routine peau simple et stable", "J'ajoute un moment de décompression dans ma journée", "Je surveille mon sommeil de près"],
        },
        {
          kind: "quiz",
          question: "Comment le cortisol agit-il concrètement sur la peau ?",
          options: [
            "Il n'a aucun effet biologique direct",
            "Il augmente la production de sébum et l'inflammation",
            "Il accélère uniquement la pousse des cheveux",
          ],
          answer: 1,
          explanation: "Le cortisol chroniquement élevé stimule les glandes sébacées et entretient un état inflammatoire local.",
        },
        {
          kind: "quiz",
          question: "Que privilégier en période de stress intense pour sa peau ?",
          options: [
            "Ajouter plusieurs nouveaux actifs pour 'compenser'",
            "Garder une routine simple et stable",
            "Exfolier plus souvent pour accélérer le renouvellement",
          ],
          answer: 1,
          explanation: "En période de stress, la peau est plus réactive : une routine simple limite le risque d'irritation supplémentaire.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA — Stress effects on the body", url: "https://www.apa.org/topics/stress" },
            { label: "NCBI / PubMed — Stress and skin (recherche)", url: "https://www.ncbi.nlm.nih.gov/pmc/?term=stress+skin+cortisol" },
            { label: "Ameli — Le stress et ses effets", url: "https://www.ameli.fr/" },
          ],
        },
      ],
    },
    {
      id: "skin-13",
      title: "Bien soigner une petite blessure ou un bouton percé",
      summary: "Le protocole simple qui limite les cicatrices après une coupure ou une lésion cutanée.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "skin-face",
      blocks: [
        {
          kind: "text",
          title: "Le mauvais réflexe : laisser sécher à l'air",
          body: "Contrairement à l'idée reçue, une plaie cicatrise mieux dans un milieu légèrement humide et protégé qu'à l'air libre, ce qui limite les croûtes épaisses et les marques.",
        },
        {
          kind: "steps",
          title: "Protocole simple",
          items: [
            "Nettoie la zone à l'eau et un savon doux ou du sérum physiologique",
            "Applique une crème cicatrisante ou vaseline en fine couche",
            "Protège avec un pansement si la zone est exposée aux frottements",
            "Renouvelle le nettoyage et le soin une à deux fois par jour",
          ],
        },
        {
          kind: "image",
          image: "skin-face",
          caption: "Une petite lésion bien protégée cicatrise plus vite et laisse moins de marque.",
        },
        {
          kind: "myth",
          myth: "Il faut laisser une plaie à l'air libre pour qu'elle 'respire' et sèche plus vite.",
          truth: "Un environnement humide contrôlé (crème + pansement adapté) favorise une meilleure cicatrisation qu'un séchage à l'air, qui forme des croûtes plus marquantes.",
        },
        {
          kind: "list",
          title: "Erreurs fréquentes",
          items: [
            "Percer un bouton avec les doigts non lavés",
            "Retirer une croûte avant qu'elle ne tombe seule",
            "Exposer une plaie fraîche au soleil sans protection",
          ],
        },
        {
          kind: "warn",
          title: "Signes d'infection à surveiller",
          body: "Rougeur qui s'étend, chaleur locale, pus ou fièvre : ce sont des signes d'infection qui nécessitent une consultation médicale rapide, pas un soin maison prolongé.",
        },
        {
          kind: "checklist",
          title: "Réflexes après une petite blessure",
          items: ["Je nettoie avant de soigner", "J'évite de toucher avec les mains sales", "Je protège du soleil une fois cicatrisé"],
        },
        {
          kind: "quiz",
          question: "Quel environnement favorise une meilleure cicatrisation ?",
          options: ["L'air libre pour sécher vite", "Un milieu légèrement humide et protégé", "Aucune différence"],
          answer: 1,
          explanation: "Un milieu humide contrôlé (crème adaptée + pansement) accélère la cicatrisation et limite les marques par rapport au séchage à l'air.",
        },
        {
          kind: "sources",
          items: [
            { label: "NHS — Wound care", url: "https://www.nhs.uk/conditions/" },
            { label: "AAD — Skin care basics", url: "https://www.aad.org/public/everyday-care/skin-care-basics" },
          ],
        },
      ],
    },
  ],
};
