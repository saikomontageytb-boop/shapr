import type { Track } from "@/lib/academy-types";

export const stress: Track = {
  id: "stress",
  title: "Stress & récupération",
  tagline: "Reprends le contrôle de ton système nerveux.",
  intro:
    "Cortisol, respiration, surcharge, récupération : les mécanismes du stress expliqués simplement, avec des outils concrets à utiliser aujourd'hui.",
  icon: "brain",
  cover: "stress-cover",
  lessons: [
    {
      id: "stress-1",
      title: "Le cortisol, ton allié mal compris",
      summary: "Comprendre l'hormone du stress avant de vouloir la combattre.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "stress-cortisol",
      blocks: [
        {
          kind: "text",
          title: "À quoi sert le cortisol",
          body: "Le cortisol te réveille le matin, mobilise ton énergie et t'aide à réagir face à un danger ou une échéance. Le problème n'est pas son existence, c'est sa présence chronique et élevée.",
        },
        {
          kind: "image",
          image: "stress-cortisol",
          caption: "Le cortisol suit normalement un rythme : haut le matin, bas le soir.",
        },
        {
          kind: "stat",
          value: "30-45 min",
          label: "Pic de cortisol après le réveil",
          body: "C'est un phénomène naturel appelé 'cortisol awakening response', utile pour démarrer la journée.",
        },
        {
          kind: "myth",
          myth: "Le cortisol est toujours mauvais pour la santé.",
          truth: "Le cortisol est indispensable à court terme. C'est son élévation prolongée, sans phases de récupération, qui pose problème.",
        },
        {
          kind: "list",
          title: "Signes d'un cortisol chroniquement élevé",
          items: [
            "Sommeil léger ou réveils nocturnes",
            "Fatigue qui ne part pas avec le repos",
            "Irritabilité inhabituelle",
            "Envies de sucre en fin de journée",
          ],
        },
        {
          kind: "compare",
          title: "Stress aigu vs stress chronique",
          left: { label: "Stress aigu", items: ["Réponse ponctuelle", "Utile pour l'action", "Retour rapide au calme"] },
          right: { label: "Stress chronique", items: ["Activation continue", "Épuise les ressources", "Perturbe sommeil et humeur"] },
        },
        {
          kind: "steps",
          title: "Remettre du rythme",
          items: [
            "Expose-toi à la lumière du jour tôt le matin",
            "Garde des horaires de sommeil réguliers",
            "Réserve des moments sans sollicitation dans la journée",
          ],
        },
        {
          kind: "checklist",
          title: "Aujourd'hui",
          items: [
            "Je sors à la lumière dans l'heure qui suit le réveil",
            "Je note un moment de calme dans ma journée",
          ],
        },
        {
          kind: "quiz",
          question: "Que représente le cortisol du matin ?",
          options: ["Un dérèglement", "Un pic naturel utile", "Un signe de maladie", "Un effet du café"],
          answer: 1,
          explanation: "Le pic matinal de cortisol est un phénomène physiologique normal qui aide à démarrer la journée.",
        },
        {
          kind: "sources",
          items: [
            { label: "Inserm – Stress", url: "https://www.inserm.fr/" },
            { label: "APA – Stress", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "stress-2",
      title: "Respirer pour calmer le système nerveux",
      summary: "Une technique simple pour désactiver l'alarme intérieure.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "stress-breathing",
      blocks: [
        {
          kind: "text",
          title: "La respiration, un levier direct",
          body: "Contrairement au rythme cardiaque, la respiration est un des seuls signaux du système nerveux autonome que tu peux contrôler volontairement. Ralentir ton souffle envoie un message de sécurité à ton cerveau.",
        },
        {
          kind: "image",
          image: "stress-breathing",
          caption: "Une expiration plus longue que l'inspiration active le système parasympathique.",
        },
        {
          kind: "steps",
          title: "La respiration 4-6",
          items: [
            "Inspire par le nez pendant 4 secondes",
            "Expire par la bouche pendant 6 secondes",
            "Répète pendant 2 à 5 minutes",
          ],
        },
        {
          kind: "stat",
          value: "6 respirations/min",
          label: "Rythme associé à la relaxation",
          body: "Un rythme plus lent que la moyenne (12-16/min) favorise la variabilité cardiaque, un marqueur de bonne récupération.",
        },
        {
          kind: "myth",
          myth: "Respirer profondément veut dire inspirer un grand coup.",
          truth: "Une respiration efficace pour calmer le stress mise surtout sur une expiration longue et lente, pas sur le volume d'air inspiré.",
        },
        {
          kind: "drill",
          title: "Exercice express",
          body: "Fais 10 cycles de respiration 4-6, assis, les épaules relâchées.",
          duration: "3 min",
        },
        {
          kind: "list",
          title: "Bons moments pour la pratiquer",
          items: [
            "Avant une réunion stressante",
            "Avant de dormir",
            "Après une contrariété",
          ],
        },
        {
          kind: "checklist",
          title: "À tester",
          items: [
            "Je fais 10 cycles de respiration 4-6 aujourd'hui",
            "Je repère un moment où je respire trop vite",
          ],
        },
        {
          kind: "quiz",
          question: "Que privilégier pour calmer le système nerveux par la respiration ?",
          options: ["Une inspiration très rapide", "Une expiration plus longue que l'inspiration", "Retenir sa respiration", "Respirer par la bouche uniquement"],
          answer: 1,
          explanation: "Allonger l'expiration active le système parasympathique, associé à la détente.",
        },
        {
          kind: "sources",
          items: [
            { label: "NHS – Breathing exercises for stress", url: "https://www.nhs.uk/" },
            { label: "APA", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "stress-3",
      title: "Repérer les signaux du stress au quotidien",
      summary: "Les premiers signes avant que la surcharge s'installe.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "stress-signals",
      blocks: [
        {
          kind: "text",
          title: "Le corps parle avant la tête",
          body: "Avant même de te sentir 'stressé' mentalement, ton corps envoie des signaux : tensions, mâchoire serrée, respiration courte. Apprendre à les repérer permet d'agir tôt.",
        },
        {
          kind: "image",
          image: "stress-signals",
          caption: "Les tensions musculaires sont souvent le premier signal visible du stress.",
        },
        {
          kind: "list",
          title: "Signaux physiques fréquents",
          items: [
            "Mâchoire ou épaules contractées",
            "Respiration haute et rapide",
            "Mains moites ou tremblantes",
            "Estomac noué",
          ],
        },
        {
          kind: "myth",
          myth: "Le stress est uniquement dans la tête.",
          truth: "Le stress se manifeste très concrètement dans le corps, souvent avant même que tu en aies conscience mentalement.",
        },
        {
          kind: "steps",
          title: "Faire un scan corporel rapide",
          items: [
            "Relâche consciemment tes épaules",
            "Desserre la mâchoire",
            "Observe le rythme de ta respiration",
          ],
        },
        {
          kind: "compare",
          title: "Corps détendu vs corps en alerte",
          left: { label: "Détendu", items: ["Respiration ample", "Épaules basses", "Mâchoire relâchée"] },
          right: { label: "En alerte", items: ["Respiration courte", "Épaules remontées", "Mâchoire serrée"] },
        },
        {
          kind: "drill",
          title: "Scan corporel de 1 minute",
          body: "Ferme les yeux et parcours ton corps de la tête aux pieds, en relâchant chaque zone tendue.",
          duration: "1 min",
        },
        {
          kind: "checklist",
          title: "Aujourd'hui",
          items: [
            "J'ai fait un scan corporel",
            "J'ai repéré une tension et je l'ai relâchée",
          ],
        },
        {
          kind: "quiz",
          question: "Où le stress se manifeste-t-il en premier le plus souvent ?",
          options: ["Uniquement dans les pensées", "Dans le corps (tensions, respiration)", "Nulle part avant la crise", "Seulement la nuit"],
          answer: 1,
          explanation: "Le corps donne souvent des signaux physiques de stress avant une prise de conscience mentale claire.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Stress effects on the body", url: "https://www.apa.org/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "stress-4",
      title: "S'accorder une vraie pause",
      summary: "La base d'un jour off qui recharge vraiment.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "stress-pause",
      blocks: [
        {
          kind: "text",
          title: "Une pause, ce n'est pas juste s'arrêter de travailler",
          body: "Regarder son téléphone en boucle n'est pas une pause pour le cerveau. Une vraie pause réduit la sollicitation mentale, pas seulement l'activité physique.",
        },
        {
          kind: "image",
          image: "stress-pause",
          caption: "Une pause efficace change de rythme, pas seulement d'activité.",
        },
        {
          kind: "list",
          title: "Ce qui constitue une vraie pause",
          items: [
            "Marcher sans écouteurs",
            "Regarder par la fenêtre quelques minutes",
            "Discuter sans objectif précis",
            "S'étirer ou bouger légèrement",
          ],
        },
        {
          kind: "myth",
          myth: "Scroller son téléphone, c'est se reposer.",
          truth: "Le scroll sollicite l'attention en continu et n'apporte pas le relâchement mental d'une vraie pause.",
        },
        {
          kind: "steps",
          title: "Installer des micro-pauses",
          items: [
            "Toutes les 90 minutes environ, lève-toi 2 minutes",
            "Éloigne-toi de ton écran",
            "Reviens seulement quand tu te sens un peu plus clair",
          ],
        },
        {
          kind: "compare",
          title: "Pause active vs pseudo-pause",
          left: { label: "Pause active", items: ["Change de posture", "Réduit la sollicitation mentale", "Recharge réellement"] },
          right: { label: "Pseudo-pause", items: ["Reste sur écran", "Sollicite encore l'attention", "Fatigue persiste"] },
        },
        {
          kind: "checklist",
          title: "Aujourd'hui",
          items: [
            "J'ai fait une pause sans écran",
            "Je me suis levé au moins une fois dans l'heure",
          ],
        },
        {
          kind: "quiz",
          question: "Qu'est-ce qui caractérise une vraie pause ?",
          options: ["Regarder son téléphone", "Réduire la sollicitation mentale", "Travailler plus vite", "Boire du café"],
          answer: 1,
          explanation: "Une pause efficace réduit la sollicitation de l'attention, contrairement au scroll ou aux mails.",
        },
        {
          kind: "sources",
          items: [
            { label: "NHS – Rest and recovery", url: "https://www.nhs.uk/" },
            { label: "APA", url: "https://www.apa.org/" },
          ],
        },
      ],
    },
    {
      id: "stress-5",
      title: "Froid et chaud : des outils accessibles",
      summary: "Douche froide, sauna : des bases simples pour débuter.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "stress-coldheat-basics",
      blocks: [
        {
          kind: "text",
          title: "Des stress contrôlés et bénéfiques",
          body: "L'exposition volontaire au froid ou à la chaleur constitue un stress modéré et bref, que le corps apprend à mieux gérer avec la répétition.",
        },
        {
          kind: "image",
          image: "stress-coldheat-basics",
          caption: "Douche froide, sauna, bain chaud : des pratiques millénaires étudiées aujourd'hui.",
        },
        {
          kind: "list",
          title: "Effets rapportés",
          items: [
            "Sensation d'alerte et d'énergie après le froid",
            "Détente musculaire après la chaleur",
            "Amélioration progressive de la tolérance au stress",
          ],
        },
        {
          kind: "myth",
          myth: "Il faut souffrir longtemps pour que ça marche.",
          truth: "Quelques dizaines de secondes suffisent pour débuter, l'important est la régularité plus que la durée.",
        },
        {
          kind: "steps",
          title: "Débuter en douceur",
          items: [
            "Termine ta douche par 15 à 30 secondes d'eau froide",
            "Reste attentif à ta respiration pendant l'exposition",
            "Augmente progressivement sur plusieurs semaines",
          ],
        },
        {
          kind: "compare",
          title: "Froid vs chaud",
          left: { label: "Froid", items: ["Effet stimulant", "Bon le matin"] },
          right: { label: "Chaud", items: ["Effet relaxant", "Bon en soirée"] },
        },
        {
          kind: "checklist",
          title: "À essayer",
          items: [
            "Je termine ma douche par de l'eau froide",
            "Je note mon ressenti après",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle est une bonne façon de débuter avec le froid ?",
          options: ["Un bain glacé de 20 minutes direct", "15 à 30 secondes en fin de douche", "Uniquement en hiver", "Jamais sans matériel spécial"],
          answer: 1,
          explanation: "Commencer progressivement par de courtes durées est plus sûr et plus tenable.",
        },
        {
          kind: "sources",
          items: [
            { label: "NHS", url: "https://www.nhs.uk/" },
            { label: "Examine.com – Cold exposure", url: "https://examine.com/" },
          ],
        },
      ],
    },
    {
      id: "stress-6",
      title: "Écrans : le premier réflexe à changer",
      summary: "Un seul ajustement simple pour réduire la sollicitation.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "stress-screens-basics",
      blocks: [
        {
          kind: "text",
          title: "Un seul geste, un vrai effet",
          body: "Avant de changer toutes tes habitudes numériques, un seul ajustement fait déjà une différence notable : désactiver les notifications non essentielles.",
        },
        {
          kind: "image",
          image: "stress-screens-basics",
          caption: "Chaque notification est une micro-interruption de l'attention.",
        },
        {
          kind: "stat",
          value: "Des dizaines par jour",
          label: "Notifications reçues en moyenne",
          body: "Chacune sollicite brièvement l'attention, même sans être ouverte, ce qui contribue à un fond de vigilance permanent.",
        },
        {
          kind: "myth",
          myth: "Répondre vite aux notifications montre que je suis efficace.",
          truth: "Répondre instantanément entretient surtout un état de sollicitation continue, sans réel gain de productivité.",
        },
        {
          kind: "steps",
          title: "Le réglage à faire aujourd'hui",
          items: [
            "Ouvre les réglages de notifications de ton téléphone",
            "Désactive celles des réseaux sociaux et applis non essentielles",
            "Garde uniquement les appels et messages importants",
          ],
        },
        {
          kind: "list",
          title: "Bénéfices attendus",
          items: [
            "Moins d'interruptions dans la journée",
            "Plus de facilité à se concentrer",
            "Sensation de calme accrue en fin de journée",
          ],
        },
        {
          kind: "checklist",
          title: "Aujourd'hui",
          items: [
            "J'ai désactivé au moins 3 notifications non essentielles",
          ],
        },
        {
          kind: "quiz",
          question: "Quel est un premier geste simple pour réduire le stress lié aux écrans ?",
          options: ["Acheter un nouveau téléphone", "Désactiver les notifications non essentielles", "Répondre plus vite", "Ajouter plus d'applications"],
          answer: 1,
          explanation: "Réduire les notifications diminue directement le nombre d'interruptions de l'attention.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Technology and stress", url: "https://www.apa.org/" },
            { label: "Sleep Foundation", url: "https://www.sleepfoundation.org/" },
          ],
        },
      ],
    },
    {
      id: "stress-7",
      title: "Désamorcer une interaction sociale stressante",
      summary: "Un outil simple avant une situation qui te met mal à l'aise.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "stress-social-basics",
      blocks: [
        {
          kind: "text",
          title: "L'appréhension avant l'interaction",
          body: "La peur du regard des autres se manifeste souvent avant même que l'interaction ait lieu, sous forme d'anticipation anxieuse. Un petit rituel de préparation peut réduire cette tension.",
        },
        {
          kind: "image",
          image: "stress-social-basics",
          caption: "L'anticipation est souvent plus intense que l'interaction elle-même.",
        },
        {
          kind: "list",
          title: "Signes d'anticipation anxieuse",
          items: [
            "Répéter mentalement ce que tu vas dire",
            "Imaginer le pire scénario possible",
            "Tension physique avant même de commencer",
          ],
        },
        {
          kind: "myth",
          myth: "Les autres remarquent forcément mon stress.",
          truth: "Les études sur le sujet montrent que les signes de nervosité sont perçus bien moins par les autres qu'on ne le pense soi-même.",
        },
        {
          kind: "steps",
          title: "Rituel avant une interaction",
          items: [
            "Fais 3 respirations lentes avant d'entrer",
            "Rappelle-toi un objectif simple pour l'échange (pas la perfection)",
            "Accepte à l'avance qu'un moment de gêne est normal",
          ],
        },
        {
          kind: "compare",
          title: "Anticipation utile vs anticipation excessive",
          left: { label: "Utile", items: ["Préparer un point clé", "Respirer avant", "Rester réaliste"] },
          right: { label: "Excessive", items: ["Imaginer le pire scénario", "Répéter en boucle", "Éviter complètement"] },
        },
        {
          kind: "checklist",
          title: "Avant ma prochaine interaction",
          items: [
            "Je fais 3 respirations lentes",
            "Je me fixe un objectif simple et réaliste",
          ],
        },
        {
          kind: "quiz",
          question: "Que montrent les études sur la perception du stress par les autres ?",
          options: ["Les autres voient toujours ton stress", "Les autres perçoivent bien moins de signes que tu ne le penses", "Le stress est totalement invisible", "Cela dépend uniquement de l'âge"],
          answer: 1,
          explanation: "L'effet de projecteur ('spotlight effect') montre qu'on surestime largement à quel point les autres remarquent notre nervosité.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Social anxiety", url: "https://www.apa.org/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "stress-8",
      title: "La surcharge chronique et ses pièges",
      summary: "Reconnaître la surcharge avant qu'elle explose.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "stress-overload",
      blocks: [
        {
          kind: "text",
          title: "La surcharge ne s'annonce pas d'un coup",
          body: "Elle s'installe progressivement : d'abord une fatigue mentale, puis une baisse de motivation, puis un sentiment d'être débordé même par des tâches simples.",
        },
        {
          kind: "image",
          image: "stress-overload",
          caption: "La surcharge cognitive s'accumule comme une dette.",
        },
        {
          kind: "list",
          title: "Signaux précoces à surveiller",
          items: [
            "Difficulté à te concentrer plus de 10-15 minutes",
            "Impression de courir après le temps en permanence",
            "Irritabilité pour des petites choses",
            "Sommeil qui se dégrade sans cause évidente",
          ],
        },
        {
          kind: "compare",
          title: "Charge gérable vs surcharge",
          left: { label: "Charge gérable", items: ["Tu récupères en une nuit", "Motivation stable", "Tu gardes de la marge"] },
          right: { label: "Surcharge", items: ["Fatigue qui persiste", "Tout devient pénible", "Tu dis oui sans réfléchir"] },
        },
        {
          kind: "myth",
          myth: "Il faut attendre le burnout pour agir.",
          truth: "Les signaux précoces sont justement le meilleur moment pour ajuster ta charge, avant que la récupération devienne beaucoup plus longue.",
        },
        {
          kind: "steps",
          title: "Faire le point chaque semaine",
          items: [
            "Note ton niveau d'énergie de 1 à 10 en fin de semaine",
            "Identifie ce qui a le plus pesé",
            "Retire ou reporte une chose évitable la semaine suivante",
          ],
        },
        {
          kind: "warn",
          title: "Ne pas confondre avec la dépression",
          body: "Une fatigue persistante avec perte de plaisir généralisée peut relever d'un trouble à évaluer avec un professionnel de santé, pas seulement d'une surcharge de travail.",
        },
        {
          kind: "checklist",
          title: "Bilan hebdo",
          items: [
            "J'ai noté mon niveau d'énergie",
            "J'ai identifié une source de surcharge",
            "J'ai retiré une tâche évitable",
          ],
        },
        {
          kind: "quiz",
          question: "Quel est le meilleur moment pour agir face à la surcharge ?",
          options: ["Une fois épuisé complètement", "Dès les premiers signaux", "Jamais, ça passe tout seul", "Seulement en vacances"],
          answer: 1,
          explanation: "Agir tôt évite que la charge s'accumule jusqu'à un épuisement plus long à récupérer.",
        },
        {
          kind: "sources",
          items: [
            { label: "OMS – Burn-out", url: "https://www.who.int/fr" },
            { label: "Ameli – Stress au travail", url: "https://www.ameli.fr/" },
          ],
        },
      ],
    },
    {
      id: "stress-9",
      title: "Les jours off, un investissement pas un luxe",
      summary: "Pourquoi ne rien faire fait partie de la performance.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "stress-restday",
      blocks: [
        {
          kind: "text",
          title: "Récupérer n'est pas un signe de faiblesse",
          body: "Le corps et le cerveau consolident leurs apprentissages et réparent leurs tissus pendant les phases de repos, pas pendant l'effort lui-même.",
        },
        {
          kind: "image",
          image: "stress-restday",
          caption: "Un vrai jour off réduit les sollicitations, pas seulement l'activité physique.",
        },
        {
          kind: "stat",
          value: "1 à 2 jours/semaine",
          label: "Fréquence de repos recommandée en pratique sportive régulière",
          body: "Le corps a besoin de ces fenêtres pour éviter l'accumulation de fatigue et le risque de blessure.",
        },
        {
          kind: "myth",
          myth: "Se reposer, c'est perdre du temps utile.",
          truth: "Sans récupération suffisante, les gains en sport comme au travail stagnent voire régressent : la fatigue accumulée dégrade la performance.",
        },
        {
          kind: "compare",
          title: "Vrai jour off vs faux jour off",
          left: { label: "Vrai jour off", items: ["Moins de sollicitations mentales", "Sommeil respecté", "Activité plaisir, sans pression"] },
          right: { label: "Faux jour off", items: ["Écrans du matin au soir", "Mails professionnels consultés", "Culpabilité de ne rien faire"] },
        },
        {
          kind: "steps",
          title: "Construire un vrai jour off",
          items: [
            "Fixe une plage sans notifications professionnelles",
            "Choisis une activité sans objectif de performance",
            "Autorise-toi explicitement à ne rien faire un moment",
          ],
        },
        {
          kind: "list",
          title: "Ce qui compte comme récupération",
          items: [
            "Marche sans écouteurs",
            "Temps social détendu",
            "Sommeil de qualité",
            "Activité créative sans enjeu",
          ],
        },
        {
          kind: "checklist",
          title: "Cette semaine",
          items: [
            "J'ai planifié un vrai jour off",
            "J'ai limité les notifications ce jour-là",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi les jours off sont-ils importants pour la performance ?",
          options: ["Ils n'ont aucun effet", "Le corps répare et consolide pendant le repos", "Ils remplacent le sommeil", "Ils sont utiles seulement pour les sportifs pro"],
          answer: 1,
          explanation: "La récupération permet la consolidation des adaptations physiques et mentales, indispensable à la progression.",
        },
        {
          kind: "sources",
          items: [
            { label: "NHS – Rest and recovery", url: "https://www.nhs.uk/" },
            { label: "Sleep Foundation", url: "https://www.sleepfoundation.org/" },
          ],
        },
      ],
    },
    {
      id: "stress-10",
      title: "Froid et chaud : protocoles et précautions",
      summary: "Aller plus loin avec le froid et la chaleur, en sécurité.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "stress-coldheat",
      blocks: [
        {
          kind: "text",
          title: "Construire un protocole progressif",
          body: "Une fois les premières expositions maîtrisées, tu peux affiner la durée, la fréquence et le moment de la journée selon l'effet recherché : stimulation ou relaxation.",
        },
        {
          kind: "image",
          image: "stress-coldheat",
          caption: "La régularité compte plus que l'intensité d'une seule séance.",
        },
        {
          kind: "list",
          title: "Effets rapportés",
          items: [
            "Sensation d'alerte et d'énergie après le froid",
            "Détente musculaire après la chaleur",
            "Amélioration progressive de la tolérance au stress",
          ],
        },
        {
          kind: "myth",
          myth: "Le froid brûle énormément de graisse.",
          truth: "L'effet sur la dépense calorique existe mais reste marginal comparé à l'alimentation et l'activité physique globale.",
        },
        {
          kind: "compare",
          title: "Froid vs chaud",
          left: { label: "Froid (douche, bain)", items: ["Effet stimulant", "Vigilance accrue", "À éviter juste avant de dormir"] },
          right: { label: "Chaud (sauna, bain chaud)", items: ["Effet relaxant", "Favorise l'endormissement", "Attention à l'hydratation"] },
        },
        {
          kind: "steps",
          title: "Progresser en sécurité",
          items: [
            "Augmente la durée du froid de quelques secondes chaque semaine",
            "Alterne éventuellement chaud puis froid en fin de séance sportive",
            "Reste toujours à l'écoute de tes sensations",
          ],
        },
        {
          kind: "warn",
          title: "Précautions",
          body: "Les expositions extrêmes au froid ou à la chaleur comportent des risques cardiovasculaires. Demande un avis médical en cas d'antécédent.",
        },
        {
          kind: "checklist",
          title: "À essayer",
          items: [
            "J'augmente légèrement la durée de ma douche froide",
            "Je note comment je me sens après",
          ],
        },
        {
          kind: "quiz",
          question: "Quel effet est plutôt associé à l'exposition au froid ?",
          options: ["Endormissement immédiat", "Effet stimulant et vigilance", "Perte de poids majeure", "Aucun effet"],
          answer: 1,
          explanation: "Le froid a un effet plutôt stimulant, à privilégier en dehors des heures proches du coucher.",
        },
        {
          kind: "sources",
          items: [
            { label: "NHS", url: "https://www.nhs.uk/" },
            { label: "Examine.com – Cold exposure", url: "https://examine.com/" },
          ],
        },
      ],
    },
    {
      id: "stress-11",
      title: "Écrans et stress : le lien sous-estimé",
      summary: "Notifications, scroll infini : comment ils entretiennent l'alerte.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "stress-screens",
      blocks: [
        {
          kind: "text",
          title: "Une sollicitation continue du système d'alerte",
          body: "Chaque notification, chaque scroll déclenche une micro-réponse d'attention. Répétée des centaines de fois par jour, cette sollicitation maintient le système nerveux en état de vigilance légère, sans jamais vraiment relâcher.",
        },
        {
          kind: "image",
          image: "stress-screens",
          caption: "Le scroll infini est conçu pour capter l'attention en continu.",
        },
        {
          kind: "stat",
          value: "> 90 fois/jour",
          label: "Fréquence moyenne de consultation du téléphone chez certains utilisateurs",
          body: "Ce chiffre varie fortement selon les études et les usages, mais illustre l'ampleur des interruptions potentielles.",
        },
        {
          kind: "myth",
          myth: "Regarder son téléphone entre deux tâches, ça détend.",
          truth: "Ça donne une impression de pause, mais ça maintient l'attention sollicitée et retarde souvent le vrai repos mental.",
        },
        {
          kind: "list",
          title: "Effets rapportés d'un usage intensif",
          items: [
            "Difficulté à s'ennuyer ou à ne rien faire",
            "Sommeil retardé par la lumière et le contenu stimulant",
            "Comparaison sociale accrue sur les réseaux",
          ],
        },
        {
          kind: "compare",
          title: "Usage réfléchi vs usage compulsif",
          left: { label: "Usage réfléchi", items: ["Plages définies", "Notifications limitées", "Objectif clair avant d'ouvrir l'app"] },
          right: { label: "Usage compulsif", items: ["Déverrouillage automatique", "Scroll sans but", "Sensation de vide après"] },
        },
        {
          kind: "steps",
          title: "Reprendre la main",
          items: [
            "Désactive les notifications non essentielles",
            "Mets ton téléphone hors de vue pendant le travail concentré",
            "Fixe une heure de coupure le soir",
          ],
        },
        {
          kind: "warn",
          title: "Pas de diabolisation totale",
          body: "Les écrans ne sont pas l'ennemi en soi ; c'est la fréquence de sollicitation involontaire qui pose problème pour le stress.",
        },
        {
          kind: "drill",
          title: "Journée test",
          body: "Désactive toutes les notifications non essentielles pendant 24h et observe ton niveau de calme.",
          duration: "24h",
        },
        {
          kind: "quiz",
          question: "Pourquoi le scroll infini entretient-il le stress ?",
          options: ["Il repose totalement le cerveau", "Il sollicite l'attention en continu sans vrai relâchement", "Il n'a aucun effet mesurable", "Il améliore le sommeil"],
          answer: 1,
          explanation: "La sollicitation répétée de l'attention empêche le système nerveux de vraiment relâcher la vigilance.",
        },
        {
          kind: "quiz",
          question: "Quelle est une bonne pratique pour limiter cet effet ?",
          options: ["Garder toutes les notifications actives", "Définir des plages sans téléphone", "Vérifier le téléphone dès le réveil", "Scroller avant de dormir"],
          answer: 1,
          explanation: "Des plages définies sans sollicitation permettent au système nerveux de se relâcher réellement.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Technology and stress", url: "https://www.apa.org/" },
            { label: "Sleep Foundation", url: "https://www.sleepfoundation.org/" },
          ],
        },
      ],
    },
    {
      id: "stress-12",
      title: "Anxiété sociale : la comprendre pour la désamorcer",
      summary: "Pourquoi certaines interactions te coûtent tant d'énergie.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "stress-social",
      blocks: [
        {
          kind: "text",
          title: "Une peur du jugement, pas une faiblesse",
          body: "L'anxiété sociale vient d'une peur excessive du jugement ou du rejet par les autres. Elle touche à des degrés divers une grande partie de la population, souvent sans que ça se voie de l'extérieur.",
        },
        {
          kind: "image",
          image: "stress-social",
          caption: "La peur du regard des autres est universelle, seule son intensité varie.",
        },
        {
          kind: "list",
          title: "Manifestations fréquentes",
          items: [
            "Répétition mentale des conversations passées",
            "Évitement de prendre la parole en groupe",
            "Sensation physique de tension avant une interaction",
            "Peur de rougir, trembler ou bafouiller",
          ],
        },
        {
          kind: "myth",
          myth: "Il suffit de 'se lancer' pour que ça passe.",
          truth: "L'exposition progressive fonctionne mieux qu'un saut brutal dans le grand bain, qui peut renforcer l'évitement en cas d'échec ressenti.",
        },
        {
          kind: "compare",
          title: "Évitement vs exposition progressive",
          left: { label: "Évitement", items: ["Soulagement immédiat", "Renforce la peur à long terme", "Réduit les occasions de progrès"] },
          right: { label: "Exposition progressive", items: ["Inconfort passager", "Réduit la peur avec la répétition", "Construit la confiance réelle"] },
        },
        {
          kind: "steps",
          title: "S'exposer par étapes",
          items: [
            "Commence par de petites interactions à faible enjeu",
            "Note ce qui s'est réellement passé, pas ce que tu redoutais",
            "Augmente progressivement la difficulté",
          ],
        },
        {
          kind: "drill",
          title: "Micro-exposition",
          body: "Engage une conversation courte avec un inconnu (vendeur, livreur, voisin) aujourd'hui.",
          duration: "5 min",
        },
        {
          kind: "warn",
          title: "Quand consulter",
          body: "Si l'anxiété sociale limite fortement ta vie quotidienne ou professionnelle, un accompagnement par un professionnel de santé mentale est recommandé.",
        },
        {
          kind: "checklist",
          title: "Cette semaine",
          items: [
            "J'ai fait une micro-exposition sociale",
            "J'ai comparé ce qui s'est passé à ce que je redoutais",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle stratégie est la plus efficace face à l'anxiété sociale ?",
          options: ["L'évitement total", "L'exposition progressive", "Se forcer d'un coup au pire scénario", "Ignorer le problème"],
          answer: 1,
          explanation: "L'exposition progressive permet de réduire la peur de façon durable, contrairement à l'évitement.",
        },
        {
          kind: "quiz",
          question: "Que renforce l'évitement à long terme ?",
          options: ["La confiance en soi", "La peur elle-même", "Les compétences sociales", "Rien de particulier"],
          answer: 1,
          explanation: "Éviter une situation redoutée soulage sur le moment mais entretient la peur pour la fois suivante.",
        },
        {
          kind: "sources",
          items: [
            { label: "APA – Social anxiety", url: "https://www.apa.org/" },
            { label: "NHS – Social anxiety", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "stress-13",
      title: "Surentraînement : les signaux à ne pas rater",
      summary: "Aller plus loin, sans se retrouver à zéro.",
      difficulty: "hard",
      minutes: 12,
      xp: 200,
      tier: "pro",
      requiresLevel: 4,
      cover: "stress-overtraining",
      blocks: [
        {
          kind: "text",
          title: "Quand l'entraînement devient une charge de trop",
          body: "Le surentraînement survient quand le volume et l'intensité dépassent durablement la capacité de récupération. Combiné à un stress de vie déjà élevé, le risque augmente nettement.",
        },
        {
          kind: "image",
          image: "stress-overtraining",
          caption: "La performance qui stagne ou régresse malgré l'effort est un signal clé.",
        },
        {
          kind: "stat",
          value: "Plusieurs semaines",
          label: "Temps de récupération possible en cas de surentraînement avéré",
          body: "Contrairement à une simple fatigue passagère qui se résorbe en quelques jours de repos.",
        },
        {
          kind: "list",
          title: "Signaux d'alerte principaux",
          items: [
            "Performance qui stagne ou régresse malgré l'entraînement",
            "Fréquence cardiaque au repos anormalement élevée",
            "Sommeil perturbé malgré la fatigue physique",
            "Motivation qui s'effondre pour une activité auparavant appréciée",
            "Blessures ou douleurs qui se répètent",
          ],
        },
        {
          kind: "myth",
          myth: "Plus on s'entraîne, plus on progresse, sans exception.",
          truth: "Passé un certain seuil, l'ajout de volume sans récupération suffisante fait stagner voire régresser la performance.",
        },
        {
          kind: "compare",
          title: "Fatigue normale vs surentraînement",
          left: { label: "Fatigue normale", items: ["Récupère en 1 à 3 jours", "Performance qui repart", "Motivation qui revient vite"] },
          right: { label: "Surentraînement", items: ["Fatigue qui persiste des semaines", "Performance qui régresse", "Perte de motivation durable"] },
        },
        {
          kind: "steps",
          title: "Réagir face aux signaux",
          items: [
            "Réduis le volume d'entraînement de 40 à 50 % temporairement",
            "Priorise le sommeil et l'alimentation pendant cette phase",
            "Réintroduis l'intensité progressivement, pas d'un coup",
          ],
        },
        {
          kind: "warn",
          title: "Ne pas confondre avec un simple manque de motivation",
          body: "Si les signaux physiques (sommeil, fréquence cardiaque, blessures répétées) s'accumulent, ce n'est pas qu'une question mentale : il faut ajuster la charge réelle.",
        },
        {
          kind: "checklist",
          title: "Auto-évaluation",
          items: [
            "Ma performance stagne ou régresse depuis plusieurs semaines",
            "Mon sommeil est perturbé malgré la fatigue",
            "J'ai des douleurs ou blessures qui reviennent",
          ],
        },
        {
          kind: "quiz",
          question: "Quel est un signal clé de surentraînement ?",
          options: ["Une progression rapide et stable", "Une performance qui stagne ou régresse durablement", "Une bonne humeur constante", "Un sommeil profond et réparateur"],
          answer: 1,
          explanation: "La stagnation ou régression de performance malgré l'entraînement est un signal central du surentraînement.",
        },
        {
          kind: "quiz",
          question: "Quelle est une réponse adaptée face à des signaux de surentraînement ?",
          options: ["Augmenter encore le volume", "Réduire temporairement la charge et prioriser la récupération", "Ignorer les douleurs", "Changer uniquement l'alimentation"],
          answer: 1,
          explanation: "Réduire la charge et prioriser sommeil et récupération permet de sortir du surentraînement.",
        },
        {
          kind: "sources",
          items: [
            { label: "NHS – Overtraining", url: "https://www.nhs.uk/" },
            { label: "NCBI", url: "https://www.ncbi.nlm.nih.gov/" },
          ],
        },
      ],
    },
  ],
};
