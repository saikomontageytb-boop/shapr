import type { Track } from "@/lib/academy-types";

export const beard: Track = {
  id: "beard",
  title: "Barbe & rasage",
  tagline: "Une barbe nette ou un rasage propre, sans irritation.",
  intro:
    "Choisir la bonne forme, éviter les poils incarnés, entretenir sans y passer des heures. Le concret, pas le marketing.",
  icon: "scissors",
  cover: "beard-cover",
  lessons: [
    {
      id: "beard-1",
      title: "Choisir sa barbe selon son visage",
      summary: "La forme qui équilibre vraiment tes traits.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "beard-face-shape",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi la forme du visage compte",
          body: "Une barbe bien taillée peut équilibrer visuellement un visage : allonger un visage rond, adoucir une mâchoire carrée, structurer un visage long.",
        },
        {
          kind: "image",
          image: "beard-face-shape",
          caption: "Identifier son visage : rond, carré, ovale, long, en cœur.",
        },
        {
          kind: "list",
          title: "Repères par forme de visage",
          items: [
            "Visage rond : privilégie une barbe plus courte sur les côtés, plus fournie au menton",
            "Visage carré : arrondis les angles avec une barbe modérée",
            "Visage long : garde les côtés plus fournis, le menton plus court",
            "Visage ovale : presque toutes les formes fonctionnent",
          ],
        },
        {
          kind: "steps",
          title: "Trouver sa forme en 3 étapes",
          items: [
            "Attache tes cheveux en arrière face à un miroir",
            "Observe la largeur du front, des pommettes et de la mâchoire",
            "Compare la longueur du visage à sa largeur",
          ],
        },
        {
          kind: "myth",
          myth: "Une barbe fournie cache forcément un double menton.",
          truth: "Mal taillée, elle peut au contraire l'accentuer. Une ligne de cou bien définie fait plus de différence que la densité seule.",
        },
        {
          kind: "compare",
          title: "Barbe adaptée vs barbe subie",
          left: { label: "Adaptée", items: ["Ligne de cou nette", "Densité travaillée aux zones creuses", "Longueur cohérente avec le visage"] },
          right: { label: "Subie", items: ["Pousse au hasard", "Ligne de cou floue", "Aucune retouche depuis des semaines"] },
        },
        {
          kind: "stat",
          value: "3-4 semaines",
          label: "Temps pour juger vraiment une nouvelle forme",
          body: "Le temps que la densité se stabilise avant de trancher si une forme te va.",
        },
        {
          kind: "checklist",
          title: "Avant de choisir",
          items: [
            "Je connais la forme de mon visage",
            "J'ai regardé des exemples proches de ma morphologie",
            "Je vise une ligne de cou nette",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle forme de visage bénéficie le plus d'une barbe qui arrondit les angles ?",
          options: ["Visage ovale", "Visage carré", "Visage en cœur", "Visage rond"],
          answer: 1,
          explanation: "Une barbe modérée qui adoucit les angles marqués équilibre un visage carré.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD – Soins du visage masculin", url: "https://www.aad.org/" },
          ],
        },
      ],
    },
    {
      id: "beard-2",
      title: "Rasage sans irritation",
      summary: "La méthode qui évite les rougeurs et brûlures.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "free",
      cover: "beard-shaving",
      blocks: [
        {
          kind: "text",
          title: "Pourquoi ça brûle",
          body: "L'irritation vient presque toujours d'une peau mal préparée, d'une lame usée ou d'une pression trop forte, pas d'un problème de peau en soi.",
        },
        {
          kind: "image",
          image: "beard-shaving",
          caption: "Peau chaude et hydratée avant de commencer.",
        },
        {
          kind: "steps",
          title: "Le rasage en 5 étapes",
          items: [
            "Rase-toi après la douche, quand les poils sont ramollis",
            "Applique une mousse ou un gel, pas juste du savon",
            "Rase dans le sens du poil en premier passage",
            "Rince la lame souvent, change-la toutes les 5-7 utilisations",
            "Termine par une eau froide et un baume sans alcool",
          ],
        },
        {
          kind: "myth",
          myth: "Appuyer plus fort rase plus près.",
          truth: "Ça augmente surtout le risque de coupures et d'irritation. Laisse la lame faire le travail.",
        },
        {
          kind: "list",
          title: "Erreurs fréquentes",
          items: [
            "Se raser à sec",
            "Utiliser une lame émoussée",
            "Raser à contre-poil dès le premier passage",
            "Appliquer de l'alcool sur une peau fraîchement rasée",
          ],
        },
        {
          kind: "compare",
          title: "Bon rasage vs mauvais rasage",
          left: { label: "Bon rasage", items: ["Peau préparée", "Lame propre et récente", "Passage dans le sens du poil"] },
          right: { label: "Mauvais rasage", items: ["Peau sèche", "Lame usée", "Pression excessive"] },
        },
        {
          kind: "warn",
          title: "Peau sensible",
          body: "En cas de rougeurs persistantes ou de boutons récurrents, espace les rasages plutôt que de forcer.",
        },
        {
          kind: "drill",
          title: "Test du sens du poil",
          body: "Passe ta main sur ta joue dans les deux sens pour repérer le sens de pousse avant de raser.",
          duration: "1 min",
        },
        {
          kind: "quiz",
          question: "Quand faut-il idéalement se raser ?",
          options: ["Au réveil, peau sèche", "Après la douche", "Juste avant de dormir", "Peu importe"],
          answer: 1,
          explanation: "La chaleur et l'humidité de la douche ramollissent le poil et réduisent l'irritation.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD – Rasage", url: "https://www.aad.org/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "beard-3",
      title: "Les outils indispensables",
      summary: "Le minimum d'équipement pour un résultat pro.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "beard-tools",
      blocks: [
        {
          kind: "text",
          title: "Moins d'outils, mais les bons",
          body: "Une bonne tondeuse, un peigne et un rasoir de précision couvrent la quasi-totalité des besoins d'entretien, quelle que soit la longueur visée.",
        },
        {
          kind: "image",
          image: "beard-tools",
          caption: "Une tondeuse avec sabots règle la longueur, un rasoir précise les contours.",
        },
        {
          kind: "list",
          title: "Le kit de base",
          items: [
            "Tondeuse avec plusieurs sabots",
            "Rasoir ou tondeuse de précision pour les contours",
            "Peigne à barbe",
            "Ciseaux fins pour les poils rebelles",
          ],
        },
        {
          kind: "steps",
          title: "Entretenir ses outils",
          items: [
            "Nettoie la lame après chaque usage",
            "Huile la tondeuse régulièrement",
            "Remplace la lame de rasoir dès qu'elle tire",
          ],
        },
        {
          kind: "myth",
          myth: "Une tondeuse chère rase forcément mieux.",
          truth: "Le prix reflète surtout la durabilité et le confort d'usage, pas la qualité de coupe pour un usage occasionnel.",
        },
        {
          kind: "compare",
          title: "Bon entretien vs négligence",
          left: { label: "Bon entretien", items: ["Lame nettoyée après usage", "Huilage régulier", "Remplacement à temps"] },
          right: { label: "Négligence", items: ["Lame encrassée", "Tondeuse qui tire", "Résultat irrégulier"] },
        },
        {
          kind: "checklist",
          title: "Mon kit est-il complet ?",
          items: [
            "J'ai une tondeuse fiable",
            "J'ai un outil de précision pour les contours",
            "Je nettoie mes outils après usage",
          ],
        },
        {
          kind: "quiz",
          question: "Que faut-il faire régulièrement avec une tondeuse ?",
          options: ["La laisser humide", "La nettoyer et l'huiler", "La ranger sans entretien", "La laver au lave-vaisselle"],
          answer: 1,
          explanation: "Un nettoyage et un huilage réguliers prolongent la durée de vie et la qualité de coupe.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD", url: "https://www.aad.org/" },
          ],
        },
      ],
    },
    {
      id: "beard-4",
      title: "Après-rasage : calmer la peau",
      summary: "Ce qui apaise vraiment, ce qui agresse.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "beard-aftershave",
      blocks: [
        {
          kind: "text",
          title: "La peau vient d'être agressée",
          body: "Juste après un rasage, la barrière cutanée est fragilisée. Le geste d'après-rasage compte autant que la technique de rasage elle-même.",
        },
        {
          kind: "image",
          image: "beard-aftershave",
          caption: "Un baume sans alcool referme les pores sans piquer.",
        },
        {
          kind: "steps",
          title: "Le bon réflexe post-rasage",
          items: [
            "Rince à l'eau froide pour resserrer les pores",
            "Tamponne, ne frotte pas",
            "Applique un baume ou une lotion sans alcool",
          ],
        },
        {
          kind: "myth",
          myth: "L'after-shave qui pique désinfecte mieux.",
          truth: "La sensation de brûlure vient souvent de l'alcool, qui assèche et irrite plus qu'il ne protège.",
        },
        {
          kind: "list",
          title: "Ingrédients apaisants à privilégier",
          items: ["Aloe vera", "Panthénol", "Glycérine", "Huiles végétales légères"],
        },
        {
          kind: "compare",
          title: "Apaisant vs agressif",
          left: { label: "Apaisant", items: ["Sans alcool", "Hydratant", "Sensation de confort"] },
          right: { label: "Agressif", items: ["Alcool fort", "Parfum intense", "Sensation de brûlure"] },
        },
        {
          kind: "warn",
          title: "Coupures",
          body: "Une petite coupure se nettoie à l'eau claire ; inutile d'y verser de l'alcool pur qui retarde plutôt la cicatrisation.",
        },
        {
          kind: "checklist",
          title: "Réflexe après chaque rasage",
          items: [
            "Eau froide",
            "Séchage en tamponnant",
            "Baume sans alcool",
          ],
        },
        {
          kind: "quiz",
          question: "Pourquoi éviter l'after-shave à base d'alcool fort ?",
          options: ["Il coûte trop cher", "Il assèche et irrite la peau", "Il sent mauvais", "Il n'existe pas de version sans alcool"],
          answer: 1,
          explanation: "L'alcool fort agresse une peau déjà fragilisée par le rasage.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD", url: "https://www.aad.org/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "beard-5",
      title: "Gérer une barbe clairsemée",
      summary: "Composer avec des zones moins fournies sans complexe.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "beard-patchy",
      blocks: [
        {
          kind: "text",
          title: "Une densité inégale est très fréquente",
          body: "Peu d'hommes ont une densité parfaitement uniforme. Adapter la coupe aux zones clairsemées donne un résultat propre sans attendre une densité irréaliste.",
        },
        {
          kind: "image",
          image: "beard-patchy",
          caption: "Une longueur plus courte uniformise l'apparence des zones creuses.",
        },
        {
          kind: "list",
          title: "Stratégies concrètes",
          items: [
            "Garder une longueur courte et homogène plutôt que longue et inégale",
            "Structurer avec une ligne de cou et de joue nette",
            "Laisser pousser 4 à 6 semaines avant de juger",
          ],
        },
        {
          kind: "myth",
          myth: "Une barbe clairsemée ne peut jamais avoir l'air soignée.",
          truth: "Une coupe courte et bien structurée rend une densité inégale beaucoup moins visible.",
        },
        {
          kind: "steps",
          title: "Adapter sa coupe",
          items: [
            "Identifie les zones les plus clairsemées",
            "Raccourcis légèrement l'ensemble pour uniformiser",
            "Renforce des contours nets pour structurer le regard",
          ],
        },
        {
          kind: "compare",
          title: "Approche efficace vs approche frustrante",
          left: { label: "Efficace", items: ["Longueur courte homogène", "Contours nets", "Patience réaliste"] },
          right: { label: "Frustrante", items: ["Laisser pousser sans plan", "Comparaison constante à d'autres barbes", "Produits miracle attendus"] },
        },
        {
          kind: "checklist",
          title: "Pour une barbe clairsemée bien gérée",
          items: [
            "Longueur adaptée à la densité réelle",
            "Contours nets et réguliers",
            "Attentes réalistes sur la densité",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle stratégie aide le plus une barbe clairsemée ?",
          options: ["Laisser pousser très long", "Une longueur courte et homogène", "Ne jamais tailler", "Changer de produit chaque semaine"],
          answer: 1,
          explanation: "Une longueur courte et uniforme atténue visuellement les zones moins denses.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD", url: "https://www.aad.org/" },
          ],
        },
      ],
    },
    {
      id: "beard-6",
      title: "Adapter sa barbe à son type de peau",
      summary: "Peau sèche, grasse ou sensible : ajuster sans se compliquer.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "beard-skin-type",
      blocks: [
        {
          kind: "text",
          title: "La peau sous la barbe reste de la peau",
          body: "Le type de peau influence les produits et la fréquence d'entretien, tout comme pour le visage rasé.",
        },
        {
          kind: "image",
          image: "beard-skin-type",
          caption: "Peau grasse, sèche, mixte ou sensible : chacune a ses ajustements.",
        },
        {
          kind: "list",
          title: "Ajustements par type de peau",
          items: [
            "Peau sèche : huile plus riche, lavage moins fréquent",
            "Peau grasse : nettoyant plus régulier, huile légère",
            "Peau sensible : produits sans parfum, test préalable",
            "Peau mixte : adapter zone par zone",
          ],
        },
        {
          kind: "steps",
          title: "Identifier son type de peau",
          items: [
            "Observe ta peau une heure après le nettoyage",
            "Zone qui brille = grasse, zone qui tiraille = sèche",
            "Ajuste tes produits en conséquence",
          ],
        },
        {
          kind: "myth",
          myth: "Une barbe protège forcément des problèmes de peau.",
          truth: "Elle peut au contraire piéger l'humidité et le sébum si l'entretien est négligé, favorisant boutons et irritations.",
        },
        {
          kind: "warn",
          title: "En cas de doute",
          body: "Une peau qui réagit fortement à plusieurs produits mérite un avis dermatologique plutôt que d'enchaîner les essais.",
        },
        {
          kind: "checklist",
          title: "Réflexes selon ta peau",
          items: [
            "J'ai identifié mon type de peau",
            "J'utilise des produits adaptés",
            "Je teste un nouveau produit sur une petite zone avant usage complet",
          ],
        },
        {
          kind: "quiz",
          question: "Que faire avant d'utiliser un nouveau produit sur peau sensible ?",
          options: ["L'appliquer partout directement", "Le tester sur une petite zone", "Attendre un an", "Rien, ce n'est jamais utile"],
          answer: 1,
          explanation: "Un test localisé permet de repérer une réaction avant une application complète.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD", url: "https://www.aad.org/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "beard-7",
      title: "Tailler les contours proprement",
      summary: "Une ligne de cou et de joue nette change tout.",
      difficulty: "base",
      minutes: 4,
      xp: 60,
      tier: "pro",
      cover: "beard-lineup",
      blocks: [
        {
          kind: "text",
          title: "Le détail qui distingue une barbe soignée",
          body: "Une barbe même longue paraît négligée sans une ligne de cou et de joue nette. C'est souvent ce détail, plus que la longueur, qui fait la différence visuelle.",
        },
        {
          kind: "image",
          image: "beard-lineup",
          caption: "La ligne de cou se trace juste au-dessus de la pomme d'Adam.",
        },
        {
          kind: "steps",
          title: "Tracer sa ligne de cou",
          items: [
            "Repère deux doigts au-dessus de la pomme d'Adam",
            "Trace une courbe douce d'une oreille à l'autre",
            "Rase tout ce qui est en dessous",
          ],
        },
        {
          kind: "list",
          title: "Outils utiles",
          items: [
            "Tondeuse avec sabots pour la longueur générale",
            "Rasoir ou tondeuse de précision pour les contours",
            "Peigne pour guider la coupe",
          ],
        },
        {
          kind: "myth",
          myth: "Il faut une ligne de joue très haute pour paraître soigné.",
          truth: "Une ligne de joue naturelle, légèrement nettoyée, paraît souvent plus propre qu'une ligne trop haute et artificielle.",
        },
        {
          kind: "compare",
          title: "Contours nets vs contours flous",
          left: { label: "Nets", items: ["Ligne de cou définie", "Joues nettoyées légèrement", "Symétrie vérifiée"] },
          right: { label: "Flous", items: ["Poils épars sur le cou", "Aucune retouche depuis longtemps", "Asymétrie visible"] },
        },
        {
          kind: "drill",
          title: "Retouche express",
          body: "Prends 5 minutes pour retracer ta ligne de cou avec une tondeuse de précision devant un bon éclairage.",
          duration: "5 min",
        },
        {
          kind: "checklist",
          title: "Avant de sortir",
          items: [
            "Ligne de cou nette",
            "Pas de poils épars visibles",
            "Symétrie vérifiée des deux côtés",
          ],
        },
        {
          kind: "quiz",
          question: "Où tracer la ligne de cou ?",
          options: ["Juste sous le menton", "Deux doigts au-dessus de la pomme d'Adam", "Au niveau des clavicules", "Peu importe"],
          answer: 1,
          explanation: "Ce repère évite une barbe qui remonte trop haut sur le cou.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD", url: "https://www.aad.org/" },
          ],
        },
      ],
    },
    {
      id: "beard-8",
      title: "Poils incarnés : comprendre et éviter",
      summary: "Pourquoi ils apparaissent et comment les prévenir vraiment.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "beard-ingrown",
      blocks: [
        {
          kind: "text",
          title: "Ce qui se passe sous la peau",
          body: "Un poil incarné se recourbe et repousse sous la peau au lieu de sortir, provoquant une inflammation locale. C'est plus fréquent avec les poils bouclés et un rasage trop court.",
        },
        {
          kind: "image",
          image: "beard-ingrown",
          caption: "Zone du cou : la plus exposée aux poils incarnés.",
        },
        {
          kind: "stat",
          value: "1 sur 5",
          label: "Part des hommes qui rasent touchée régulièrement",
          body: "Un phénomène courant, surtout chez les hommes à poils épais ou bouclés.",
        },
        {
          kind: "list",
          title: "Facteurs qui favorisent les poils incarnés",
          items: [
            "Rasage trop ras ou à contre-poil",
            "Peau morte accumulée qui bloque le pore",
            "Lame usée qui arrache plutôt que coupe net",
            "Frottement de vêtements ou de cols serrés",
          ],
        },
        {
          kind: "myth",
          myth: "Il faut percer un poil incarné avec une aiguille.",
          truth: "Ça augmente le risque d'infection et de cicatrice. Un gommage doux et de la patience suffisent dans la majorité des cas.",
        },
        {
          kind: "steps",
          title: "Prévenir efficacement",
          items: [
            "Exfolie doucement 1 à 2 fois par semaine",
            "Rase dans le sens du poil, pas à ras",
            "Change de lame régulièrement",
            "Hydrate après chaque rasage",
          ],
        },
        {
          kind: "compare",
          title: "Réaction utile vs réaction à éviter",
          left: { label: "Utile", items: ["Gommage doux", "Compresse tiède", "Laisser le poil sortir seul"] },
          right: { label: "À éviter", items: ["Percer avec une aiguille sale", "Gratter avec les ongles", "Raser par-dessus la zone irritée"] },
        },
        {
          kind: "warn",
          title: "Quand consulter",
          body: "Si la zone devient très douloureuse, gonflée ou purulente, un avis médical vaut mieux qu'un forum.",
        },
        {
          kind: "checklist",
          title: "Routine anti-incarnés",
          items: [
            "J'exfolie une à deux fois par semaine",
            "Je change de lame régulièrement",
            "Je rase dans le sens du poil sur les zones sensibles",
          ],
        },
        {
          kind: "quiz",
          question: "Quelle est la cause la plus fréquente des poils incarnés ?",
          options: ["Trop d'hydratation", "Rasage trop ras ou à contre-poil", "Manque de vitamine C", "Eau trop froide"],
          answer: 1,
          explanation: "Un rasage trop court ou à contre-poil favorise la repousse sous la peau.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD – Poils incarnés", url: "https://www.aad.org/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
    {
      id: "beard-9",
      title: "Entretenir sa barbe au quotidien",
      summary: "La routine minimale qui fait la vraie différence.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "beard-maintenance",
      blocks: [
        {
          kind: "text",
          title: "Une barbe, ça se lave et ça se peigne",
          body: "Sous les poils, la peau accumule sébum, poussière et peaux mortes comme n'importe quelle autre zone du corps. L'ignorer donne une barbe terne et parfois irritée.",
        },
        {
          kind: "image",
          image: "beard-maintenance",
          caption: "Peigner sa barbe démêle et répartit l'huile naturelle.",
        },
        {
          kind: "steps",
          title: "Routine de base",
          items: [
            "Lave ta barbe 2 à 3 fois par semaine avec un shampoing doux",
            "Sèche en tapotant, jamais en frottant fort",
            "Peigne quotidiennement pour démêler et dresser les poils",
            "Applique une huile ou un baume sur barbe humide",
          ],
        },
        {
          kind: "list",
          title: "Ce que l'huile à barbe apporte réellement",
          items: [
            "Assouplit le poil",
            "Réduit les démangeaisons des premières semaines",
            "Nourrit la peau en dessous",
          ],
        },
        {
          kind: "myth",
          myth: "Il faut laver sa barbe tous les jours comme les cheveux.",
          truth: "Un lavage trop fréquent assèche la peau sous la barbe. 2 à 3 fois par semaine suffit pour la plupart.",
        },
        {
          kind: "compare",
          title: "Barbe entretenue vs barbe négligée",
          left: { label: "Entretenue", items: ["Douce au toucher", "Peau saine dessous", "Forme régulière"] },
          right: { label: "Négligée", items: ["Sèche et cassante", "Démangeaisons fréquentes", "Contour flou"] },
        },
        {
          kind: "drill",
          title: "Séance d'entretien",
          body: "Ce soir : lave, sèche en tapotant, peigne et applique une huile légère.",
          duration: "5 min",
        },
        {
          kind: "checklist",
          title: "Routine hebdomadaire",
          items: [
            "2-3 lavages doux",
            "Peignage quotidien",
            "Taille des contours une fois par semaine",
          ],
        },
        {
          kind: "quiz",
          question: "À quelle fréquence laver sa barbe idéalement ?",
          options: ["Tous les jours", "2 à 3 fois par semaine", "Une fois par mois", "Jamais"],
          answer: 1,
          explanation: "Un lavage doux 2 à 3 fois par semaine évite d'assécher la peau tout en gardant la barbe propre.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD – Soins de la barbe", url: "https://www.aad.org/" },
          ],
        },
      ],
    },
    {
      id: "beard-10",
      title: "Rasoir manuel vs tondeuse électrique",
      summary: "Choisir le bon outil selon l'usage.",
      difficulty: "medium",
      minutes: 7,
      xp: 100,
      tier: "pro",
      cover: "beard-electric",
      blocks: [
        {
          kind: "text",
          title: "Deux logiques différentes",
          body: "Le rasoir manuel coupe très près de la peau, la tondeuse électrique privilégie la rapidité et réduit le risque de coupures et d'irritation.",
        },
        {
          kind: "image",
          image: "beard-electric",
          caption: "Le bon choix dépend de ta peau et du temps que tu veux y consacrer.",
        },
        {
          kind: "compare",
          title: "Manuel vs électrique",
          left: { label: "Rasoir manuel", items: ["Résultat très net", "Plus de risque d'irritation", "Nécessite plus de préparation"] },
          right: { label: "Tondeuse électrique", items: ["Plus rapide", "Moins irritant", "Résultat légèrement moins ras"] },
        },
        {
          kind: "list",
          title: "Quand préférer chaque outil",
          items: [
            "Rasoir manuel : occasion, peau tolérante, envie d'un rasage impeccable",
            "Électrique : quotidien, peau sensible, gain de temps",
          ],
        },
        {
          kind: "myth",
          myth: "Le rasage électrique est toujours moins efficace.",
          truth: "Les tondeuses modernes offrent un résultat proche du rasoir manuel pour beaucoup d'hommes, avec moins d'irritation.",
        },
        {
          kind: "steps",
          title: "Bien utiliser une tondeuse électrique",
          items: [
            "Utilise-la sur peau sèche, contrairement au rasoir manuel",
            "Passe dans plusieurs directions pour un résultat homogène",
            "Nettoie la tête après chaque usage",
          ],
        },
        {
          kind: "warn",
          title: "Peau très sensible",
          body: "Si les irritations persistent avec un rasoir manuel malgré une bonne technique, l'électrique est souvent la meilleure option à essayer.",
        },
        {
          kind: "checklist",
          title: "Choisir son outil",
          items: [
            "J'ai identifié ma sensibilité de peau",
            "J'ai choisi l'outil adapté à ma fréquence de rasage",
            "J'entretiens mon outil régulièrement",
          ],
        },
        {
          kind: "quiz",
          question: "Sur quel type de peau utilise-t-on une tondeuse électrique ?",
          options: ["Peau humide et savonnée", "Peau sèche", "Peau mouillée seulement", "Peu importe"],
          answer: 1,
          explanation: "Contrairement au rasoir manuel, la tondeuse électrique s'utilise sur peau sèche.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD", url: "https://www.aad.org/" },
          ],
        },
      ],
    },
    {
      id: "beard-11",
      title: "Densité de barbe : ce qui joue vraiment",
      summary: "Génétique, hormones, patience : démêler le vrai du faux.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "beard-density",
      blocks: [
        {
          kind: "text",
          title: "D'où vient la densité de barbe",
          body: "La densité et la vitesse de pousse dépendent principalement de la génétique et de la sensibilité des follicules à la DHT (un dérivé de la testostérone), pas seulement du taux d'hormones circulantes.",
        },
        {
          kind: "image",
          image: "beard-density",
          caption: "La répartition de la densité varie fortement d'un homme à l'autre, même en bonne santé.",
        },
        {
          kind: "stat",
          value: "Plusieurs mois",
          label: "Temps nécessaire pour juger le potentiel réel d'une barbe",
          body: "Les zones clairsemées peuvent se densifier lentement avec le temps, notamment jusqu'à la mi-vingtaine.",
        },
        {
          kind: "myth",
          myth: "Se raser souvent fait pousser une barbe plus dense.",
          truth: "Le rasage ne modifie ni le nombre de follicules ni la vitesse de pousse. L'impression de repousse plus épaisse vient juste de la coupe nette du poil.",
        },
        {
          kind: "list",
          title: "Facteurs qui influencent réellement la densité",
          items: [
            "Génétique familiale",
            "Âge (la densité maximale arrive souvent après 25-30 ans)",
            "Sensibilité individuelle aux androgènes",
            "Santé générale et sommeil, dans une moindre mesure",
          ],
        },
        {
          kind: "compare",
          title: "Facteurs solides vs promesses marketing",
          left: { label: "Facteurs solides", items: ["Génétique", "Âge", "Patience sur plusieurs mois"] },
          right: { label: "Promesses marketing", items: ["Compléments 'booster de barbe'", "Rasage fréquent", "Massages miracles"] },
        },
        {
          kind: "warn",
          title: "Perte de barbe inhabituelle",
          body: "Des zones qui se dégarnissent soudainement, avec des plaques, méritent un avis médical plutôt qu'une solution en ligne.",
        },
        {
          kind: "drill",
          title: "Suivi photo",
          body: "Prends une photo de face tous les mois pendant 3 mois pour juger objectivement l'évolution, sans te fier à l'impression du miroir quotidien.",
          duration: "2 min/mois",
        },
        {
          kind: "quiz",
          question: "Le rasage fréquent rend-il la barbe plus dense ?",
          options: ["Oui, toujours", "Non, ça ne change pas le nombre de follicules", "Seulement chez les jeunes", "Seulement avec un rasoir électrique"],
          answer: 1,
          explanation: "Le nombre de follicules est fixé génétiquement ; le rasage ne l'augmente pas.",
        },
        {
          kind: "quiz",
          question: "Quel facteur influence le plus la densité de barbe ?",
          options: ["La fréquence de rasage", "La génétique", "Les compléments alimentaires", "Le climat"],
          answer: 1,
          explanation: "La génétique et la sensibilité des follicules aux androgènes déterminent l'essentiel de la densité.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD – Croissance des poils", url: "https://www.aad.org/" },
            { label: "NCBI", url: "https://www.ncbi.nlm.nih.gov/" },
          ],
        },
      ],
    },
    {
      id: "beard-12",
      title: "Produits utiles vs marketing",
      summary: "Ce qui a un vrai effet, ce qui ne sert qu'à vendre.",
      difficulty: "hard",
      minutes: 11,
      xp: 160,
      tier: "pro",
      cover: "beard-products",
      blocks: [
        {
          kind: "text",
          title: "Le rayon barbe est saturé de promesses",
          body: "Entre huiles, baumes, sérums de croissance et kits 'tout-en-un', peu de produits ont un intérêt réellement démontré au-delà du confort et de l'hydratation.",
        },
        {
          kind: "image",
          image: "beard-products",
          caption: "Une routine simple bat presque toujours un kit à dix étapes.",
        },
        {
          kind: "compare",
          title: "Utile vs marketing",
          left: { label: "Utile", items: ["Huile hydratante simple", "Shampoing doux sans sulfate agressif", "Ciseaux/tondeuse de qualité"] },
          right: { label: "Marketing", items: ["Sérums 'accélérateurs de pousse' sans preuve", "Kits à 15 produits", "Parfums forts qui irritent"] },
        },
        {
          kind: "myth",
          myth: "Un baume 'croissance accélérée' fait pousser la barbe plus vite.",
          truth: "Aucune huile ou baume cosmétique n'a démontré d'effet sur la vitesse de pousse ; ils hydratent et assouplissent, c'est tout.",
        },
        {
          kind: "list",
          title: "Ce qu'il faut vraiment regarder sur l'étiquette",
          items: [
            "Liste d'ingrédients courte et compréhensible",
            "Absence de parfum agressif si peau sensible",
            "Huiles de base connues (jojoba, argan) plutôt que mélanges obscurs",
          ],
        },
        {
          kind: "stat",
          value: "3 produits",
          label: "Suffisent pour une routine complète",
          body: "Nettoyant doux, huile ou baume, et une bonne tondeuse ou des ciseaux couvrent l'essentiel des besoins.",
        },
        {
          kind: "steps",
          title: "Construire une routine minimale",
          items: [
            "Choisis un nettoyant doux adapté à ta peau",
            "Ajoute une huile ou un baume simple",
            "Investis dans un bon outil de coupe plutôt que dans plus de produits",
          ],
        },
        {
          kind: "warn",
          title: "Attention aux allergies",
          body: "Les parfums et huiles essentielles concentrées peuvent irriter une peau sensible sous la barbe ; teste sur une petite zone avant usage complet.",
        },
        {
          kind: "checklist",
          title: "Avant d'acheter un produit",
          items: [
            "Je vérifie la liste d'ingrédients",
            "Je me méfie des promesses de croissance",
            "Je privilégie la simplicité à la quantité",
          ],
        },
        {
          kind: "quiz",
          question: "Que fait réellement une huile à barbe ?",
          options: ["Accélère la pousse", "Change la couleur du poil", "Hydrate et assouplit", "Élimine les poils incarnés définitivement"],
          answer: 2,
          explanation: "Son rôle prouvé se limite à l'hydratation et à l'assouplissement du poil et de la peau.",
        },
        {
          kind: "quiz",
          question: "Combien de produits suffisent généralement pour une routine efficace ?",
          options: ["1", "3", "10", "15"],
          answer: 1,
          explanation: "Nettoyant doux, huile/baume et un bon outil de coupe couvrent l'essentiel.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD – Soins de la peau et du poil", url: "https://www.aad.org/" },
            { label: "Examine.com", url: "https://examine.com/" },
          ],
        },
      ],
    },
    {
      id: "beard-13",
      title: "Bonus : construire sa routine barbe sur mesure",
      summary: "Synthèse pour bâtir un protocole adapté à ton profil.",
      difficulty: "hard",
      minutes: 12,
      xp: 200,
      tier: "pro",
      requiresLevel: 4,
      cover: "beard-routine",
      blocks: [
        {
          kind: "text",
          title: "Assembler ce que tu sais déjà",
          body: "Forme de visage, type de peau, densité et objectifs personnels se combinent pour définir une routine réellement adaptée, plutôt qu'une routine copiée sur un influenceur.",
        },
        {
          kind: "image",
          image: "beard-routine",
          caption: "Une routine sur mesure prend 10 minutes par jour, pas plus.",
        },
        {
          kind: "steps",
          title: "Construire ta routine en 4 étapes",
          items: [
            "Détermine ta forme de visage et la longueur cible",
            "Identifie ton type de peau et choisis des produits simples adaptés",
            "Fixe une fréquence de lavage et de taille des contours",
            "Réévalue après 4 semaines et ajuste",
          ],
        },
        {
          kind: "list",
          title: "Check final avant de valider ta routine",
          items: [
            "Forme cohérente avec le visage",
            "Produits limités et adaptés à la peau",
            "Ligne de cou et de joue entretenues régulièrement",
            "Patience sur la densité, sans produit miracle",
          ],
        },
        {
          kind: "compare",
          title: "Routine sur mesure vs routine copiée",
          left: { label: "Sur mesure", items: ["Basée sur ton visage et ta peau", "Ajustée dans le temps", "Peu de produits, bien choisis"] },
          right: { label: "Copiée", items: ["Ignore ta morphologie", "Trop de produits", "Aucun ajustement"] },
        },
        {
          kind: "myth",
          myth: "La routine parfaite existe et est la même pour tous.",
          truth: "La meilleure routine est celle que tu tiens dans la durée et qui correspond à ta peau et ta pilosité.",
        },
        {
          kind: "warn",
          title: "Ne change pas tout d'un coup",
          body: "Introduis un changement à la fois (produit, longueur, fréquence) pour identifier ce qui fonctionne vraiment.",
        },
        {
          kind: "drill",
          title: "Plan sur 4 semaines",
          body: "Note ta routine actuelle, applique un seul changement cette semaine, et observe l'effet avant le suivant.",
          duration: "10 min",
        },
        {
          kind: "checklist",
          title: "Routine validée",
          items: [
            "Forme adaptée à mon visage",
            "Produits adaptés à ma peau",
            "Contours entretenus chaque semaine",
            "Un seul changement testé à la fois",
          ],
        },
        {
          kind: "quiz",
          question: "Comment tester un changement de routine efficacement ?",
          options: ["Tout changer en même temps", "Un seul changement à la fois", "Ne jamais rien changer", "Changer tous les jours"],
          answer: 1,
          explanation: "Isoler une variable permet de savoir ce qui a réellement un effet.",
        },
        {
          kind: "quiz",
          question: "Qu'est-ce qui définit la meilleure routine barbe ?",
          options: ["Le nombre de produits utilisés", "Ce qui est tenable dans la durée et adapté à sa peau", "Le prix des produits", "La routine d'un influenceur"],
          answer: 1,
          explanation: "La régularité et l'adaptation personnelle priment sur la quantité de produits ou les tendances.",
        },
        {
          kind: "sources",
          items: [
            { label: "AAD", url: "https://www.aad.org/" },
            { label: "NHS", url: "https://www.nhs.uk/" },
          ],
        },
      ],
    },
  ],
};
