import type { Track } from "@/lib/academy-types";

/**
 * English catalogue. Generated from the French content by
 * scripts/translate-academy.ts; empty until that has run, in which case the
 * app falls back to the French tracks.
 */
export const EN_TRACKS: Track[] = [];
