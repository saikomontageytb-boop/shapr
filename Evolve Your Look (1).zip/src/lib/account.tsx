import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./auth";
import { isFreeLesson, FREE_LESSON_COUNT } from "./free-lessons";
import type { AcademyState } from "./progress";
import { getArenaHub, type PlayerProgress } from "./arena.functions";
import { useServerFn } from "@tanstack/react-start";


/**
 * Everything the app knows about the signed-in member lives on the account:
 * the subscription flag, the free lessons they opened and the lessons they
 * finished. Nothing is kept on the device, so a refresh without a session is
 * always a signed-out, unpaid visitor.
 */

export const FREE_LESSONS = FREE_LESSON_COUNT;

const EMPTY_ACADEMY: AcademyState = { completedLessons: [], days: [], bonus: {} };
export const EMPTY_PLAYER_PROGRESS: PlayerProgress = { arenaXp: 0, runs: 0, bestScore: 0, dailyStreak: 0, dailyXp: 0, dailyPeriod: null, accountXp: 0, lastDailyDate: null, showOnLeaderboard: true, badges: [] };

export interface AccountValue {
  ready: boolean;
  pro: boolean;
  academy: AcademyState;
  arena: PlayerProgress;
  unlocked: string[];
  remaining: number;
  canOpen: (key: string) => boolean;
  unlock: (key: string) => Promise<void>;
  complete: (key: string, bonusXp: number) => Promise<void>;
  setPro: (on: boolean) => Promise<void>;
  refreshArena: () => Promise<PlayerProgress>;
}

const AccountContext = createContext<AccountValue>({
  ready: false,
  pro: false,
  academy: EMPTY_ACADEMY,
  arena: EMPTY_PLAYER_PROGRESS,
  unlocked: [],
  remaining: FREE_LESSONS,
  canOpen: () => false,
  unlock: async () => {},
  complete: async () => {},
  setPro: async () => {},
  refreshArena: async () => EMPTY_PLAYER_PROGRESS,
});

export function AccountProvider({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const userId = user?.id ?? null;

  const [ready, setReady] = useState(false);
  const [pro, setProState] = useState(false);
  const [unlocked, setUnlocked] = useState<string[]>([]);
  const [academy, setAcademy] = useState<AcademyState>(EMPTY_ACADEMY);
  const [arena, setArena] = useState<PlayerProgress>(EMPTY_PLAYER_PROGRESS);
  const fetchArena = useServerFn(getArenaHub);

  const refreshArena = useCallback(async () => {
    if (!userId) return EMPTY_PLAYER_PROGRESS;
    const next = await fetchArena();
    setArena(next);
    return next;
  }, [fetchArena, userId]);

  useEffect(() => {
    let cancelled = false;

    if (!userId) {
      setProState(false);
      setUnlocked([]);
      setAcademy(EMPTY_ACADEMY);
      setArena(EMPTY_PLAYER_PROGRESS);
      setReady(!loading);
      return;
    }

    void (async () => {
      const [profile, unlocks, completions, arenaProgress] = await Promise.all([
        supabase.from("profiles").select("is_pro").eq("id", userId).maybeSingle(),
        supabase.from("lesson_unlocks").select("lesson_key"),
        supabase.from("lesson_completions").select("lesson_key, bonus_xp, completed_on"),
        fetchArena().catch(() => EMPTY_PLAYER_PROGRESS),
      ]);
      if (cancelled) return;

      setProState(Boolean(profile.data?.is_pro));
      setUnlocked((unlocks.data ?? []).map((r) => r.lesson_key));

      const rows = completions.data ?? [];
      setAcademy({
        completedLessons: rows.map((r) => r.lesson_key),
        days: [...new Set(rows.map((r) => r.completed_on))],
        bonus: Object.fromEntries(rows.map((r) => [r.lesson_key, r.bonus_xp ?? 0])),
      });
      setArena(arenaProgress);
      setReady(true);
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, loading, fetchArena]);

  const canOpen = useCallback(
    (key: string) => pro || isFreeLesson(key),
    [pro],
  );


  const unlock = useCallback(
    async (key: string) => {
      if (!userId || unlocked.includes(key) || unlocked.length >= FREE_LESSONS) return;
      setUnlocked((list) => [...list, key]);
      await supabase.from("lesson_unlocks").insert({ user_id: userId, lesson_key: key });
    },
    [userId, unlocked],
  );

  const complete = useCallback(
    async (key: string, bonusXp: number) => {
      if (!userId) return;
      const day = new Date().toISOString().slice(0, 10);
      setAcademy((state) => ({
        completedLessons: [...new Set([...state.completedLessons, key])],
        days: [...new Set([...state.days, day])],
        bonus: { ...state.bonus, [key]: Math.max(state.bonus?.[key] ?? 0, bonusXp) },
      }));
      await supabase
        .from("lesson_completions")
        .upsert(
          { user_id: userId, lesson_key: key, bonus_xp: bonusXp, completed_on: day },
          { onConflict: "user_id,lesson_key" },
        );
    },
    [userId],
  );

  const setPro = useCallback(
    async (on: boolean) => {
      if (!userId) return;
      setProState(on);
      await supabase.from("profiles").update({ is_pro: on }).eq("id", userId);
    },
    [userId],
  );

  const value = useMemo<AccountValue>(
    () => ({
      ready,
      pro,
      academy,
      arena,
      unlocked,
      remaining: Math.max(0, FREE_LESSONS - unlocked.length),
      canOpen,
      unlock,
      complete,
      setPro,
      refreshArena,
    }),
    [ready, pro, academy, arena, unlocked, canOpen, unlock, complete, setPro, refreshArena],
  );

  return <AccountContext.Provider value={value}>{children}</AccountContext.Provider>;
}

export function useAccount(): AccountValue {
  return useContext(AccountContext);
}
