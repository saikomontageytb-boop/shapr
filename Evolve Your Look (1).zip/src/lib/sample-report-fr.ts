import type { Analysis } from "./analysis-schema";

/** French demo data for the public example report. */
export const SAMPLE_ANALYSIS_FR: Analysis = {
  overall_score: 6.4,
  potential_score: 7.5,
  percentile: 58,
  headline: "Base solide, présentation sous-optimisée",
  summary:
    "Tes traits sont équilibrés, mais ta coupe actuelle et ton grooming te desservent. Les gains les plus rapides : volume des cheveux, nettoyage des sourcils et routine skincare — rien de tout ça ne nécessite de changement structurel.",
  categories: [
    {
      key: "face_shape",
      score: 6.8,
      observation:
        "Ton visage est légèrement plus long que large, avec un tiers supérieur modérément étroit.",
      why_it_matters:
        "La forme du visage détermine les coupes de cheveux et les montures de lunettes qui te mettent en valeur.",
      recommendation:
        "Privilégie les coupes avec du volume sur les côtés et une hauteur maîtrisée sur le dessus ; évite les bananes hautes qui allongent encore le visage.",
      priority: "medium",
      fixed_trait: true,
    },
    {
      key: "symmetry",
      score: 7.0,
      observation:
        "Les côtés gauche et droit sont très alignés ; le sourcil droit est à peine plus haut.",
      why_it_matters: "Une légère asymétrie est normale et quasiment invisible en mouvement.",
      recommendation:
        "Rien à changer. En photo, ton profil trois-quarts gauche est ton meilleur angle.",
      priority: "low",
      fixed_trait: true,
    },
    {
      key: "jawline",
      score: 6.1,
      observation:
        "La ligne de mâchoire est visible mais adoucie le long du bas des joues et sous le menton.",
      why_it_matters: "La netteté de la mâchoire définit en grande partie la structure perçue du visage.",
      recommendation:
        "Baisse ton taux de masse grasse et réduis sel et alcool pour affûter la ligne en quelques mois. Une barbe courte dégradée le long de la mâchoire apporte une définition immédiate.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "eyes",
      score: 7.4,
      observation: "Tes yeux sont ton point fort : bon espacement, blanc net.",
      why_it_matters: "Le regard est ce qu'on regarde en premier en face-à-face et en photo.",
      recommendation:
        "Préserve-les : sommeil régulier et moins d'écrans tard le soir pour estomper les cernes visibles ici.",
      priority: "low",
      fixed_trait: true,
    },
    {
      key: "eyebrows",
      score: 5.6,
      observation:
        "Sourcils denses avec des poils épars au-dessus de l'arche et entre les sourcils.",
      why_it_matters: "Les sourcils encadrent le regard ; négligés, ils plombent une zone pourtant forte.",
      recommendation:
        "Un coup de pince de 10 minutes — l'espace intersourcilier et au-dessus de l'arche uniquement. Garde la ligne naturelle.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "nose",
      score: 6.5,
      observation: "Arête droite, largeur proportionnée à l'écartement des yeux.",
      why_it_matters: "Le nez ancre le centre du visage.",
      recommendation:
        "Aucun changement requis. Choisis des montures avec un pont légèrement plus haut pour ne pas le tasser.",
      priority: "low",
      fixed_trait: true,
    },
    {
      key: "skin",
      score: 6.0,
      observation:
        "Brillance visible sur le front et le nez, un peu de texture sur les joues.",
      why_it_matters: "La qualité de peau est le trait modifiable le plus visible.",
      recommendation:
        "Nettoyant doux matin et soir, crème hydratante légère, SPF 30+ quotidien. Tiens huit semaines. Consulte un dermato pour ce qui persiste.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "hair",
      score: 5.8,
      observation:
        "La coupe actuelle a une longueur uniforme et élargit le haut des tempes.",
      why_it_matters: "Les cheveux changent la perception globale du visage en un seul passage chez le coiffeur.",
      recommendation:
        "Demande des côtés plus courts et dégradés, garde du volume sur le dessus avec une frange texturée. Montre une photo, ne demande pas 'comme d'habitude'.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "facial_hair",
      score: 5.4,
      observation: "Barbe courte clairsemée sans ligne de cou définie.",
      why_it_matters: "Une ligne de cou propre fait la différence entre un style maîtrisé et un look négligé.",
      recommendation:
        "Garde une longueur de 3 à 5 mm, rase le cou à deux doigts au-dessus de la pomme d'Adam et nettoie le haut des joues.",
      priority: "medium",
      fixed_trait: false,
    },
    {
      key: "eyewear",
      score: 6.2,
      observation: "Montures actuelles trop étroites par rapport à la largeur de ton visage.",
      why_it_matters: "Les lunettes équilibrent le visage ou le rétrécissent.",
      recommendation:
        "Essaie des montures légèrement plus larges avec un pont droit ou en trou de serrure ; la monture doit s'aligner avec le bord extérieur du visage.",
      priority: "medium",
      fixed_trait: false,
    },
    {
      key: "style",
      score: 6.0,
      observation: "Le haut visible flotte au niveau des épaules et de l'encolure.",
      why_it_matters: "La coupe aux épaules se remarque avant la couleur, la marque ou le reste.",
      recommendation:
        "Construis ta garde-robe sur des basiques bien coupés dans des tons qui contrastent avec ta peau. La couture d'épaule doit tomber pile sur l'os.",
      priority: "medium",
      fixed_trait: false,
    },
    {
      key: "proportions",
      score: 6.6,
      observation: "Tiers du visage équilibrés, avec un tiers inférieur légèrement plus long.",
      why_it_matters: "Les proportions dictent le volume vertical qu'une coupe doit apporter.",
      recommendation:
        "Garde un volume capillaire modéré et évite les barbes épaisses qui allongent encore le menton.",
      priority: "low",
      fixed_trait: true,
    },
  ],
  priority_actions: [
    {
      title: "Changer de coupe de cheveux",
      category: "hair",
      impact: "high",
      why: "Ta coupe actuelle élargit le haut de la tête et aplatit le dessus.",
      action:
        "Prends rendez-vous chez le barbier cette semaine : demande un dégradé sur les côtés et garde du volume sur le dessus.",
    },
    {
      title: "Lancer une routine skincare",
      category: "skin",
      impact: "high",
      why: "Brillance et grain de peau sont les points modifiables les plus visibles sur ta photo.",
      action: "Nettoyant, hydratant, SPF. Même ordre, tous les jours, pendant huit semaines.",
    },
    {
      title: "Nettoyer sourcils et ligne de cou",
      category: "eyebrows",
      impact: "medium",
      why: "Deux contours nets rendent immédiatement tout le visage soigné.",
      action: "Épile les poils entre les sourcils et trace ta ligne de barbe dès ce soir.",
    },
  ],
  roadmap: [
    {
      level: 1,
      title: "FONDATIONS",
      focus: "Actions rapides, peu coûteuses et à fort impact.",
      quests: [
        {
          id: "haircut-upgrade",
          title: "Faire le dégradé adapté",
          category: "hair",
          difficulty: "easy",
          impact: "high",
          xp: 200,
        },
        {
          id: "skincare-start",
          title: "Mettre en place la routine en 3 étapes",
          category: "skin",
          difficulty: "easy",
          impact: "high",
          xp: 180,
        },
        {
          id: "brow-cleanup",
          title: "Épiler et nettoyer les sourcils",
          category: "eyebrows",
          difficulty: "easy",
          impact: "medium",
          xp: 120,
        },
        {
          id: "sleep-baseline",
          title: "Dormir 7h par nuit pendant 14 jours",
          category: "skin",
          difficulty: "medium",
          impact: "medium",
          xp: 160,
        },
      ],
    },
    {
      level: 2,
      title: "GROOMING",
      focus: "Affûter chaque ligne du visage.",
      quests: [
        {
          id: "beard-neckline",
          title: "Tracer une vraie ligne de cou",
          category: "facial_hair",
          difficulty: "easy",
          impact: "medium",
          xp: 120,
        },
        {
          id: "frame-swap",
          title: "Essayer trois formes de montures plus larges",
          category: "eyewear",
          difficulty: "medium",
          impact: "medium",
          xp: 150,
        },
        {
          id: "jaw-habits",
          title: "Éliminer sel et alcool en soirée",
          category: "jawline",
          difficulty: "medium",
          impact: "high",
          xp: 200,
        },
      ],
    },
    {
      level: 3,
      title: "STYLE",
      focus: "Harmoniser la silhouette avec le visage.",
      quests: [
        {
          id: "fit-basics",
          title: "Remplacer 3 basiques mal coupés",
          category: "style",
          difficulty: "medium",
          impact: "high",
          xp: 220,
        },
        {
          id: "color-palette",
          title: "Définir une palette de 4 couleurs",
          category: "style",
          difficulty: "easy",
          impact: "medium",
          xp: 140,
        },
        {
          id: "signature-piece",
          title: "Trouver une pièce signature",
          category: "style",
          difficulty: "hard",
          impact: "medium",
          xp: 260,
        },
      ],
    },
  ],
  annotations: [
    {
      id: "brow-gap",
      x: 50,
      y: 34,
      label: "Espace inter-sourcils",
      category: "eyebrows",
      severity: "high",
      observation:
        "Des poils épars relient les deux sourcils et brouillent la ligne du regard.",
      fix: "Nettoie uniquement la zone entre les sourcils à la pince, tous les 10 jours.",
      xp: 60,
      lesson: {
        title: "Nettoyer la ligne des sourcils sans la casser",
        steps: [
          {
            title: "Repère la limite",
            body: "Pose un crayon verticalement contre l'aile du nez : le sourcil doit commencer là. Tout ce qui dépasse vers l'intérieur peut partir.",
          },
          {
            title: "Épile après la douche",
            body: "La peau est souple, les poils partent avec la racine et la rougeur retombe en vingt minutes.",
          },
          {
            title: "Ne touche jamais le dessus",
            body: "Le contour supérieur porte la forme du sourcil. On ne dégarnit que l'entre-deux et les poils isolés très bas.",
          },
        ],
        tip: "Deux minutes toutes les deux semaines suffisent. Plus, et tu perds l'épaisseur qui rend le regard masculin.",
        quiz: {
          question: "Où ne faut-il jamais épiler ?",
          options: ["Entre les sourcils", "Au-dessus du sourcil", "Sous l'arcade basse"],
          answer_index: 1,
          explanation:
            "Le dessus définit l'arc naturel : l'épiler affine le sourcil et féminise le regard.",
        },
      },
    },
    {
      id: "jaw-line",
      x: 30,
      y: 74,
      label: "Contour de mâchoire",
      category: "jawline",
      severity: "high",
      observation:
        "La ligne se lit mais s'adoucit sous la joue : rétention d'eau et léger voile graisseux.",
      fix: "Sommeil régulier, moins de sel et d'alcool, déficit calorique léger si besoin.",
      xp: 120,
      lesson: {
        title: "Rendre une mâchoire lisible",
        steps: [
          {
            title: "Le taux de graisse d'abord",
            body: "Sous ~15 % chez l'homme, la ligne apparaît d'elle-même. Aucun exercice facial ne remplace ça.",
          },
          {
            title: "Coupe la rétention d'eau",
            body: "Moins de sel le soir, 2 L d'eau par jour, alcool limité : le bas du visage se dégonfle en une à deux semaines.",
          },
          {
            title: "Dors sur le dos",
            body: "Le sommeil sur le ventre écrase le visage et accentue les poches au réveil.",
          },
        ],
        tip: "Une barbe courte dégradée le long de la mâchoire donne le même effet visuel immédiatement.",
        quiz: {
          question: "Qu'est-ce qui change le plus vite l'aspect de la mâchoire ?",
          options: [
            "Mâcher un chewing-gum dur",
            "Réduire sel et alcool",
            "Des exercices de mâchoire quotidiens",
          ],
          answer_index: 1,
          explanation:
            "La rétention d'eau part en quelques jours. Le muscle masséter, lui, bouge à peine la silhouette du visage.",
        },
      },
    },
    {
      id: "under-eye",
      x: 62,
      y: 43,
      label: "Cernes",
      category: "eyes",
      severity: "medium",
      observation: "Ombre bleutée sous l'œil, typique d'un manque de sommeil chronique.",
      fix: "7 h 30 à 8 h de sommeil, écran coupé une heure avant, contour hydratant matin et soir.",
      xp: 80,
      lesson: {
        title: "Comprendre ses cernes",
        steps: [
          {
            title: "Identifie le type",
            body: "Bleu-violet = vasculaire (sommeil, hydratation). Brun = pigmentaire (soleil, génétique). Creux = structurel.",
          },
          {
            title: "Traite le bon levier",
            body: "Vasculaire : sommeil et sel. Pigmentaire : crème solaire quotidienne. Creux : lumière et coiffure, pas de crème miracle.",
          },
        ],
        tip: "Un contour au froid trente secondes le matin réduit le gonflement sans rien acheter d'autre.",
        quiz: {
          question: "Un cerne brun se traite surtout avec…",
          options: ["Plus de sommeil", "De la crème solaire", "Du café"],
          answer_index: 1,
          explanation:
            "Le brun est de la pigmentation : le soleil l'entretient, la protection quotidienne l'atténue.",
        },
      },
    },
    {
      id: "hairline-volume",
      x: 50,
      y: 14,
      label: "Volume et implantation",
      category: "hair",
      severity: "high",
      observation:
        "Les cheveux retombent à plat et écrasent le tiers supérieur du visage.",
      fix: "Coupe plus courte sur les côtés, longueur travaillée sur le dessus, séchage racines vers le haut.",
      xp: 100,
      lesson: {
        title: "Le volume est un levier gratuit",
        steps: [
          {
            title: "Sèche à l'envers",
            body: "Trente secondes tête en bas au sèche-cheveux tiède : les racines se relèvent et tiennent la journée.",
          },
          {
            title: "Produit léger, pas de gel lourd",
            body: "Une poudre texturisante ou une pâte mate donne du corps sans effet casque brillant.",
          },
          {
            title: "Demande une coupe, pas 'la même chose'",
            body: "Côtés dégradés courts, dessus conservé : le visage paraît plus haut et la mâchoire plus large.",
          },
        ],
        tip: "Le volume au sommet du crâne fait plus pour la silhouette du visage que n'importe quel soin.",
        quiz: {
          question: "Quel réglage de sèche-cheveux garde le volume ?",
          options: ["Air très chaud", "Air tiède puis coup de froid", "Séchage à la serviette"],
          answer_index: 1,
          explanation:
            "Le froid final fige la forme obtenue ; le très chaud abîme et fait retomber.",
        },
      },
    },
    {
      id: "skin-texture",
      x: 72,
      y: 55,
      label: "Texture de la peau",
      category: "skin",
      severity: "medium",
      observation: "Brillance sur la zone T et pores dilatés sur les joues hautes.",
      fix: "Nettoyant doux matin et soir, hydratant léger, SPF 30 chaque matin.",
      xp: 90,
      lesson: {
        title: "La routine minimale qui marche",
        steps: [
          {
            title: "Trois produits, pas dix",
            body: "Nettoyant doux, hydratant non comédogène, crème solaire. Tout le reste est optionnel.",
          },
          {
            title: "Introduis un actif à la fois",
            body: "Rétinol le soir, deux fois par semaine au début. Un actif nouveau toutes les quatre semaines maximum.",
          },
          {
            title: "Le soleil est le facteur numéro un",
            body: "L'exposition non protégée pèse plus sur la texture et le vieillissement que tous les sérums réunis.",
          },
        ],
        tip: "La peau met six à huit semaines à répondre. Change de routine trop vite et tu ne sauras jamais ce qui marchait.",
        quiz: {
          question: "Quel produit a le plus d'effet à long terme ?",
          options: ["Un sérum vitamine C", "Une crème solaire quotidienne", "Un gommage"],
          answer_index: 1,
          explanation:
            "La protection solaire quotidienne est la seule habitude prouvée pour la texture et le vieillissement.",
        },
      },
    },
    {
      id: "beard-line",
      x: 50,
      y: 86,
      label: "Ligne du cou",
      category: "facial_hair",
      severity: "medium",
      observation: "La barbe descend trop bas sur le cou et efface la limite du menton.",
      fix: "Trace la limite deux doigts au-dessus de la pomme d'Adam, en courbe, jamais à l'horizontale.",
      xp: 70,
      lesson: {
        title: "Placer sa ligne de cou",
        steps: [
          {
            title: "Trouve le point",
            body: "Deux doigts au-dessus de la pomme d'Adam : c'est la hauteur de la limite basse.",
          },
          {
            title: "Suis une courbe en U",
            body: "Relie ce point aux deux angles derrière la mâchoire. Une ligne droite fait 'barbe collée'.",
          },
        ],
        tip: "Une barbe courte bien délimitée bat une barbe longue mal délimitée à chaque fois.",
        quiz: {
          question: "Où passe la limite basse d'une barbe ?",
          options: [
            "Sous le menton, à l'os",
            "Deux doigts au-dessus de la pomme d'Adam",
            "Au niveau du col",
          ],
          answer_index: 1,
          explanation:
            "Plus haut, on efface le menton ; plus bas, la barbe se confond avec le cou.",
        },
      },
    },
  ],
  protocols: [
    {
      id: "nutrition",
      title: "Nutrition — la base de la composition du visage",
      why: "Le taux de graisse et l'inflammation décident de la définition de la mâchoire, du gonflement du visage et de l'éclat de la peau.",
      steps: [
        "1,6 à 2 g de protéines par kilo de poids de corps, réparties sur la journée.",
        "Légumes et fruits à chaque repas pour les micronutriments (zinc, vitamine A, vitamine C).",
        "Poissons gras deux fois par semaine ou une source d'oméga-3 régulière.",
        "Sel modéré le soir et 2 L d'eau par jour pour limiter la rétention.",
        "Déficit calorique léger (200 à 400 kcal) si le voile graisseux masque la structure.",
      ],
      avoid: [
        "Les régimes très restrictifs : ils creusent le visage et abîment la peau.",
        "L'alcool fréquent : rétention d'eau, teint terne, sommeil dégradé.",
      ],
      timeline: "Visible sur le visage en 4 à 8 semaines.",
    },
    {
      id: "hormones",
      title: "Hormones — les leviers naturels, rien d'autre",
      why: "Sommeil, entraînement, graisse corporelle et micronutriments soutiennent un profil hormonal sain, ce qui se lit sur la peau, la barbe et la densité du visage.",
      steps: [
        "Dors 7 h 30 à 9 h : c'est le levier hormonal le plus puissant et le plus gratuit.",
        "Musculation lourde 3 à 4 fois par semaine, mouvements polyarticulaires.",
        "Garde un taux de graisse sain : trop haut comme trop bas dégrade le profil hormonal.",
        "Couvre zinc, magnésium et vitamine D par l'alimentation et le soleil ; teste avant de te supplémenter.",
        "Réduis le stress chronique : le cortisol prolongé agit contre tout le reste.",
      ],
      avoid: [
        "Stéroïdes, SARMs, hormones ou 'boosters' vendus en ligne.",
        "Les protocoles de forum qui promettent de changer la structure osseuse.",
      ],
      timeline: "Effets réels sur 3 à 6 mois. Aucun raccourci sûr n'existe.",
    },
    {
      id: "sleep",
      title: "Sommeil — le multiplicateur",
      why: "Le manque de sommeil se voit en premier : cernes, teint gris, paupières gonflées, mâchoire moins nette.",
      steps: [
        "Heure de coucher fixe, même le week-end, à trente minutes près.",
        "Chambre sombre et fraîche, écrans coupés une heure avant.",
        "Pas de caféine après 14 h si tu t'endors mal.",
        "Dors sur le dos pour éviter l'écrasement du visage.",
      ],
      avoid: ["Les nuits de rattrapage : elles ne compensent pas la dette."],
      timeline: "Différence visible en 5 à 10 jours.",
    },
    {
      id: "training",
      title: "Entraînement — la posture et la ligne du cou",
      why: "Épaules, cou et posture cadrent le visage sur chaque photo et dans chaque conversation.",
      steps: [
        "Trois séances de musculation par semaine, focus dos et épaules.",
        "Travail du cou léger et progressif, deux fois par semaine maximum.",
        "10 000 pas par jour pour la gestion de la graisse sans fatigue nerveuse.",
        "Étirements des pectoraux et des fléchisseurs de hanche contre la posture avachie.",
      ],
      avoid: ["Le travail du cou lourd sans progression : risque de blessure réel."],
      timeline: "Posture en 4 semaines, silhouette en 3 mois.",
    },
    {
      id: "skincare",
      title: "Peau — routine minimale, tenue longtemps",
      why: "La texture et l'uniformité du teint pèsent plus dans la perception que n'importe quel trait isolé.",
      steps: [
        "Nettoyant doux matin et soir.",
        "Hydratant non comédogène adapté à ton type de peau.",
        "SPF 30 minimum tous les matins, même en hiver.",
        "Rétinol le soir, deux fois par semaine, à introduire progressivement.",
      ],
      avoid: [
        "Les gommages agressifs quotidiens.",
        "Empiler cinq actifs nouveaux la même semaine.",
      ],
      timeline: "6 à 8 semaines avant de juger une routine.",
    },
  ],
};
