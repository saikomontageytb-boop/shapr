import { useParams } from "@tanstack/react-router";
import { dict, isLang, DEFAULT_LANG, type Lang } from "./i18n";
import { CATEGORY_LABELS, type CategoryKey } from "./analysis-schema";

const CATEGORY_LABELS_FR: Record<CategoryKey, string> = {
  face_shape: "Forme du visage",
  symmetry: "Symétrie",
  jawline: "Mâchoire et menton",
  eyes: "Yeux",
  eyebrows: "Sourcils",
  nose: "Nez",
  skin: "Peau",
  hair: "Cheveux",
  facial_hair: "Barbe",
  eyewear: "Lunettes",
  style: "Style",
  proportions: "Proportions du visage",
};

/** Current language, read from the /:lang route segment. */
export function useLang(): Lang {
  const params = useParams({ strict: false }) as { lang?: string };
  return isLang(params.lang) ? params.lang : DEFAULT_LANG;
}

export function useT() {
  const lang = useLang();
  return { lang, t: dict(lang) };
}

/** Category names, translated. */
export function useCategoryLabels(): Record<CategoryKey, string> {
  const lang = useLang();
  return lang === "fr" ? CATEGORY_LABELS_FR : CATEGORY_LABELS;
}
