import type { CategoryKey } from "./analysis-schema";

/**
 * Each report category points at the academy module that teaches it.
 * Used by the face map: a branch pulled from a point on the photo drops the
 * reader straight into the matching adventure path.
 */
export const CATEGORY_TRACK: Record<CategoryKey, string> = {
  face_shape: "face",
  symmetry: "face",
  jawline: "face",
  eyes: "face",
  eyebrows: "face",
  nose: "face",
  proportions: "face",
  skin: "skin",
  hair: "hair",
  facial_hair: "hair",
  eyewear: "style",
  style: "style",
};

export function trackForCategory(key: CategoryKey): string {
  return CATEGORY_TRACK[key] ?? "face";
}
