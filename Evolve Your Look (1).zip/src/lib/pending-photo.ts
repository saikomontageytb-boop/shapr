/**
 * Hand-off for a photo picked on the landing page and confirmed on /scan.
 * Session-scoped and cleared on read: the image never persists past the tab.
 */
const KEY = "loadout.pending-photo";

export function setPendingPhoto(dataUrl: string) {
  try {
    window.sessionStorage.setItem(KEY, dataUrl);
  } catch {
    /* storage unavailable — the scan page simply asks for the photo again */
  }
}

export function takePendingPhoto(): string | null {
  if (typeof window === "undefined") return null;
  try {
    const value = window.sessionStorage.getItem(KEY);
    window.sessionStorage.removeItem(KEY);
    return value;
  } catch {
    return null;
  }
}

/**
 * Session-scoped copy of the scanned photo, kept only so the face map can be
 * drawn on the report page in the same tab. Never uploaded, never persisted.
 */
const SESSION_KEY = "loadout.session-photo";

export function setSessionPhoto(dataUrl: string) {
  try {
    window.sessionStorage.setItem(SESSION_KEY, dataUrl);
  } catch {
    /* storage unavailable — the face map falls back to a generic guide */
  }
}

export function getSessionPhoto(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.sessionStorage.getItem(SESSION_KEY);
  } catch {
    return null;
  }
}

export function clearSessionPhoto() {
  try {
    window.sessionStorage.removeItem(SESSION_KEY);
  } catch {
    /* nothing to clear */
  }
}

