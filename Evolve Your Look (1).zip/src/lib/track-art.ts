import beard from "@/assets/tracks/beard.png";
import body from "@/assets/tracks/body.png";
import cardio from "@/assets/tracks/cardio.png";
import eyes from "@/assets/tracks/eyes.png";
import fragrance from "@/assets/tracks/fragrance.png";
import grooming from "@/assets/tracks/grooming.png";
import habits from "@/assets/tracks/habits.png";
import mobility from "@/assets/tracks/mobility.png";
import photo from "@/assets/tracks/photo.png";
import posture from "@/assets/tracks/posture.png";
import sportnutrition from "@/assets/tracks/sportnutrition.png";
import stress from "@/assets/tracks/stress.png";
import supplements from "@/assets/tracks/supplements.png";
import teeth from "@/assets/tracks/teeth.png";
import face from "@/assets/tracks/face.png";
import hair from "@/assets/tracks/hair.png";
import hormones from "@/assets/tracks/hormones.png";
import mind from "@/assets/tracks/mind.png";
import nutrition from "@/assets/tracks/nutrition.png";
import seduction from "@/assets/tracks/seduction.png";
import skin from "@/assets/tracks/skin.png";
import sleep from "@/assets/tracks/sleep.png";
import social from "@/assets/tracks/social.png";
import style from "@/assets/tracks/style.png";
import training from "@/assets/tracks/training.png";
import voice from "@/assets/tracks/voice.png";

/** Own illustrations, one per module. Generated for Shapr, not stock photos. */
const ART: Record<string, string> = {
  face,
  hair,
  hormones,
  mind,
  nutrition,
  seduction,
  skin,
  sleep,
  social,
  style,
  training,
  voice,
  beard,
  body,
  cardio,
  eyes,
  fragrance,
  grooming,
  habits,
  mobility,
  photo,
  posture,
  sportnutrition,
  stress,
  supplements,
  teeth,
};

export function trackArt(trackId: string): string | undefined {
  return ART[trackId];
}
