import { useAccount } from "./account";
import { FREE_LESSON_KEYS, FREE_LESSON_COUNT, isFreeLesson } from "./free-lessons";

/**
 * Free members read the same three lessons as everybody else; every other
 * lesson belongs to the subscription. Nothing is stored on the device.
 */
export { FREE_LESSON_KEYS, FREE_LESSON_COUNT, isFreeLesson };

export interface LessonAccess {
  pro: boolean;
  /** True when the lesson can be opened right now. */
  canOpen: (key: string) => boolean;
  isFree: (key: string) => boolean;
}

export function useLessonAccess(): LessonAccess {
  const account = useAccount();
  return {
    pro: account.pro,
    canOpen: account.canOpen,
    isFree: isFreeLesson,
  };
}
