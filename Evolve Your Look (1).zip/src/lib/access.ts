import { useAuth } from "./auth";
import { useIsPro } from "./pro";

/**
 * What a visitor is allowed to see of a report.
 * - `anon`  : signed out. Nothing but a sign-up wall.
 * - `free`  : signed in. Score, potential and percentile only.
 * - `pro`   : subscribed. The whole report, face map and lessons.
 *
 * The scan itself is free and unlimited for everyone.
 */
export type Access = "anon" | "free" | "pro";

export function useAccess(): Access {
  const { user } = useAuth();
  const pro = useIsPro();
  if (pro) return "pro";
  return user ? "free" : "anon";
}
