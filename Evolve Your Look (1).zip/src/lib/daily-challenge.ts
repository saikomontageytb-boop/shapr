import type { Lang } from "./i18n";
import { questionPool, type ArenaQuestion } from "./arena";

export const DAILY_QUESTION_COUNT = 5;
/** Daily challenge is always played on the "Sharp" step: 4 answers, 8s, ×1.6. */
export const DAILY_DIFFICULTY = 3;

export function utcDay(): string {
  return new Date().toISOString().slice(0, 10);
}

/** Month key used for the monthly reset of daily-challenge points. */
export function utcMonth(): string {
  return utcDay().slice(0, 7);
}

function hashSeed(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function seededRandom(seed: number) {
  let state = seed || 1;
  return () => {
    state = Math.imul(state ^ (state >>> 15), 1 | state);
    state ^= state + Math.imul(state ^ (state >>> 7), 61 | state);
    return ((state ^ (state >>> 14)) >>> 0) / 4294967296;
  };
}

function seededShuffle<T>(items: T[], random: () => number): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i -= 1) {
    const j = Math.floor(random() * (i + 1));
    const a = copy[i]!;
    copy[i] = copy[j]!;
    copy[j] = a;
  }
  return copy;
}

/** Same four answers, in the same order, for everybody on a given day. */
function seededNarrow(question: ArenaQuestion, optionCount: number, random: () => number): ArenaQuestion {
  const correct = question.options[question.answer]!;
  const wrong = seededShuffle(
    question.options.filter((_, i) => i !== question.answer),
    random,
  );
  const options = seededShuffle([correct, ...wrong.slice(0, Math.max(1, optionCount - 1))], random);
  return { ...question, options, answer: options.indexOf(correct) };
}

/**
 * Five questions, identical for every member, fully renewed every UTC day.
 * The day seeds both the picks and the answer order, so nothing repeats
 * from one day to the next unless the whole pool has been used.
 */
export function dailyQuestions(lang: Lang, day = utcDay()): ArenaQuestion[] {
  const random = seededRandom(hashSeed(`shapr:daily:${day}`));
  const pool = questionPool(lang, []);
  if (pool.length === 0) return [];

  // Rotate the pool by the day index so consecutive days never overlap while
  // the pool lasts, then shuffle inside that day's window.
  const dayIndex = Math.floor(Date.parse(`${day}T00:00:00Z`) / 86_400_000);
  const offset = (dayIndex * DAILY_QUESTION_COUNT) % pool.length;
  const ordered = seededShuffle(pool, seededRandom(hashSeed("shapr:daily:pool")));
  const window: ArenaQuestion[] = [];
  for (let i = 0; i < Math.min(DAILY_QUESTION_COUNT, ordered.length); i += 1) {
    window.push(ordered[(offset + i) % ordered.length]!);
  }

  return seededShuffle(window, random).map((question) => seededNarrow(question, 4, random));
}
