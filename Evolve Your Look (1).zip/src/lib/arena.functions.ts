import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const runSchema = z.object({
  score: z.number().int().min(0),
  difficulty: z.number().int().min(0).max(4),
  questionCount: z.number().int().min(1).max(100),
  correctCount: z.number().int().min(0).max(100),
  bestStreak: z.number().int().min(0).max(100),
  eliminated: z.boolean(),
  categoryIds: z.array(z.string().max(64)).max(20),
  challengeDate: z.string().date().nullable(),
});

export interface PlayerProgress {
  arenaXp: number;
  runs: number;
  bestScore: number;
  dailyStreak: number;
  dailyXp: number;
  dailyPeriod: string | null;
  accountXp: number;
  lastDailyDate: string | null;
  showOnLeaderboard: boolean;
  badges: string[];
}

export interface LeaderboardEntry {
  rank: number;
  displayName: string;
  arenaXp: number;
  dailyXp: number;
  accountXp: number;
  totalXp: number;
  bestScore: number;
  current: boolean;
}

export const getArenaHub = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const [progress, badges] = await Promise.all([
      context.supabase
        .from("player_progress")
        .select("arena_xp,runs,best_score,daily_streak,daily_xp,daily_period,account_xp,last_daily_date,show_on_leaderboard")
        .eq("user_id", context.userId)
        .maybeSingle(),
      context.supabase.from("badge_unlocks").select("badge_id").eq("user_id", context.userId),
    ]);
    if (progress.error) throw progress.error;
    if (badges.error) throw badges.error;
    const row = progress.data;
    const player: PlayerProgress = {
      arenaXp: row?.arena_xp ?? 0,
      runs: row?.runs ?? 0,
      bestScore: row?.best_score ?? 0,
      dailyStreak: row?.daily_streak ?? 0,
      dailyXp: row?.daily_xp ?? 0,
      dailyPeriod: row?.daily_period ?? null,
      accountXp: row?.account_xp ?? 0,
      lastDailyDate: row?.last_daily_date ?? null,
      showOnLeaderboard: row?.show_on_leaderboard ?? true,
      badges: (badges.data ?? []).map((item) => item.badge_id),
    };
    return player;
  });

export const getLeaderboard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    void context.userId;
    const { data, error } = await supabaseAdmin.rpc("get_arena_leaderboard", { p_limit: 50 });
    if (error) throw error;
    return (data ?? []).map((row) => ({
      rank: Number(row.rank),
      displayName: row.display_name,
      arenaXp: row.arena_xp,
      dailyXp: row.daily_xp,
      accountXp: row.account_xp,
      totalXp: row.total_xp,
      bestScore: row.best_score,
      current: row.is_current_user,
    })) satisfies LeaderboardEntry[];
  });

export const submitArenaRun = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => runSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const args = {
      p_user_id: context.userId,
      p_score: data.score,
      p_difficulty: data.difficulty,
      p_question_count: data.questionCount,
      p_correct_count: data.correctCount,
      p_best_streak: data.bestStreak,
      p_eliminated: data.eliminated,
      p_category_ids: data.categoryIds,
      ...(data.challengeDate ? { p_challenge_date: data.challengeDate } : {}),
    };
    const { data: rows, error } = await supabaseAdmin.rpc("submit_arena_run_internal", args);
    if (error) throw error;
    const row = rows?.[0];
    if (!row) throw new Error("Run not recorded");
    return { arenaXp: row.arena_xp, runs: row.runs, bestScore: row.best_score, dailyStreak: row.daily_streak, xpEarned: row.xp_earned, badges: row.new_badges };
  });

export const setLeaderboardVisibility = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ visible: z.boolean() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("player_progress")
      .upsert({ user_id: context.userId, show_on_leaderboard: data.visible }, { onConflict: "user_id" });
    if (error) throw error;
    return { visible: data.visible };
  });

/** Mirrors the member's account XP (scan + lessons) so it can be ranked. */
export const syncAccountXp = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ xp: z.number().int().min(0).max(1_000_000) }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("player_progress")
      .upsert({ user_id: context.userId, account_xp: data.xp }, { onConflict: "user_id" });
    if (error) throw error;
    return { xp: data.xp };
  });
