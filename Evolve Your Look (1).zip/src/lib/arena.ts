/**
 * Arène — endless quiz mode.
 *
 * Questions are pulled from the quiz blocks already written inside academy
 * lessons, so the mode always tests things the reader could have learned.
 */
import type { Lang } from "./i18n";
import { ACADEMY, CATEGORIES } from "./academy";

export interface ArenaQuestion {
  id: string;
  trackId: string;
  trackTitle: string;
  question: string;
  options: string[];
  answer: number;
  explanation: string;
}

export interface ArenaConfig {
  /** Category ids; empty means every category. */
  categoryIds: string[];
  /** 0..4 — drives answers, clock, scoring and sudden death. */
  difficulty: number;
  /** 0 means endless. */
  questionCount: number;
}

export interface Difficulty {
  /** 2 to 4 answers shown per question. */
  optionCount: number;
  /** Seconds per question, 0 disables the clock. */
  seconds: number;
  /** Score and XP multiplier. */
  reward: number;
  /** One mistake ends the run. */
  suddenDeath: boolean;
  fr: string;
  en: string;
}

/** Five steps, deliberately pushed to both extremes. */
export const DIFFICULTIES: Difficulty[] = [
  { optionCount: 2, seconds: 0, reward: 0.5, suddenDeath: false, fr: "Échauffement", en: "Warm-up" },
  { optionCount: 3, seconds: 30, reward: 0.8, suddenDeath: false, fr: "Tranquille", en: "Easy" },
  { optionCount: 4, seconds: 15, reward: 1, suddenDeath: false, fr: "Standard", en: "Standard" },
  { optionCount: 4, seconds: 8, reward: 1.6, suddenDeath: false, fr: "Nerveux", en: "Sharp" },
  { optionCount: 4, seconds: 5, reward: 2.5, suddenDeath: true, fr: "Insane", en: "Insane" },
];

export function difficultyOf(config: ArenaConfig): Difficulty {
  return DIFFICULTIES[Math.min(DIFFICULTIES.length - 1, Math.max(0, config.difficulty))]!;
}

export const LENGTH_CHOICES = [5, 10, 20, 0];

export const DEFAULT_CONFIG: ArenaConfig = {
  categoryIds: [],
  difficulty: 2,
  questionCount: 10,
};


/** Every quiz block of every lesson, flattened. */
export function questionPool(lang: Lang, categoryIds: string[]): ArenaQuestion[] {
  const allowed = new Set(
    categoryIds.length
      ? CATEGORIES.filter((c) => categoryIds.includes(c.id)).flatMap((c) => c.trackIds)
      : ACADEMY[lang].map((t) => t.id),
  );

  const out: ArenaQuestion[] = [];
  for (const track of ACADEMY[lang]) {
    if (!allowed.has(track.id)) continue;
    for (const lesson of track.lessons) {
      lesson.blocks.forEach((block, i) => {
        if (block.kind !== "quiz") return;
        if (block.options.length < 2) return;
        out.push({
          id: `${track.id}:${lesson.id}:${i}`,
          trackId: track.id,
          trackTitle: track.title,
          question: block.question,
          options: block.options,
          answer: block.answer,
          explanation: block.explanation,
        });
      });
    }
  }
  return out;
}

export function shuffle<T>(items: T[]): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const a = copy[i]!;
    copy[i] = copy[j]!;
    copy[j] = a;
  }
  return copy;
}

/** Trim a question down to `optionCount` answers, keeping the right one. */
export function narrow(question: ArenaQuestion, optionCount: number): ArenaQuestion {
  const correct = question.options[question.answer]!;
  const wrong = shuffle(question.options.filter((_, i) => i !== question.answer));
  const kept = [correct, ...wrong.slice(0, Math.max(1, optionCount - 1))];
  const options = shuffle(kept);
  return { ...question, options, answer: options.indexOf(correct) };
}

/** Points for one right answer, richer as the streak grows. */
export function scoreFor(
  streak: number,
  secondsLeft: number,
  seconds: number,
  reward = 1,
): number {
  const multiplier = Math.min(5, 1 + Math.floor(streak / 3));
  const speed = seconds > 0 ? Math.round((secondsLeft / seconds) * 40) : 20;
  return Math.round((60 + speed) * multiplier * reward);
}

export function multiplierFor(streak: number): number {
  return Math.min(5, 1 + Math.floor(streak / 3));
}

/** XP credited to the profile for a finished run. */
export function xpForRun(score: number, reward: number): number {
  return Math.round((score / 12) * reward);
}


export const ARENA_COPY = {
  fr: {
    name: "Arène",
    tagline: "Le mode sans fin qui teste ce que tu as appris.",
    intro:
      "Choisis tes thèmes, ta difficulté et la longueur. Enchaîne les bonnes réponses pour faire monter le multiplicateur et gagner de l'XP.",
    themes: "Thèmes",
    allThemes: "Tous les thèmes",
    answers: "Réponses par question",
    length: "Questions",
    endless: "Sans fin",
    timer: "Temps par question",
    noTimer: "Sans limite",
    seconds: "s",
    difficulty: "Difficulté",
    suddenDeath: "Mort subite : une erreur et c'est fini.",
    reward: "Gain",
    impact: "Impact sur ta progression",
    xpEarned: "XP gagnés",
    level: "Niveau",
    levelUp: "Niveau atteint",
    toNext: "avant le niveau suivant",
    totalXp: "XP d'arène",
    runs: "Parties jouées",
    eliminated: "Éliminé",

    play: "Entrer dans l'arène",
    questionsReady: "questions prêtes",
    notEnough: "Pas assez de questions sur ces thèmes.",
    streak: "Série",
    score: "Score",
    best: "Record",
    quit: "Quitter",
    stop: "Arrêter et voir le score",
    next: "Question suivante",
    timeUp: "Temps écoulé",
    correct: "Bien vu",
    wrong: "Raté",
    over: "Partie terminée",
    right: "bonnes réponses",
    accuracy: "Réussite",
    bestStreak: "Meilleure série",
    again: "Rejouer",
    change: "Changer les réglages",
    newBest: "Nouveau record",
    perfect: "Sans faute. Impressionnant.",
    good: "Solide. Encore une série et tu montes.",
    meh: "Il y a des leçons à revoir.",
    backAcademy: "Retour aux leçons",
  },
  en: {
    name: "Arena",
    tagline: "The endless mode that tests what you learned.",
    intro:
      "Pick your themes, difficulty and run length. Chain right answers to raise the multiplier and earn XP.",
    themes: "Themes",
    allThemes: "All themes",
    answers: "Answers per question",
    length: "Questions",
    endless: "Endless",
    timer: "Time per question",
    noTimer: "No limit",
    seconds: "s",
    difficulty: "Difficulty",
    suddenDeath: "Sudden death: one mistake ends the run.",
    reward: "Reward",
    impact: "Impact on your progress",
    xpEarned: "XP earned",
    level: "Level",
    levelUp: "Level reached",
    toNext: "to the next level",
    totalXp: "Arena XP",
    runs: "Runs played",
    eliminated: "Eliminated",

    play: "Enter the arena",
    questionsReady: "questions ready",
    notEnough: "Not enough questions in these themes.",
    streak: "Streak",
    score: "Score",
    best: "Best",
    quit: "Quit",
    stop: "Stop and see the score",
    next: "Next question",
    timeUp: "Time up",
    correct: "Nailed it",
    wrong: "Missed",
    over: "Run over",
    right: "right answers",
    accuracy: "Accuracy",
    bestStreak: "Best streak",
    again: "Play again",
    change: "Change settings",
    newBest: "New best",
    perfect: "Flawless. Impressive.",
    good: "Solid. One more run and you level up.",
    meh: "Some lessons are worth a second read.",
    backAcademy: "Back to lessons",
  },
} as const;

export type ArenaCopy = { [K in keyof (typeof ARENA_COPY)["fr"]]: string };

const BEST_KEY = "loadout.arena.best.v1";

export function loadBest(): number {
  if (typeof window === "undefined") return 0;
  const raw = window.localStorage.getItem(BEST_KEY);
  const value = raw ? Number(raw) : 0;
  return Number.isFinite(value) ? value : 0;
}

export function saveBest(score: number): void {
  if (typeof window === "undefined") return;
  if (score > loadBest()) window.localStorage.setItem(BEST_KEY, String(score));
}

/* ---------------------------------------------------------- arena progress */

const PROGRESS_KEY = "loadout.arena.progress.v1";

export interface ArenaProgress {
  xp: number;
  runs: number;
}

export function loadProgress(): ArenaProgress {
  if (typeof window === "undefined") return { xp: 0, runs: 0 };
  try {
    const raw = window.localStorage.getItem(PROGRESS_KEY);
    const parsed = raw ? (JSON.parse(raw) as Partial<ArenaProgress>) : null;
    return {
      xp: Number.isFinite(parsed?.xp) ? Number(parsed?.xp) : 0,
      runs: Number.isFinite(parsed?.runs) ? Number(parsed?.runs) : 0,
    };
  } catch {
    return { xp: 0, runs: 0 };
  }
}

export function addProgress(xp: number): ArenaProgress {
  const current = loadProgress();
  const next: ArenaProgress = { xp: current.xp + Math.max(0, xp), runs: current.runs + 1 };
  if (typeof window !== "undefined") {
    window.localStorage.setItem(PROGRESS_KEY, JSON.stringify(next));
  }
  return next;
}

