/**
 * Bilingual copy. French is the default; English is opt-in via the /en prefix.
 * Every user-facing string lives here so routes stay layout-only.
 */
export const LANGS = ["fr", "en"] as const;
export type Lang = (typeof LANGS)[number];

export const DEFAULT_LANG: Lang = "fr";

export function isLang(value: unknown): value is Lang {
  return typeof value === "string" && (LANGS as readonly string[]).includes(value);
}

export function otherLang(lang: Lang): Lang {
  return lang === "fr" ? "en" : "fr";
}

const fr = {
  nav: {
    how: "Le principe",
    academy: "Académie",
    dashboard: "Tableau de bord",
    analyze: "Ce qu'on lit",
    pricing: "Tarif",
    example: "Rapport exemple",
    scan: "Lancer mon scan",
    progress: "Ma progression",
    signIn: "Se connecter",
    signOut: "Se déconnecter",
    account: "Mon compte",
    menuOpen: "Ouvrir le menu",
    menuClose: "Fermer le menu",
    home: "Accueil Shapr",
  },
  hero: {
    kicker: "Optimisation de personnage, version vie réelle",
    title: "Apprends",
    titleAccent: "à être beau",
    lead: "Une photo. Une lecture honnête de douze aspects de ton apparence, les trois changements qui comptent vraiment, et l'ordre dans lequel les faire.",
    dropTitle: "Dépose ta photo ici",
    dropHint: "JPG, PNG ou WebP — 8 Mo max. Analysée, puis effacée.",
    choose: "Choisir une photo",
    preparing: "Préparation…",
    orExample: "Voir un rapport exemple",
    reassure: "Sans compte · Photo effacée après analyse · Aucune chirurgie recommandée",
    frameLabel: "Cadre d'analyse",
  },
  upload: {
    tipsTitle: "Pour une lecture correcte",
    tips: [
      "Visage bien visible",
      "Lumière régulière",
      "Sans lunettes de soleil",
      "Sans filtre",
      "Regard vers l'avant",
      "Nette, pas floue",
    ],
    privacyNote:
      "Ta photo ne sort jamais de la requête : ni stockage, ni journal, ni URL.",
    errType: "Ce format n'est pas pris en charge. Utilise un JPG, PNG ou WebP.",
    errSize: "Cette photo dépasse 8 Mo. Réexporte-la en plus léger.",
    errRead: "Impossible de lire ce fichier. Essaie une autre photo.",
  },
  steps: {
    label: "Le principe",
    title: "Trois étapes. Moins d'une minute.",
    items: [
      {
        n: "01",
        title: "Envoyer",
        body: "Une photo nette, de face. Pas de compte, pas d'e-mail, pas de tunnel en quatorze écrans.",
      },
      {
        n: "02",
        title: "Analyser",
        body: "Un modèle de vision lit douze aspects de ta présentation et note ce qu'il peut réellement observer.",
      },
      {
        n: "03",
        title: "Améliorer",
        body: "Tu repars avec des changements classés et un parcours : quoi faire d'abord, et ce que ça vaut.",
      },
    ],
  },
  analyze: {
    label: "Ce qu'on lit",
    title: "Douze catégories, notées séparément.",
    intro:
      "Certaines se changent cette semaine. D'autres sont structurelles : on les traite comme fixes et le plan compose avec, au lieu de faire semblant.",
  },
  potential: {
    label: "Ton potentiel",
    title: "Toi aujourd'hui, toi bien présenté.",
    intro:
      "Le potentiel ici veut dire une seule chose : le même visage, mieux présenté. Meilleure coupe, meilleur soin, meilleures montures, meilleures coupes de vêtements, meilleures photos. Aucune promesse biologique.",
    currentLabel: "Actuel",
    currentBody:
      "Réglages par défaut : la dernière coupe en date et ce que tu as attrapé sur la chaise ce matin.",
    ceilingLabel: "Plafond de présentation",
    ceilingBody:
      "Même ossature, même tout. Simplement chaque variable contrôlable réellement réglée.",
  },
  example: {
    label: "Rapport exemple",
    title: "Ce que tu reçois vraiment.",
    intro: "Pas un chiffre et un haussement d'épaules. Une lecture actionnable ce soir.",
    upgrade: "Amélioration",
    impact: "impact",
    readFull: "Lire le rapport exemple complet",
    sampleLabel: "Données d'exemple",
    sampleBody:
      "Rapport de démonstration pour une personne fictive, pas une vraie analyse.",
    scanCta: "Scanner mon visage",
  },
  progression: {
    label: "Progression",
    title: "Re-scanne. Regarde le chiffre bouger.",
    intro:
      "Chaque amélioration terminée donne de l'XP. Chaque re-scan est un point de contrôle. Une progression visible bat une motivation à fabriquer.",
    xpTitle: "XP d'apparence",
    xpBody: "Termine une mission du parcours, encaisse l'XP, passe un niveau.",
    firstLabel: "PREMIER 6.1",
    currentLabel: "ACTUEL 6.8",
    compareBody: "Comparaison des scans, côte à côte, avec ce qui a changé.",
    achievementsTitle: "Succès",
    achievementsBody:
      "Premier scan. Coupe améliorée. Style amélioré. Nouveau record. Gagnés, pas offerts.",
  },
  privacy: {
    label: "Confidentialité",
    title: "Ta photo est analysée, puis effacée.",
    intro:
      "Elle vit le temps d'une requête. Aucun stockage, aucun journal, aucune URL permanente, aucune donnée faciale dans les statistiques.",
    chipDeleted: "Effacée après analyse",
    chipNeverLogged: "Jamais journalisée ni partagée",
    readMore: "Lire le détail complet",
    pageLead:
      "Une photo de visage est une donnée sensible. On la traite comme telle : elle existe le temps d'une requête, pas plus.",
    points: [
      {
        title: "Analysée en mémoire",
        body: "Ta photo voyage dans une seule requête, est lue par le modèle de vision, et disparaît quand la réponse revient. Elle n'est jamais écrite sur disque ni en base.",
      },
      {
        title: "Effacée après analyse",
        body: "Pas d'historique de photos, pas de galerie, pas de sauvegarde. Seul le rapport dérivé — des chiffres et du texte — persiste, sur ton appareil ou dans ton compte si tu en crées un.",
      },
      {
        title: "Jamais journalisée, jamais publique",
        body: "Les images sont exclues des journaux serveur et des rapports d'erreur, et aucune URL publique vers ta photo n'est jamais créée.",
      },
      {
        title: "Aucune donnée faciale dans les statistiques",
        body: "Les statistiques produit enregistrent des événements comme « scan terminé ». Les photos, les octets d'image et les mesures faciales ne partent jamais chez un tiers.",
      },
    ],
    checksTitle: "Ce qu'on vérifie à l'envoi",
    checks: [
      "Type de fichier vérifié côté serveur (JPG, PNG, WebP uniquement)",
      "Taille plafonnée à 8 Mo, résolution minimale exigée",
      "Limitation du nombre de scans par adresse réseau",
      "Toute validation refaite côté serveur, jamais crue depuis le navigateur",
      "Les clés d'IA restent sur le serveur, jamais exposées au navigateur",
    ],
  },
  pricing: {
    label: "Tarif",
    title: "Le scan est gratuit. Tu paies le plan.",
    intro:
      "Tu vois ton score avant de dépenser quoi que ce soit. C'est l'ordre honnête des opérations.",
    freeLabel: "Scan gratuit",
    freeItems: [
      "Score global et centile",
      "Trois catégories détaillées",
      "Une recommandation",
    ],
    fullLabel: "Rapport complet",
    fullItems: [
      "Les douze catégories, en détail",
      "Tes trois améliorations prioritaires",
      "Le parcours d'amélioration complet",
      "Comparaison de scans et suivi d'XP",
    ],
    fullCta: "Scanner, puis débloquer",
  },
  faq: {
    label: "FAQ",
    title: "Les questions qu'on nous pose vraiment.",
    items: [
      {
        q: "C'est juste une note de beauté ?",
        a: "Non. Le score sert de point de départ. La valeur est dans les douze lectures de catégories et la liste ordonnée de ce qu'il faut changer en premier.",
      },
      {
        q: "Le score est-il objectif ?",
        a: "Ce n'est pas une vérité scientifique et on ne prétendra pas le contraire. C'est une lecture structurée de ta présentation actuelle, basée sur ce que le modèle observe sur ta photo.",
      },
      {
        q: "Est-ce qu'on va me conseiller la chirurgie ?",
        a: "Jamais. Shapr ne recommande ni chirurgie, ni médicaments, ni régimes extrêmes, ni rien d'invasif. Les traits structurels sont marqués comme fixes et le plan s'organise autour.",
      },
      {
        q: "Que devient ma photo ?",
        a: "Elle est analysée dans une seule requête puis abandonnée. Pas de stockage, pas de journal, pas d'URL publique, pas d'historique.",
      },
      {
        q: "Faut-il un compte ?",
        a: "Pas pour ton premier scan. Ton rapport est gardé dans ton navigateur. Le compte sert à conserver ton historique d'un appareil à l'autre.",
      },
      {
        q: "Qu'est-ce qui est gratuit ?",
        a: "Ton score global, ton centile, trois catégories et une recommandation. Le détail complet, les trois priorités et le parcours sont payants.",
      },
      {
        q: "À quelle vitesse le score peut bouger ?",
        a: "Le soin et le style se voient au scan suivant, en quelques jours. Tout ce qui touche à la pousse des cheveux ou à la forme physique avance plus lentement, et le plan le dit.",
      },
      {
        q: "C'est pour qui ?",
        a: "Pour les gens qui préfèrent un diagnostic à un compliment. Pensé pour un public tech qui raisonne déjà en stats, en builds et en arbres d'amélioration.",
      },
    ],
  },
  finalCta: {
    title: "Regarde ce que tu peux améliorer.",
    body: "Une photo, une lecture honnête, un ordre de priorité clair. Tu peux continuer à deviner, ou regarder les données.",
    cta: "Lancer mon scan",
  },
  scan: {
    metaTitle: "Lancer ton scan — Shapr",
    metaDesc:
      "Envoie une photo nette. Shapr lit ta présentation et renvoie des scores, des recommandations et un parcours d'amélioration. Ta photo est effacée après analyse.",
    step1: "Étape 01 — Envoi",
    step1Title: "Une photo. C'est toute la configuration.",
    step1Body:
      "Pas de compte, pas d'e-mail. Envoie une photo nette de ton visage et l'analyse démarre.",
    step2: "Étape 02 — Confirmation",
    step2Title: "C'est bien cette photo ?",
    confirmBody: "De face, bien éclairé, sans lunettes de soleil ? Alors c'est bon.",
    analyzeCta: "Analyser mon visage",
    pickAnother: "Choisir une autre photo",
    tryAnother: "Essayer une autre photo",
    badPhoto: "Cette photo n'a pas fonctionné",
    savedLocal:
      "Ton rapport est gardé sur cet appareil. Crée un compte pour le retrouver partout.",
    savedCloud: "Ton rapport est enregistré dans ton compte.",
    goProgress: "Voir ma progression",
  },
  report: {
    metaTitle: "Mon rapport et ma progression — Shapr",
    metaDesc:
      "Ton rapport d'apparence : scores par catégorie, priorités, parcours, XP et évolution entre les scans.",
    noneLabel: "Aucun scan",
    noneTitle: "Rien à suivre pour l'instant",
    noneBody:
      "Lance ton premier scan et cette page devient ton tableau de progression : historique de score, améliorations terminées et XP.",
    savedOn: (n: number, cloud: boolean) =>
      cloud ? `Scan ${n} · enregistré dans ton compte` : `Scan ${n} · sur cet appareil`,
    title: "Ta progression",
    newScan: "Lancer un nouveau scan",
    first: "Premier scan",
    current: "Scan actuel",
    change: "Évolution",
    changed: "Ce qui a changé :",
    syncTitle: "Garde tes rapports d'un appareil à l'autre",
    syncBody:
      "Crée un compte gratuit et tes scans te suivent partout, au lieu de rester dans ce navigateur.",
    syncCta: "Créer un compte",
  },
  auth: {
    metaTitle: "Compte — Shapr",
    metaDesc:
      "Connecte-toi pour retrouver tes scans, ta progression et ton XP sur tous tes appareils.",
    label: "Compte",
    signInTitle: "Retrouve tes résultats",
    signUpTitle: "Garde tes résultats",
    signInLead: "Connecte-toi pour retrouver tes scans et ta progression.",
    signUpLead:
      "Un compte gratuit conserve tes scans, ton XP et tes améliorations d'un appareil à l'autre.",
    email: "E-mail",
    password: "Mot de passe",
    name: "Prénom ou pseudo",
    signIn: "Se connecter",
    signUp: "Créer mon compte",
    google: "Continuer avec Google",
    toSignUp: "Pas encore de compte ? Créer un compte",
    toSignIn: "Déjà un compte ? Se connecter",
    checkEmail:
      "Vérifie ta boîte mail : on vient d'envoyer un lien de confirmation. Ton compte sera actif dès que tu auras cliqué dessus.",
    working: "Un instant…",
    signedInAs: "Connecté en tant que",
    or: "ou",
  },
  common: {
    startScan: "Lancer mon scan",
    seeExample: "Voir un rapport exemple",
  },
  footer: {
    tagline: "Optimisation de personnage, version vie réelle.",
    product: "Produit",
    runScan: "Lancer un scan",
    exampleReport: "Rapport exemple",
    myProgress: "Ma progression",
    trust: "Confiance",
    privacy: "Confidentialité",
    faq: "FAQ",
    notAdvice: "Pas un avis médical",
    notAdviceBody:
      "Shapr donne un retour sur la présentation, pas un avis médical. Aucune chirurgie, aucun médicament, rien d'invasif.",
    rights: "Pour celles et ceux qui préfèrent les données aux compliments.",
  },
};

type Dict = typeof fr;

const en: Dict = {
  nav: {
    how: "How it works",
    academy: "Academy",
    dashboard: "Dashboard",
    analyze: "What we read",
    pricing: "Pricing",
    example: "Example report",
    scan: "Start my scan",
    progress: "My progress",
    signIn: "Sign in",
    signOut: "Sign out",
    account: "My account",
    menuOpen: "Open menu",
    menuClose: "Close menu",
    home: "Shapr home",
  },
  hero: {
    kicker: "Character optimization for real life",
    title: "Learn",
    titleAccent: "how to look good",
    lead: "One photo. An honest read on twelve parts of how you present, the three changes worth making first, and the order to make them in.",
    dropTitle: "Drop your photo here",
    dropHint: "JPG, PNG or WebP — up to 8 MB. Analysed, then discarded.",
    choose: "Choose a photo",
    preparing: "Preparing…",
    orExample: "See an example report",
    reassure: "No account · Photo deleted after analysis · Never recommends surgery",
    frameLabel: "Analysis frame",
  },
  upload: {
    tipsTitle: "For a proper read",
    tips: [
      "Face clearly visible",
      "Even lighting",
      "No sunglasses",
      "No filters",
      "Looking forward",
      "Sharp, not blurry",
    ],
    privacyNote: "Your photo never leaves the request: no storage, no logs, no URL.",
    errType: "That file type isn't supported. Use a JPG, PNG or WebP photo.",
    errSize: "That photo is over 8 MB. Try a smaller export.",
    errRead: "We couldn't read that image file. Try a different photo.",
  },
  steps: {
    label: "How it works",
    title: "Three steps. Under a minute.",
    items: [
      {
        n: "01",
        title: "Upload",
        body: "One clear, front-facing photo. No account, no email, no fourteen-step onboarding.",
      },
      {
        n: "02",
        title: "Analyze",
        body: "A vision model reads twelve presentation categories and scores what it can actually observe.",
      },
      {
        n: "03",
        title: "Improve",
        body: "You get ranked upgrades and a path — what to change first, and what it's worth.",
      },
    ],
  },
  analyze: {
    label: "What we read",
    title: "Twelve categories, scored separately.",
    intro:
      "Some you can change this week. Some are structural and get treated as fixed — the plan works around them instead of pretending otherwise.",
  },
  potential: {
    label: "Your potential",
    title: "Current you vs. best-presented you.",
    intro:
      "Potential here means one thing only: the same face, presented properly. Better haircut, better grooming, better frames, better fit, better photos. No biology promises.",
    currentLabel: "Current",
    currentBody:
      "Default settings: whatever haircut you last got, whatever you grabbed off the chair this morning.",
    ceilingLabel: "Presentation ceiling",
    ceilingBody:
      "Same bone structure, same everything. Just every controllable variable actually dialled in.",
  },
  example: {
    label: "Example report",
    title: "What you actually receive.",
    intro: "Not a number and a shrug. A breakdown you can act on tonight.",
    upgrade: "Upgrade",
    impact: "impact",
    readFull: "Read the full example report",
    sampleLabel: "Sample data",
    sampleBody: "A demonstration report for a fictional user, not a real analysis.",
    scanCta: "Scan my face",
  },
  progression: {
    label: "Progression",
    title: "Re-scan. Watch the number move.",
    intro:
      "Every completed upgrade is XP. Every re-scan is a checkpoint. Progress you can see beats motivation you have to manufacture.",
    xpTitle: "Appearance XP",
    xpBody: "Complete a mission from your path, bank the XP, level up.",
    firstLabel: "FIRST 6.1",
    currentLabel: "CURRENT 6.8",
    compareBody: "Scan comparison, side by side, with what changed.",
    achievementsTitle: "Achievements",
    achievementsBody:
      "First Scan. Hair Upgrade. Style Upgrade. New Personal Best. Earned, not handed out.",
  },
  privacy: {
    label: "Privacy",
    title: "Your photo is analysed, then deleted.",
    intro:
      "It lives for the length of one request. No storage, no logging, no permanent URL, no facial data in analytics.",
    chipDeleted: "Deleted after analysis",
    chipNeverLogged: "Never logged or shared",
    readMore: "Read the full detail",
    pageLead:
      "A face photo is sensitive data. We treat it that way: it exists for the length of one request and nothing longer.",
    points: [
      {
        title: "Analysed in memory",
        body: "Your photo travels in a single request, is read by the vision model, and is gone when the response returns. It is never written to a database or a disk.",
      },
      {
        title: "Deleted after analysis",
        body: "There is no photo history, no gallery, no backup. Only the derived report — numbers and text — persists, on your device or in your account if you create one.",
      },
      {
        title: "Never logged, never public",
        body: "Images are excluded from server logs and error reports, and no permanent public URL to your photo is ever created.",
      },
      {
        title: "No facial data in analytics",
        body: "Product analytics record events like 'scan completed'. Photos, image bytes and facial measurements never reach a third party.",
      },
    ],
    checksTitle: "What we check on upload",
    checks: [
      "File type verified server-side (JPG, PNG, WebP only)",
      "Size capped at 8 MB, minimum resolution enforced",
      "Rate limiting per network address",
      "All validation repeated on the server, never trusted from the browser",
      "AI keys live only on the server and are never exposed to your browser",
    ],
  },
  pricing: {
    label: "Pricing",
    title: "Scan free. Pay only for the plan.",
    intro:
      "You see your score before you spend anything. That's the honest order of operations.",
    freeLabel: "Free scan",
    freeItems: ["Overall score and percentile", "Three category read-outs", "One recommendation"],
    fullLabel: "Full report",
    fullItems: [
      "All twelve categories, in detail",
      "Your top three upgrades, ranked",
      "The full upgrade path",
      "Re-scan comparison and XP tracking",
    ],
    fullCta: "Scan, then unlock",
  },
  faq: {
    label: "FAQ",
    title: "The questions people actually ask.",
    items: [
      {
        q: "Is this just a hot-or-not score?",
        a: "No. The score exists to give you a baseline. The value is in the twelve category read-outs and the ordered list of what to change first.",
      },
      {
        q: "Is the score objective?",
        a: "It isn't scientific truth, and we won't pretend otherwise. It's a structured read of how you currently present, based on patterns the model can observe in your photo.",
      },
      {
        q: "Will it tell me to get surgery?",
        a: "Never. Shapr doesn't recommend surgery, medication, extreme diets or anything invasive. Structural traits get flagged as fixed and the plan optimises around them.",
      },
      {
        q: "What happens to my photo?",
        a: "It's analysed inside a single request and then dropped. No storage, no logging, no public URL, no photo history.",
      },
      {
        q: "Do I need an account?",
        a: "Not for your first scan. Your report is saved in your browser. Accounts exist for keeping history across devices.",
      },
      {
        q: "What do I get for free?",
        a: "Your overall score, percentile, three category read-outs and one recommendation. The full breakdown, top three upgrades and the upgrade path are paid.",
      },
      {
        q: "How fast can the score actually move?",
        a: "Grooming and style changes show up in your next scan within days. Anything involving hair growth or fitness moves on a slower clock and the plan says so.",
      },
      {
        q: "Who is this for?",
        a: "People who'd rather have a diagnostic than a compliment. Built for a tech-leaning crowd that already thinks in stats, builds and upgrade paths.",
      },
    ],
  },
  finalCta: {
    title: "See what you can improve.",
    body: "One photo, one honest read-out, one clear order of operations. You can keep guessing, or you can look at the data.",
    cta: "Start my scan",
  },
  scan: {
    metaTitle: "Run your scan — Shapr",
    metaDesc:
      "Upload one clear photo. Shapr reads your presentation and returns scores, recommendations and an upgrade path. Your photo is deleted after analysis.",
    step1: "Step 01 — Upload",
    step1Title: "One photo. That's the whole setup.",
    step1Body:
      "No account, no email. Upload a clear photo of your face and the analysis starts immediately.",
    step2: "Step 02 — Confirm",
    step2Title: "Is this the photo?",
    confirmBody: "Face front-on, well lit, no sunglasses? Then you're good.",
    analyzeCta: "Analyze my face",
    pickAnother: "Pick another photo",
    tryAnother: "Try another photo",
    badPhoto: "That photo didn't work",
    savedLocal:
      "Your report is saved on this device. Create an account to keep it everywhere.",
    savedCloud: "Your report is saved to your account.",
    goProgress: "Go to my progress",
  },
  report: {
    metaTitle: "My report & progress — Shapr",
    metaDesc:
      "Your saved appearance report: category scores, top upgrades, the upgrade path, XP and score changes between scans.",
    noneLabel: "No scan yet",
    noneTitle: "Nothing to track yet",
    noneBody:
      "Run your first scan and this becomes your progress dashboard: score history, completed upgrades and XP.",
    savedOn: (n: number, cloud: boolean) =>
      cloud ? `Scan ${n} · saved to your account` : `Scan ${n} · saved on this device`,
    title: "Your progress",
    newScan: "Run a new scan",
    first: "First scan",
    current: "Current scan",
    change: "Change",
    changed: "What changed:",
    syncTitle: "Keep your reports across devices",
    syncBody:
      "Create a free account and your scans follow you anywhere, instead of living in this browser.",
    syncCta: "Create an account",
  },
  auth: {
    metaTitle: "Account — Shapr",
    metaDesc:
      "Sign in to keep your scans, progress and XP across all of your devices.",
    label: "Account",
    signInTitle: "Get your results back",
    signUpTitle: "Keep your results",
    signInLead: "Sign in to find your scans and your progress again.",
    signUpLead:
      "A free account keeps your scans, XP and upgrades across devices.",
    email: "Email",
    password: "Password",
    name: "First name or handle",
    signIn: "Sign in",
    signUp: "Create my account",
    google: "Continue with Google",
    toSignUp: "No account yet? Create one",
    toSignIn: "Already have an account? Sign in",
    checkEmail:
      "Check your inbox: we just sent a confirmation link. Your account is active as soon as you click it.",
    working: "One moment…",
    signedInAs: "Signed in as",
    or: "or",
  },
  common: {
    startScan: "Start my scan",
    seeExample: "See an example report",
  },
  footer: {
    tagline: "Character optimization for real life.",
    product: "Product",
    runScan: "Run a scan",
    exampleReport: "Example report",
    myProgress: "My progress",
    trust: "Trust",
    privacy: "Privacy",
    faq: "FAQ",
    notAdvice: "Not advice",
    notAdviceBody:
      "Shapr gives presentation feedback, not medical advice. It never recommends surgery, medication or anything invasive.",
    rights: "Built for people who'd rather have data than compliments.",
  },
};

const DICTS: Record<Lang, Dict> = { fr, en };

export function dict(lang: Lang): Dict {
  return DICTS[lang];
}
