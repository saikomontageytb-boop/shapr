import { SAMPLE_ANALYSIS } from "./sample-report";
import { SAMPLE_ANALYSIS_FR } from "./sample-report-fr";
import { useLang } from "./use-lang";

/** The demo report in the visitor's language. */
export function useSample() {
  return useLang() === "fr" ? SAMPLE_ANALYSIS_FR : SAMPLE_ANALYSIS;
}
