import type { Lang } from "./i18n";
import type { Track } from "./academy-types";

/**
 * The modules are grouped into a handful of big themes so the academy reads
 * like a set of categories with sub-categories rather than one long list.
 */
export interface Family {
  id: string;
  title: Record<Lang, string>;
  blurb: Record<Lang, string>;
  tracks: string[];
}

export const FAMILIES: Family[] = [
  {
    id: "body",
    title: { fr: "Musculature & performance", en: "Muscle & performance" },
    blurb: {
      fr: "Entraînement, souffle, silhouette et ce que tu mets dans l'assiette autour des séances.",
      en: "Training, conditioning, body shape and what you eat around your sessions.",
    },
    tracks: ["training", "cardio", "body", "mobility", "sportnutrition"],
  },
  {
    id: "fuel",
    title: { fr: "Nutrition & santé interne", en: "Nutrition & inner health" },
    blurb: {
      fr: "Ce que tu manges tous les jours, les compléments qui servent, tes hormones.",
      en: "Everyday food, the supplements that matter, your hormones.",
    },
    tracks: ["nutrition", "supplements", "hormones"],
  },
  {
    id: "face",
    title: { fr: "Visage & peau", en: "Face & skin" },
    blurb: {
      fr: "Le premier truc qu'on regarde : peau, traits, dents, regard.",
      en: "The first thing anyone looks at: skin, features, teeth, eyes.",
    },
    tracks: ["face", "skin", "teeth", "eyes"],
  },
  {
    id: "grooming",
    title: { fr: "Cheveux, barbe & soins", en: "Hair, beard & grooming" },
    blurb: {
      fr: "Coupe, barbe, hygiène et odeur — la partie la plus rentable.",
      en: "Cut, beard, hygiene and scent — the highest-return part.",
    },
    tracks: ["hair", "beard", "grooming", "fragrance"],
  },
  {
    id: "image",
    title: { fr: "Style & image", en: "Style & image" },
    blurb: {
      fr: "Les vêtements qui te vont et les photos qui te ressemblent.",
      en: "Clothes that fit you and photos that look like you.",
    },
    tracks: ["style", "photo"],
  },
  {
    id: "energy",
    title: { fr: "Énergie & mental", en: "Energy & mindset" },
    blurb: {
      fr: "Sommeil, stress, habitudes et tête froide : ce qui rend tout le reste possible.",
      en: "Sleep, stress, habits and a clear head: what makes the rest possible.",
    },
    tracks: ["sleep", "stress", "habits", "mind"],
  },
  {
    id: "presence",
    title: { fr: "Présence & social", en: "Presence & social" },
    blurb: {
      fr: "Posture, voix, aisance sociale et rencontres.",
      en: "Posture, voice, social ease and dating.",
    },
    tracks: ["posture", "voice", "social", "seduction"],
  },
];

/** Families filled with the tracks that actually exist, plus any leftovers. */
export function groupTracks(tracks: Track[]) {
  const byId = new Map(tracks.map((t) => [t.id, t]));
  const used = new Set<string>();

  const groups = FAMILIES.map((family) => {
    const items = family.tracks
      .map((id) => byId.get(id))
      .filter((t): t is Track => Boolean(t));
    items.forEach((t) => used.add(t.id));
    return { family, tracks: items };
  }).filter((g) => g.tracks.length > 0);

  const rest = tracks.filter((t) => !used.has(t.id));
  return { groups, rest };
}
