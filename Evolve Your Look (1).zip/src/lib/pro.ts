import { useAccount } from "./account";

/**
 * Shapr Pro membership. It belongs to the account, never to the device:
 * signing out or refreshing without a session always yields a free member.
 */
export const PRO_PRICE = "4,99 €";
export const PRO_PRICE_EN = "€4.99";
/** Scans included before Pro is required. */
export const FREE_SCANS = 1;

export function useIsPro(): boolean {
  return useAccount().pro;
}

/** Turns the subscription on or off for the signed-in account. */
export function useSetPro(): (on: boolean) => Promise<void> {
  return useAccount().setPro;
}
