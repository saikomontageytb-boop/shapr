import { lessonKey } from "./academy-types";

/**
 * The three lessons everyone can read without a subscription. They are always
 * the same three — one for the body, one for the face, one for the head — so
 * the free tier is identical for every member.
 */
export const FREE_LESSON_KEYS: readonly string[] = [
  lessonKey("nutrition", "nutrition-1"),
  lessonKey("training", "training-1"),
  lessonKey("skin", "skin-1"),
];

export const FREE_LESSON_COUNT = FREE_LESSON_KEYS.length;

export function isFreeLesson(key: string): boolean {
  return FREE_LESSON_KEYS.includes(key);
}
