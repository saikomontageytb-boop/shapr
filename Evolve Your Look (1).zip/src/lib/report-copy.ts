import { useLang } from "./use-lang";
import type { Lang } from "./i18n";

/** Static strings used by the report and scanning components. */
const COPY = {
  fr: {
    profile: "Ton profil d'apparence",
    outOf: "sur 10",
    percentile: "Centile",
    percentileSuffix: "e",
    potential: "Potentiel d'amélioration",
    potentialNote:
      "Estimé uniquement à partir de changements de présentation — cheveux, soin, peau, lunettes et style. L'ossature est traitée comme fixe : on compose avec, on ne la change pas.",
    categoryScores: "Scores par catégorie",
    categoryScoresIntro:
      "Douze lectures. Les traits structurels sont notés mais jamais présentés comme des choses à corriger.",
    detailed: "Analyse détaillée",
    moreLocked: (n: number) =>
      `${n} catégories supplémentaires sont dans le rapport complet.`,
    observation: "Observation",
    whyMatters: "Pourquoi ça compte",
    recommendation: "Recommandation",
    presentAround: "Comment composer avec",
    structural: "structurel",
    priority: "priorité",
    topUpgrades: "Tes améliorations prioritaires",
    topUpgradesIntro:
      "Classées selon ce qu'elles peuvent réellement changer à ta présentation.",
    impact: { high: "Fort impact", medium: "Impact moyen", low: "Impact faible" },
    upgradePath: "Ton parcours d'amélioration",
    upgradePathIntro:
      "De haut en bas. Chaque niveau s'appuie sur le précédent.",
    level: "Niveau",
    done: "faites",
    tracks: "Pistes de transformation",
    tracksIntro:
      "Les directions concrètes à tester, piste par piste. Les aperçus visuels arriveront quand la génération d'image sera activée — d'ici là, ce sont des directions écrites, pas des maquettes.",
    trackLabels: {
      hair: "Cheveux",
      eyewear: "Lunettes",
      facial_hair: "Barbe",
      style: "Style",
    },
    nothingToChange: "Rien à changer ici pour l'instant.",
    readThis: "À lire",
    disclaimer:
      "Ces scores sont indicatifs, pas des faits scientifiques. Shapr ne recommande jamais de chirurgie, de médicaments ni rien d'invasif, et ne donne pas d'avis médical. Pour ta peau ou ta santé, parle à un professionnel.",
    xp: "XP d'apparence",
    levelShort: "Niveau",
    upgradesDone: "Améliorations faites",
    currentScore: "Score actuel",
    scans: "Scans",
    sinceFirst: "Depuis le premier scan",
    achievements: "Succès",
    scanning: "Analyse",
    scanningTitle: "Lecture de ta présentation",
    scanSteps: [
      "Lecture de la structure du visage",
      "Mesure des proportions",
      "Vérification de la symétrie",
      "Analyse des cheveux",
      "Analyse de la peau",
      "Analyse du soin",
      "Lecture des lunettes et du style",
      "Construction de ton parcours",
    ],
    scanningNote: "Ça prend en général 10 à 25 secondes. Garde l'onglet ouvert.",
  },
  en: {
    profile: "Your appearance profile",
    outOf: "out of 10",
    percentile: "Percentile",
    percentileSuffix: "th",
    potential: "Improvement potential",
    potentialNote:
      "Estimated from presentation changes only — hair, grooming, skin habits, eyewear and style. Bone structure is treated as fixed and worked around, never changed.",
    categoryScores: "Category scores",
    categoryScoresIntro:
      "Twelve read-outs. Structural traits are scored but never treated as things to fix.",
    detailed: "Detailed breakdown",
    moreLocked: (n: number) => `${n} more categories are in the full report.`,
    observation: "Observation",
    whyMatters: "Why it matters",
    recommendation: "Recommendation",
    presentAround: "How to present around it",
    structural: "structural",
    priority: "priority",
    topUpgrades: "Your top upgrades",
    topUpgradesIntro:
      "Ordered by how much they can realistically move your presentation.",
    impact: { high: "High impact", medium: "Medium impact", low: "Low impact" },
    upgradePath: "Your upgrade path",
    upgradePathIntro: "Work top to bottom. Each level compounds on the one before it.",
    level: "Level",
    done: "done",
    tracks: "Transformation tracks",
    tracksIntro:
      "The specific directions worth trying, per track. Visual previews arrive when image generation is enabled — until then these are written directions, not mockups.",
    trackLabels: {
      hair: "Hair",
      eyewear: "Glasses",
      facial_hair: "Facial hair",
      style: "Style",
    },
    nothingToChange: "Nothing to change here right now.",
    readThis: "Read this",
    disclaimer:
      "These scores are indicative, not scientific fact. Shapr never recommends surgery, medication or anything invasive, and it does not give medical advice. For anything about your skin or health, talk to a professional.",
    xp: "Appearance XP",
    levelShort: "Level",
    upgradesDone: "Upgrades done",
    currentScore: "Current score",
    scans: "Scans",
    sinceFirst: "Since first scan",
    achievements: "Achievements",
    scanning: "Scanning",
    scanningTitle: "Reading your presentation",
    scanSteps: [
      "Reading facial structure",
      "Measuring proportions",
      "Checking symmetry",
      "Analysing hair",
      "Analysing skin",
      "Analysing grooming",
      "Reading eyewear and style",
      "Building your upgrade path",
    ],
    scanningNote: "This usually takes 10–25 seconds. Keep the tab open.",
  },
} satisfies Record<Lang, unknown>;

export function useReportCopy() {
  return COPY[useLang()];
}
