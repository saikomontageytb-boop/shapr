import { ACADEMY, lessonKey } from "./academy";
import { levelInfo } from "./levels";
import type { Analysis, ScanRecord } from "./analysis-schema";

/**
 * Progress shapes and pure helpers. Nothing is stored on the device: scans,
 * quests and lessons all live on the account and are loaded from there.
 */

export interface ProgressState {
  scans: ScanRecord[];
  completedQuests: string[];
  achievements: string[];
  unlocked: boolean;
}

export const EMPTY_PROGRESS: ProgressState = {
  scans: [],
  completedQuests: [],
  achievements: [],
  unlocked: false,
};


export function addScan(state: ProgressState, analysis: Analysis): ProgressState {
  const record: ScanRecord = {
    id: `scan_${Date.now()}`,
    created_at: new Date().toISOString(),
    analysis,
  };
  return {
    ...state,
    scans: [...state.scans, record],
    achievements: Array.from(
      new Set([
        ...state.achievements,
        "first_scan",
        ...(state.scans.length ? ["rescan"] : []),
      ]),
    ),
  };
}

export function toggleQuest(state: ProgressState, id: string): ProgressState {
  const done = state.completedQuests.includes(id);
  const completedQuests = done
    ? state.completedQuests.filter((q) => q !== id)
    : [...state.completedQuests, id];
  const achievements = new Set(state.achievements);
  if (!done) achievements.add("first_upgrade");
  if (completedQuests.length >= 5) achievements.add("five_upgrades");
  return { ...state, completedQuests, achievements: [...achievements] };
}

export function latestScan(state: ProgressState): ScanRecord | null {
  return state.scans.length ? state.scans[state.scans.length - 1]! : null;
}

export function xpFor(state: ProgressState, analysis: Analysis | null): number {
  if (!analysis) return 0;
  const all = analysis.roadmap.flatMap((l) => l.quests);
  const questXp = all
    .filter((q) => state.completedQuests.includes(q.id))
    .reduce((sum, q) => sum + q.xp, 0);
  const lessonXp = (analysis.annotations ?? [])
    .filter((a) => state.completedQuests.includes(`lesson:${a.id}`))
    .reduce((sum, a) => sum + a.xp, 0);
  return questXp + lessonXp;
}


export function levelFor(xp: number) {
  return levelInfo(xp);
}

export const ACHIEVEMENTS: Record<string, { title: string; detail: string }> = {
  first_scan: { title: "First Scan", detail: "You looked at the data." },
  first_upgrade: { title: "First Upgrade", detail: "One quest cleared." },
  five_upgrades: { title: "Momentum", detail: "Five quests cleared." },
  rescan: { title: "Re-scan", detail: "You came back with proof." },
  personal_best: { title: "New Personal Best", detail: "Your best score yet." },
};

/* ---------------------------------------------------------------------------
 * Academy: theme modules with short lessons. Stored on the account so one XP
 * number covers everything the user actually did.
 * ------------------------------------------------------------------------ */

export interface AcademyState {
  /** `academy:<track>:<lesson>` keys. */
  completedLessons: string[];
  /** ISO yyyy-mm-dd days with at least one completed lesson. */
  days: string[];
  /** Extra XP earned from correct in-lesson answers, per lesson key. */
  bonus: Record<string, number>;
}

export const EMPTY_ACADEMY: AcademyState = { completedLessons: [], days: [], bonus: {} };

/** Consecutive days ending today or yesterday. */
export function streakFor(state: AcademyState): number {
  if (!state.days.length) return 0;
  const set = new Set(state.days);
  const day = new Date();
  if (!set.has(day.toISOString().slice(0, 10))) {
    day.setDate(day.getDate() - 1);
    if (!set.has(day.toISOString().slice(0, 10))) return 0;
  }
  let streak = 0;
  while (set.has(day.toISOString().slice(0, 10))) {
    streak += 1;
    day.setDate(day.getDate() - 1);
  }
  return streak;
}

/** XP earned in the academy, read from the lesson catalogue. */
export function academyXp(state: AcademyState): number {
  let xp = 0;
  for (const track of ACADEMY.fr) {
    for (const lesson of track.lessons) {
      const key = lessonKey(track.id, lesson.id);
      if (state.completedLessons.includes(key)) xp += lesson.xp + (state.bonus?.[key] ?? 0);
    }
  }
  return xp;
}
