import type { Analysis } from "./analysis-schema";

/** Clearly-labelled demo data used only on the public example report and hero mock. */
export const SAMPLE_ANALYSIS: Analysis = {
  overall_score: 6.4,
  potential_score: 7.5,
  percentile: 58,
  headline: "Solid base, under-optimised presentation",
  summary:
    "Your features read balanced, but the current haircut and grooming are working against you. The fastest gains here are hair volume, brow cleanup and a skincare routine — none of it requires changing anything structural.",
  categories: [
    {
      key: "face_shape",
      score: 6.8,
      observation:
        "Your face reads slightly longer than it is wide, with a moderately narrow upper third.",
      why_it_matters:
        "Face shape decides which haircuts and glasses frames sit well on you.",
      recommendation:
        "Favour cuts with width on the sides and restrained height on top; avoid tall quiffs that lengthen the face further.",
      priority: "medium",
      fixed_trait: true,
    },
    {
      key: "symmetry",
      score: 7.0,
      observation:
        "Left and right sides track closely; the right brow sits marginally higher.",
      why_it_matters: "Minor asymmetry is normal and largely invisible in motion.",
      recommendation:
        "Nothing to change. When taking photos, your left three-quarter angle reads best.",
      priority: "low",
      fixed_trait: true,
    },
    {
      key: "jawline",
      score: 6.1,
      observation:
        "Jaw outline is visible but softened along the lower cheek and under the chin.",
      why_it_matters: "Jaw definition drives a lot of the perceived 'sharpness' of a face.",
      recommendation:
        "Lower body fat and reduced sodium/alcohol sharpen this over months. A short, faded beard along the jaw adds definition immediately.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "eyes",
      score: 7.4,
      observation: "Eyes are your strongest feature: good spacing, clear whites.",
      why_it_matters: "Eyes are where people look first in conversation and in photos.",
      recommendation:
        "Protect them: consistent sleep and less late-night screen time reduce the under-eye shadowing visible here.",
      priority: "low",
      fixed_trait: true,
    },
    {
      key: "eyebrows",
      score: 5.6,
      observation:
        "Brows are dense with stray hairs above the arch and between the brows.",
      why_it_matters: "Brows frame the eyes; untidy ones drag down an otherwise strong area.",
      recommendation:
        "A 10-minute cleanup — the space between the brows and above the arch only. Keep the natural shape.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "nose",
      score: 6.5,
      observation: "Straight bridge, proportionate width relative to eye spacing.",
      why_it_matters: "The nose anchors the centre of the face.",
      recommendation:
        "No changes needed. Frames with a slightly higher bridge keep glasses from crowding it.",
      priority: "low",
      fixed_trait: true,
    },
    {
      key: "skin",
      score: 6.0,
      observation:
        "Visible shine across the forehead and nose, some texture on the cheeks.",
      why_it_matters: "Skin quality is the single most noticeable modifiable trait.",
      recommendation:
        "Gentle cleanser morning and night, a light moisturiser, daily SPF 30+. Give it eight weeks. See a dermatologist for anything persistent.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "hair",
      score: 5.8,
      observation:
        "Current cut is uniform in length and adds width around the upper sides of the head.",
      why_it_matters: "Hair changes the perceived shape of your whole face in one appointment.",
      recommendation:
        "Ask for shorter, tapered sides with more volume kept on top and a soft texture on the fringe. Bring a photo; don't ask for 'the usual'.",
      priority: "high",
      fixed_trait: false,
    },
    {
      key: "facial_hair",
      score: 5.4,
      observation: "Patchy short stubble with an undefined neckline.",
      why_it_matters: "A defined neckline is the difference between designed and neglected.",
      recommendation:
        "Keep stubble at 3-5 mm, shave the neck to two fingers above the Adam's apple, and clean the cheek line.",
      priority: "medium",
      fixed_trait: false,
    },
    {
      key: "eyewear",
      score: 6.2,
      observation: "Current frames are narrow relative to the width of your face.",
      why_it_matters: "Frames either balance the face or shrink it.",
      recommendation:
        "Try slightly wider frames with a flat or keyhole bridge; the frame should end near the outer edge of your face.",
      priority: "medium",
      fixed_trait: false,
    },
    {
      key: "style",
      score: 6.0,
      observation: "Visible top is loose through the shoulders and neckline.",
      why_it_matters: "Fit at the shoulders reads before colour, brand or anything else.",
      recommendation:
        "Build around well-fitting basics in colours that contrast with your skin tone. Shoulder seam sits on the shoulder bone.",
      priority: "medium",
      fixed_trait: false,
    },
    {
      key: "proportions",
      score: 6.6,
      observation: "Facial thirds are close to even, with a slightly longer lower third.",
      why_it_matters: "Proportion decides how much visual height a hairstyle should add.",
      recommendation:
        "Keep hair volume moderate and avoid heavy beards that extend the chin further.",
      priority: "low",
      fixed_trait: true,
    },
  ],
  priority_actions: [
    {
      title: "Change the haircut",
      category: "hair",
      impact: "high",
      why: "Your current cut widens the upper sides and flattens the top.",
      action:
        "Book a barber this week and ask for tapered sides with volume kept on top.",
    },
    {
      title: "Start a skincare routine",
      category: "skin",
      impact: "high",
      why: "Shine and texture are the most visible modifiable traits in your photo.",
      action: "Cleanser, moisturiser, SPF. Same order, every day, for eight weeks.",
    },
    {
      title: "Clean up brows and neckline",
      category: "eyebrows",
      impact: "medium",
      why: "Two tidy edges make the whole face look intentional.",
      action: "Remove strays between the brows and set a beard neckline tonight.",
    },
  ],
  roadmap: [
    {
      level: 1,
      title: "FOUNDATION",
      focus: "Cheap, fast, high-impact fixes.",
      quests: [
        {
          id: "haircut-upgrade",
          title: "Get the tapered cut",
          category: "hair",
          difficulty: "easy",
          impact: "high",
          xp: 200,
        },
        {
          id: "skincare-start",
          title: "Build the 3-step routine",
          category: "skin",
          difficulty: "easy",
          impact: "high",
          xp: 180,
        },
        {
          id: "brow-cleanup",
          title: "Clean up the brows",
          category: "eyebrows",
          difficulty: "easy",
          impact: "medium",
          xp: 120,
        },
        {
          id: "sleep-baseline",
          title: "Hit 7h sleep for 14 nights",
          category: "skin",
          difficulty: "medium",
          impact: "medium",
          xp: 160,
        },
      ],
    },
    {
      level: 2,
      title: "GROOMING",
      focus: "Sharpen every edge of the face.",
      quests: [
        {
          id: "beard-neckline",
          title: "Set a proper beard neckline",
          category: "facial_hair",
          difficulty: "easy",
          impact: "medium",
          xp: 120,
        },
        {
          id: "frame-swap",
          title: "Try three wider frame shapes",
          category: "eyewear",
          difficulty: "medium",
          impact: "medium",
          xp: 150,
        },
        {
          id: "jaw-habits",
          title: "Cut late-night sodium and alcohol",
          category: "jawline",
          difficulty: "medium",
          impact: "high",
          xp: 200,
        },
      ],
    },
    {
      level: 3,
      title: "STYLE",
      focus: "Make the rest of the frame match the face.",
      quests: [
        {
          id: "fit-basics",
          title: "Replace 3 badly-fitting basics",
          category: "style",
          difficulty: "medium",
          impact: "high",
          xp: 220,
        },
        {
          id: "color-palette",
          title: "Lock a 4-colour palette",
          category: "style",
          difficulty: "easy",
          impact: "medium",
          xp: 140,
        },
        {
          id: "signature-piece",
          title: "Find one signature piece",
          category: "style",
          difficulty: "hard",
          impact: "medium",
          xp: 260,
        },
      ],
    },
  ],
  annotations: [
    {
      id: "brow-gap",
      x: 50,
      y: 34,
      label: "Brow gap",
      category: "eyebrows",
      severity: "high",
      observation: "Stray hairs bridge the two brows and blur the read of your eyes.",
      fix: "Tweeze the space between the brows only, every ten days.",
      xp: 60,
      lesson: {
        title: "Clean the brow line without ruining it",
        steps: [
          {
            title: "Find the border",
            body: "Hold a pencil vertically against your nostril. The brow should start there — anything inside that line can go.",
          },
          {
            title: "Tweeze after a shower",
            body: "Skin is soft, hairs come out at the root, and redness fades within twenty minutes.",
          },
          {
            title: "Never touch the top",
            body: "The upper edge carries the shape. Only the gap and isolated low strays get removed.",
          },
        ],
        tip: "Two minutes every two weeks is enough. More than that and you lose the thickness that reads as strong.",
        quiz: {
          question: "Which area should you never tweeze?",
          options: ["The brow gap", "Above the brow", "Below the low arch"],
          answer_index: 1,
          explanation:
            "The top edge defines the natural arch; removing it thins the brow and softens the whole face.",
        },
      },
    },
    {
      id: "jaw-line",
      x: 30,
      y: 74,
      label: "Jaw outline",
      category: "jawline",
      severity: "high",
      observation:
        "The line is readable but softens under the cheek — water retention plus a light fat layer.",
      fix: "Consistent sleep, less salt and alcohol, a small calorie deficit if needed.",
      xp: 120,
      lesson: {
        title: "Making a jawline readable",
        steps: [
          {
            title: "Body fat comes first",
            body: "Under roughly 15% for men, the line shows on its own. No facial exercise substitutes for that.",
          },
          {
            title: "Cut water retention",
            body: "Less salt at night, 2 L of water a day, limited alcohol — the lower face de-puffs in one to two weeks.",
          },
          {
            title: "Sleep on your back",
            body: "Face-down sleeping compresses the face and worsens morning puffiness.",
          },
        ],
        tip: "A short faded beard along the jaw gives the same visual effect immediately.",
        quiz: {
          question: "What changes jaw appearance fastest?",
          options: ["Chewing hard gum", "Cutting salt and alcohol", "Daily jaw exercises"],
          answer_index: 1,
          explanation:
            "Water retention clears in days. Masseter training barely moves the outline of the face.",
        },
      },
    },
    {
      id: "under-eye",
      x: 62,
      y: 43,
      label: "Under-eye shadow",
      category: "eyes",
      severity: "medium",
      observation: "Blue-toned shadow under the eye, typical of chronic short sleep.",
      fix: "7.5–8 hours of sleep, screens off an hour before, a hydrating eye cream twice daily.",
      xp: 80,
      lesson: {
        title: "Know your dark circles",
        steps: [
          {
            title: "Identify the type",
            body: "Blue-purple is vascular (sleep, hydration). Brown is pigmentary (sun, genetics). Hollow is structural.",
          },
          {
            title: "Pull the right lever",
            body: "Vascular: sleep and salt. Pigmentary: daily sunscreen. Hollow: lighting and hair, not creams.",
          },
        ],
        tip: "Thirty seconds of cold on the eye area in the morning cuts puffiness for free.",
        quiz: {
          question: "Brown under-eye circles respond most to…",
          options: ["More sleep", "Sunscreen", "Coffee"],
          answer_index: 1,
          explanation:
            "Brown circles are pigment: sun keeps them going, daily protection fades them.",
        },
      },
    },
    {
      id: "hairline-volume",
      x: 50,
      y: 14,
      label: "Volume and hairline",
      category: "hair",
      severity: "high",
      observation: "Hair falls flat and compresses the upper third of your face.",
      fix: "Shorter sides, kept length on top, blow-dry roots upward.",
      xp: 100,
      lesson: {
        title: "Volume is a free upgrade",
        steps: [
          {
            title: "Dry upside down",
            body: "Thirty seconds head-down on warm air lifts the roots and holds all day.",
          },
          {
            title: "Light product, no heavy gel",
            body: "Texture powder or matte paste gives body without the shiny helmet look.",
          },
          {
            title: "Ask for a cut, not 'the usual'",
            body: "Short faded sides with length kept on top makes the face read taller and the jaw wider.",
          },
        ],
        tip: "Volume on top does more for face shape than any product you can buy.",
        quiz: {
          question: "Which drying method holds volume?",
          options: ["Very hot air", "Warm air then a cool shot", "Towel drying only"],
          answer_index: 1,
          explanation:
            "The cool shot sets the shape; very hot air damages hair and it drops again.",
        },
      },
    },
    {
      id: "skin-texture",
      x: 72,
      y: 55,
      label: "Skin texture",
      category: "skin",
      severity: "medium",
      observation: "Shine across the T-zone and visible pores on the upper cheeks.",
      fix: "Gentle cleanser morning and night, light moisturiser, SPF 30 every morning.",
      xp: 90,
      lesson: {
        title: "The minimum routine that works",
        steps: [
          {
            title: "Three products, not ten",
            body: "Gentle cleanser, non-comedogenic moisturiser, sunscreen. Everything else is optional.",
          },
          {
            title: "One active at a time",
            body: "Retinol at night, twice a week to start. Add a new active every four weeks at most.",
          },
          {
            title: "Sun is factor number one",
            body: "Unprotected exposure affects texture and ageing more than every serum combined.",
          },
        ],
        tip: "Skin takes six to eight weeks to respond. Switch routines faster and you learn nothing.",
        quiz: {
          question: "Which product has the biggest long-term effect?",
          options: ["Vitamin C serum", "Daily sunscreen", "A scrub"],
          answer_index: 1,
          explanation:
            "Daily sun protection is the only habit consistently proven for texture and ageing.",
        },
      },
    },
    {
      id: "beard-line",
      x: 50,
      y: 86,
      label: "Neckline",
      category: "facial_hair",
      severity: "medium",
      observation: "The beard runs too far down the neck and erases the chin border.",
      fix: "Set the line two fingers above the Adam's apple, curved, never straight across.",
      xp: 70,
      lesson: {
        title: "Placing your beard neckline",
        steps: [
          {
            title: "Find the point",
            body: "Two fingers above the Adam's apple — that is the height of the lower border.",
          },
          {
            title: "Follow a U curve",
            body: "Connect that point to the two corners behind the jaw. A straight line looks pasted on.",
          },
        ],
        tip: "A short beard with a clean border beats a long beard with a messy one every time.",
        quiz: {
          question: "Where does a beard neckline sit?",
          options: [
            "Under the chin, on the bone",
            "Two fingers above the Adam's apple",
            "At the collar",
          ],
          answer_index: 1,
          explanation:
            "Higher erases the chin; lower blends the beard into the neck.",
        },
      },
    },
  ],
  protocols: [
    {
      id: "nutrition",
      title: "Nutrition — the base layer of facial composition",
      why: "Body fat and inflammation decide jaw definition, facial puffiness and skin clarity.",
      steps: [
        "1.6–2 g of protein per kg of bodyweight, spread across the day.",
        "Vegetables and fruit at every meal for micronutrients (zinc, vitamin A, vitamin C).",
        "Fatty fish twice a week or a steady omega-3 source.",
        "Moderate salt at night and 2 L of water a day to limit retention.",
        "A small calorie deficit (200–400 kcal) if a fat layer is hiding your structure.",
      ],
      avoid: [
        "Crash diets — they hollow the face and wreck the skin.",
        "Frequent alcohol — water retention, dull tone, broken sleep.",
      ],
      timeline: "Visible in the face in 4–8 weeks.",
    },
    {
      id: "hormones",
      title: "Hormones — natural levers only",
      why: "Sleep, training, body fat and micronutrients support a healthy hormonal profile, which shows up in skin, beard growth and facial fullness.",
      steps: [
        "Sleep 7.5–9 hours: the strongest and cheapest hormonal lever there is.",
        "Heavy resistance training 3–4 times a week, compound movements.",
        "Keep body fat in a healthy range — too high and too low both hurt.",
        "Cover zinc, magnesium and vitamin D through food and sunlight; test before supplementing.",
        "Cut chronic stress: sustained cortisol works against everything else.",
      ],
      avoid: [
        "Steroids, SARMs, hormones or 'boosters' sold online.",
        "Forum protocols promising changes to bone structure.",
      ],
      timeline: "Real effects over 3–6 months. There is no safe shortcut.",
    },
    {
      id: "sleep",
      title: "Sleep — the multiplier",
      why: "Short sleep shows first: dark circles, grey tone, puffy lids, a less defined jaw.",
      steps: [
        "Fixed bedtime, weekends included, within thirty minutes.",
        "Dark, cool room; screens off an hour before.",
        "No caffeine after 2 pm if you struggle to fall asleep.",
        "Sleep on your back to avoid compressing your face.",
      ],
      avoid: ["Catch-up nights — they do not clear the debt."],
      timeline: "Noticeable in 5–10 days.",
    },
    {
      id: "training",
      title: "Training — posture and the neck line",
      why: "Shoulders, neck and posture frame your face in every photo and every conversation.",
      steps: [
        "Three resistance sessions a week, back and shoulders emphasised.",
        "Light, progressive neck work twice a week at most.",
        "10,000 steps a day for fat management without nervous fatigue.",
        "Chest and hip flexor stretches against slumped posture.",
      ],
      avoid: ["Heavy neck work without progression — the injury risk is real."],
      timeline: "Posture in 4 weeks, physique in 3 months.",
    },
    {
      id: "skincare",
      title: "Skin — a minimal routine held for a long time",
      why: "Texture and tone evenness weigh more in perception than any single feature.",
      steps: [
        "Gentle cleanser morning and night.",
        "Non-comedogenic moisturiser matched to your skin type.",
        "SPF 30 or higher every morning, winter included.",
        "Retinol at night, twice a week, introduced gradually.",
      ],
      avoid: ["Daily aggressive scrubs.", "Stacking five new actives in one week."],
      timeline: "6–8 weeks before judging a routine.",
    },
  ],
};

