import { CalendarCheck, Flame, Medal, ScanFace, Sparkles, Target, Trophy, Zap } from "lucide-react";
import type { ComponentType } from "react";

export type BadgeTier = "bronze" | "silver" | "gold";

export interface BadgeDefinition {
  id: string;
  tier: BadgeTier;
  icon: ComponentType<{ className?: string }>;
  fr: { title: string; detail: string };
  en: { title: string; detail: string };
}

export const BADGES: BadgeDefinition[] = [
  { id: "first_scan", tier: "bronze", icon: ScanFace, fr: { title: "Premier scan", detail: "Ton point de départ est posé." }, en: { title: "First scan", detail: "Your starting point is set." } },
  { id: "first_upgrade", tier: "bronze", icon: Sparkles, fr: { title: "Premier progrès", detail: "Une action concrète terminée." }, en: { title: "First upgrade", detail: "One concrete action completed." } },
  { id: "first_run", tier: "bronze", icon: Zap, fr: { title: "Entrée en Arène", detail: "Ta première partie officielle." }, en: { title: "Arena entry", detail: "Your first official run." } },
  { id: "daily_first", tier: "silver", icon: CalendarCheck, fr: { title: "Rituel lancé", detail: "Ton premier défi du jour." }, en: { title: "Ritual started", detail: "Your first daily challenge." } },
  { id: "five_upgrades", tier: "silver", icon: Target, fr: { title: "Momentum", detail: "Cinq améliorations terminées." }, en: { title: "Momentum", detail: "Five upgrades completed." } },
  { id: "streak_10", tier: "gold", icon: Flame, fr: { title: "Sous tension", detail: "Dix bonnes réponses de suite." }, en: { title: "On fire", detail: "Ten correct answers in a row." } },
  { id: "perfect_run", tier: "gold", icon: Trophy, fr: { title: "Sans faute", detail: "Une partie parfaite en Arène." }, en: { title: "Flawless", detail: "A perfect Arena run." } },
  { id: "rescan", tier: "silver", icon: Medal, fr: { title: "Preuve d’évolution", detail: "Un nouveau scan pour mesurer l’écart." }, en: { title: "Proof of growth", detail: "A new scan to measure progress." } },
];

export function badgeById(id: string) {
  return BADGES.find((badge) => badge.id === id);
}