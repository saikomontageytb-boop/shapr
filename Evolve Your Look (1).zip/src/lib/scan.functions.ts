import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { subjectProfileSchema, type AnalysisResult } from "./analysis-schema";

const ALLOWED_MIME = ["image/jpeg", "image/png", "image/webp"] as const;
const MAX_BYTES = 8 * 1024 * 1024; // 8 MB

const inputSchema = z.object({
  /** data:<mime>;base64,<payload> — held in memory only, never written to disk. */
  imageDataUrl: z.string().min(64).max(14_000_000),
  lang: z.enum(["fr", "en"]).default("fr"),
  profile: subjectProfileSchema.optional(),
});

/** Naive in-memory rate limiter (per instance). Replace with a shared store at scale. */
const hits = new Map<string, number[]>();
const WINDOW_MS = 60 * 60 * 1000;
const MAX_PER_WINDOW = 12;

function rateLimited(key: string) {
  const now = Date.now();
  const list = (hits.get(key) ?? []).filter((t) => now - t < WINDOW_MS);
  list.push(now);
  hits.set(key, list);
  return list.length > MAX_PER_WINDOW;
}

/**
 * Analyse a face photo.
 * Privacy: the image exists only for the duration of this call. It is never
 * stored, never logged, and never given a public URL.
 */
export const analyzeScan = createServerFn({ method: "POST" })
  .inputValidator((input: unknown) => inputSchema.parse(input))
  .handler(async ({ data }): Promise<AnalysisResult> => {
    const ip =
      getRequestHeader("cf-connecting-ip") ??
      getRequestHeader("x-forwarded-for") ??
      "anonymous";

    if (rateLimited(ip)) {
      return {
        ok: false,
        code: "rate_limited",
        message: "You've run a lot of scans in the last hour. Try again shortly.",
      };
    }

    const match = /^data:([a-z/+-]+);base64,([A-Za-z0-9+/=]+)$/.exec(data.imageDataUrl);
    if (!match) {
      return {
        ok: false,
        code: "invalid_format",
        message: "That file isn't a valid JPG, PNG or WebP image.",
      };
    }

    const [, mime, payload] = match as unknown as [string, string, string];
    if (!ALLOWED_MIME.includes(mime as (typeof ALLOWED_MIME)[number])) {
      return {
        ok: false,
        code: "invalid_format",
        message: "Only JPG, PNG and WebP photos are supported.",
      };
    }

    const bytes = Math.floor((payload.length * 3) / 4);
    if (bytes > MAX_BYTES) {
      return { ok: false, code: "too_large", message: "That photo is over 8 MB." };
    }
    if (bytes < 12_000) {
      return {
        ok: false,
        code: "low_quality",
        message: "That photo is too small to read reliably.",
      };
    }

    const { analyzeImage } = await import("@/services/ai/analyze.server");
    const outcome = await analyzeImage(data.imageDataUrl, data.lang, data.profile);

    if (outcome.ok) return { ok: true, analysis: outcome.analysis };
    return { ok: false, code: outcome.code, message: outcome.message };
  });
