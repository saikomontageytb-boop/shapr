/**
 * Academy content model.
 *
 * Lessons are built out of small blocks of different shapes so a lesson never
 * feels like a wall of text: photo, key figure, myth vs fact, side-by-side
 * comparison, drill, checklist, inline question, sources.
 */

export type Difficulty = "base" | "medium" | "hard";
export type Tier = "free" | "pro";

export type TrackIconName =
  | "apple"
  | "flame"
  | "droplet"
  | "scissors"
  | "moon"
  | "shirt"
  | "dumbbell"
  | "users"
  | "heart"
  | "mic"
  | "brain"
  | "sparkles";

export interface Source {
  label: string;
  url: string;
}

export type Block =
  /** Plain explanation. Keep it to a short paragraph. */
  | { kind: "text"; title: string; body: string }
  /** A real photo, referenced by key into academy-images. */
  | { kind: "image"; image: string; caption: string }
  /** Unordered takeaways. */
  | { kind: "list"; title: string; items: string[] }
  /** Ordered protocol the reader can execute today. */
  | { kind: "steps"; title: string; items: string[] }
  /** One number that anchors the lesson. */
  | { kind: "stat"; value: string; label: string; body: string }
  /** Common belief vs what the evidence says. */
  | { kind: "myth"; myth: string; truth: string }
  /** Two columns, e.g. works / does not work. */
  | {
      kind: "compare";
      title: string;
      left: { label: string; items: string[] };
      right: { label: string; items: string[] };
    }
  /** Safety or nuance warning. */
  | { kind: "warn"; title: string; body: string }
  /** A practice drill with a duration. */
  | { kind: "drill"; title: string; body: string; duration: string }
  /** Tick-box habits saved with lesson progress. */
  | { kind: "checklist"; title: string; items: string[] }
  /** Inline question, answered before the lesson continues. */
  | {
      kind: "quiz";
      question: string;
      options: string[];
      answer: number;
      explanation: string;
    }
  /** Links to studies, reviews or guidelines. */
  | { kind: "sources"; items: Source[] };

export interface Lesson {
  id: string;
  title: string;
  /** One line shown in the lesson list. */
  summary: string;
  difficulty: Difficulty;
  minutes: number;
  xp: number;
  tier: Tier;
  /** Image key for the lesson cover. */
  cover: string;
  blocks: Block[];
  /** Bonus lessons only open at this account level. */
  requiresLevel?: number;
}

export interface Track {
  id: string;
  title: string;
  tagline: string;
  /** Two-line description on the track page. */
  intro: string;
  icon: TrackIconName;
  cover: string;
  lessons: Lesson[];
}

/** Progress key used for a completed academy lesson. */
export function lessonKey(trackId: string, lessonId: string) {
  return `academy:${trackId}:${lessonId}`;
}
