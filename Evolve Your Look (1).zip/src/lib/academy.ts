import { useLang } from "./use-lang";
import type { Lang } from "./i18n";
import type { Difficulty, Lesson, Track } from "./academy-types";
import { face } from "@/content/academy/fr/face";
import { hair } from "@/content/academy/fr/hair";
import { hormones } from "@/content/academy/fr/hormones";
import { mind } from "@/content/academy/fr/mind";
import { nutrition } from "@/content/academy/fr/nutrition";
import { seduction } from "@/content/academy/fr/seduction";
import { skin } from "@/content/academy/fr/skin";
import { sleep } from "@/content/academy/fr/sleep";
import { social } from "@/content/academy/fr/social";
import { style } from "@/content/academy/fr/style";
import { training } from "@/content/academy/fr/training";
import { voice } from "@/content/academy/fr/voice";
import { beard } from "@/content/academy/fr/beard";
import { body } from "@/content/academy/fr/body";
import { cardio } from "@/content/academy/fr/cardio";
import { eyes } from "@/content/academy/fr/eyes";
import { fragrance } from "@/content/academy/fr/fragrance";
import { grooming } from "@/content/academy/fr/grooming";
import { habits } from "@/content/academy/fr/habits";
import { mobility } from "@/content/academy/fr/mobility";
import { photo } from "@/content/academy/fr/photo";
import { stress } from "@/content/academy/fr/stress";
import { supplements } from "@/content/academy/fr/supplements";
import { teeth } from "@/content/academy/fr/teeth";
import { posture } from "@/content/academy/fr/posture";
import { sportnutrition } from "@/content/academy/fr/sportnutrition";
import { EN_TRACKS } from "@/content/academy/en";

export type { Block, Difficulty, Lesson, Track, TrackIconName } from "./academy-types";
export { lessonKey } from "./academy-types";

/** Order matters: this is the order of the module list. */
const FR_TRACKS: Track[] = [
  nutrition,
  training,
  cardio,
  sportnutrition,
  body,
  mobility,
  posture,
  face,
  skin,
  teeth,
  eyes,
  beard,
  hair,
  grooming,
  fragrance,
  style,
  photo,
  sleep,
  stress,
  hormones,
  supplements,
  habits,
  social,
  seduction,
  voice,
  mind,
];

export interface AcademyCategory {
  id: string;
  fr: string;
  en: string;
  trackIds: string[];
}

/** Top-level categories shown as buttons on the academy index. */
export const CATEGORIES: AcademyCategory[] = [
  {
    id: "body",
    fr: "Corps & entraînement",
    en: "Body & training",
    trackIds: ["nutrition", "training", "cardio", "sportnutrition", "body", "mobility", "posture"],
  },
  {
    id: "face",
    fr: "Visage & peau",
    en: "Face & skin",
    trackIds: ["face", "skin", "teeth", "eyes", "beard", "hair", "grooming", "fragrance"],
  },
  {
    id: "style",
    fr: "Style & image",
    en: "Style & image",
    trackIds: ["style", "photo"],
  },
  {
    id: "energy",
    fr: "Énergie & récupération",
    en: "Energy & recovery",
    trackIds: ["sleep", "stress", "hormones", "supplements", "habits"],
  },
  {
    id: "social",
    fr: "Social & esprit",
    en: "Social & mind",
    trackIds: ["social", "seduction", "voice", "mind"],
  },
];

export function tracksInCategory(lang: Lang, categoryId: string): Track[] {
  const cat = CATEGORIES.find((c) => c.id === categoryId);
  if (!cat) return [];
  const tracks = ACADEMY[lang];
  return cat.trackIds
    .map((id) => tracks.find((t) => t.id === id))
    .filter((t): t is Track => t !== undefined);
}

export const ACADEMY: Record<Lang, Track[]> = {
  fr: FR_TRACKS,
  en: EN_TRACKS.length ? EN_TRACKS : FR_TRACKS,
};

export function useAcademy(): Track[] {
  return ACADEMY[useLang()];
}

export function findTrack(lang: Lang, id: string): Track | undefined {
  return ACADEMY[lang].find((t) => t.id === id);
}

export function allLessons(lang: Lang): Lesson[] {
  return ACADEMY[lang].flatMap((t) => t.lessons);
}

export const DIFFICULTY_ORDER: Difficulty[] = ["base", "medium", "hard"];

/** Totals shown on the academy landing and the Pro page. */
export function academyStats(lang: Lang) {
  const lessons = allLessons(lang);
  return {
    tracks: ACADEMY[lang].length,
    lessons: lessons.length,
    free: lessons.filter((l) => l.tier === "free").length,
    pro: lessons.filter((l) => l.tier === "pro").length,
    xp: lessons.reduce((sum, l) => sum + l.xp, 0),
  };
}
