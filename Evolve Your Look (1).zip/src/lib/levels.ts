import type { Lang } from "./i18n";

/** XP needed to reach each level. Index 0 = level 1. */
export const THRESHOLDS = [0, 300, 700, 1200, 1900, 2800, 4000, 5500, 7500, 10000];

const TITLES: Record<Lang, string[]> = {
  fr: [
    "Boot",
    "Initié",
    "Réglé",
    "Constant",
    "Affûté",
    "Solide",
    "Net",
    "Redoutable",
    "Référence",
    "Version finale",
  ],
  en: [
    "Boot",
    "Initiate",
    "Dialed in",
    "Consistent",
    "Sharp",
    "Solid",
    "Clean",
    "Formidable",
    "Benchmark",
    "Final build",
  ],
};

export interface LevelInfo {
  level: number;
  /** % towards the next level, 0-100. */
  progress: number;
  into: number;
  span: number;
  toNext: number;
  max: boolean;
}

export function levelInfo(xp: number): LevelInfo {
  let level = 1;
  for (let i = 0; i < THRESHOLDS.length; i += 1) {
    if (xp >= THRESHOLDS[i]!) level = i + 1;
  }
  const max = level >= THRESHOLDS.length;
  const base = THRESHOLDS[level - 1]!;
  const next = max ? base : THRESHOLDS[level]!;
  const span = max ? 1 : next - base;
  const into = xp - base;
  return {
    level,
    progress: max ? 100 : Math.min(100, Math.round((into / span) * 100)),
    into,
    span,
    toNext: max ? 0 : next - xp,
    max,
  };
}

export function levelTitle(lang: Lang, level: number): string {
  return TITLES[lang][Math.min(level, TITLES[lang].length) - 1]!;
}
