import { supabase } from "@/integrations/supabase/client";
import { analysisSchema, type Analysis, type ScanRecord } from "./analysis-schema";

/**
 * Account-backed scan history. Photos are never involved: only the derived
 * report JSON is stored, scoped to the signed-in user by row-level security.
 */

export async function saveScanToCloud(analysis: Analysis): Promise<void> {
  const { data: auth } = await supabase.auth.getUser();
  const user = auth.user;
  if (!user) return;

  await supabase.from("scans").insert({
    user_id: user.id,
    overall_score: analysis.overall_score,
    potential_score: analysis.potential_score,
    percentile: analysis.percentile,
    analysis: analysis as unknown as never,
  });
}

export interface CloudScans {
  scans: ScanRecord[];
  completedQuests: string[];
}

export async function fetchCloudScans(): Promise<CloudScans> {
  const { data, error } = await supabase
    .from("scans")
    .select("id, created_at, analysis, completed_quests")
    .order("created_at", { ascending: true });

  if (error || !data) return { scans: [], completedQuests: [] };

  const scans: ScanRecord[] = [];
  const quests = new Set<string>();

  for (const row of data) {
    const parsed = analysisSchema.safeParse(row.analysis);
    if (!parsed.success) continue;
    scans.push({ id: row.id, created_at: row.created_at, analysis: parsed.data });
    for (const q of row.completed_quests ?? []) quests.add(q);
  }

  return { scans, completedQuests: [...quests] };
}

export async function saveCloudQuests(
  scanId: string,
  completedQuests: string[],
): Promise<void> {
  await supabase.from("scans").update({ completed_quests: completedQuests }).eq("id", scanId);
}
