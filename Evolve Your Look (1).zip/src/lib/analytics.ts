/**
 * Analytics façade.
 *
 * Only product events and non-identifying properties ever pass through here.
 * Photos, image bytes and any facial data are explicitly forbidden.
 */
export type AnalyticsEvent =
  | "landing_view"
  | "scan_started"
  | "photo_uploaded"
  | "analysis_started"
  | "analysis_completed"
  | "analysis_failed"
  | "report_preview_viewed"
  | "paywall_viewed"
  | "checkout_started"
  | "purchase_completed"
  | "account_created"
  | "recommendation_completed"
  | "rescan_completed";

type Props = Record<string, string | number | boolean | undefined>;

const FORBIDDEN = ["image", "photo", "dataurl", "base64", "face"];

export function track(event: AnalyticsEvent, props: Props = {}) {
  const safe: Props = {};
  for (const [k, v] of Object.entries(props)) {
    if (FORBIDDEN.some((f) => k.toLowerCase().includes(f))) continue;
    safe[k] = v;
  }
  if (typeof window === "undefined") return;
  // Sink is pluggable: swap this for a real analytics client when one is added.
  window.dispatchEvent(new CustomEvent("loadout:analytics", { detail: { event, ...safe } }));
  if (import.meta.env.DEV) console.debug("[analytics]", event, safe);
}
