export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      arena_runs: {
        Row: {
          best_streak: number
          category_ids: string[]
          challenge_date: string | null
          correct_count: number
          created_at: string
          difficulty: number
          eliminated: boolean
          id: string
          question_count: number
          score: number
          user_id: string
          xp_earned: number
        }
        Insert: {
          best_streak?: number
          category_ids?: string[]
          challenge_date?: string | null
          correct_count: number
          created_at?: string
          difficulty: number
          eliminated?: boolean
          id?: string
          question_count: number
          score: number
          user_id: string
          xp_earned: number
        }
        Update: {
          best_streak?: number
          category_ids?: string[]
          challenge_date?: string | null
          correct_count?: number
          created_at?: string
          difficulty?: number
          eliminated?: boolean
          id?: string
          question_count?: number
          score?: number
          user_id?: string
          xp_earned?: number
        }
        Relationships: []
      }
      badge_unlocks: {
        Row: {
          badge_id: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          badge_id: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          badge_id?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: []
      }
      lesson_completions: {
        Row: {
          bonus_xp: number
          completed_on: string
          created_at: string
          lesson_key: string
          user_id: string
        }
        Insert: {
          bonus_xp?: number
          completed_on?: string
          created_at?: string
          lesson_key: string
          user_id: string
        }
        Update: {
          bonus_xp?: number
          completed_on?: string
          created_at?: string
          lesson_key?: string
          user_id?: string
        }
        Relationships: []
      }
      lesson_unlocks: {
        Row: {
          created_at: string
          lesson_key: string
          user_id: string
        }
        Insert: {
          created_at?: string
          lesson_key: string
          user_id: string
        }
        Update: {
          created_at?: string
          lesson_key?: string
          user_id?: string
        }
        Relationships: []
      }
      player_progress: {
        Row: {
          account_xp: number
          arena_xp: number
          best_score: number
          created_at: string
          daily_period: string
          daily_streak: number
          daily_xp: number
          last_daily_date: string | null
          runs: number
          show_on_leaderboard: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          account_xp?: number
          arena_xp?: number
          best_score?: number
          created_at?: string
          daily_period?: string
          daily_streak?: number
          daily_xp?: number
          last_daily_date?: string | null
          runs?: number
          show_on_leaderboard?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          account_xp?: number
          arena_xp?: number
          best_score?: number
          created_at?: string
          daily_period?: string
          daily_streak?: number
          daily_xp?: number
          last_daily_date?: string | null
          runs?: number
          show_on_leaderboard?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
          is_pro: boolean
          locale: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id: string
          is_pro?: boolean
          locale?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
          is_pro?: boolean
          locale?: string
          updated_at?: string
        }
        Relationships: []
      }
      scans: {
        Row: {
          analysis: Json
          completed_quests: string[]
          created_at: string
          id: string
          overall_score: number
          percentile: number
          potential_score: number
          user_id: string
        }
        Insert: {
          analysis: Json
          completed_quests?: string[]
          created_at?: string
          id?: string
          overall_score: number
          percentile: number
          potential_score: number
          user_id: string
        }
        Update: {
          analysis?: Json
          completed_quests?: string[]
          created_at?: string
          id?: string
          overall_score?: number
          percentile?: number
          potential_score?: number
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_arena_leaderboard: {
        Args: { p_limit?: number }
        Returns: {
          account_xp: number
          arena_xp: number
          best_score: number
          daily_xp: number
          display_name: string
          is_current_user: boolean
          rank: number
          total_xp: number
        }[]
      }
      submit_arena_run: {
        Args: {
          p_best_streak: number
          p_category_ids?: string[]
          p_challenge_date?: string
          p_correct_count: number
          p_difficulty: number
          p_eliminated: boolean
          p_question_count: number
          p_score: number
        }
        Returns: {
          arena_xp: number
          best_score: number
          daily_streak: number
          new_badges: string[]
          runs: number
          xp_earned: number
        }[]
      }
      submit_arena_run_internal: {
        Args: {
          p_best_streak: number
          p_category_ids?: string[]
          p_challenge_date?: string
          p_correct_count: number
          p_difficulty: number
          p_eliminated: boolean
          p_question_count: number
          p_score: number
          p_user_id: string
        }
        Returns: {
          arena_xp: number
          best_score: number
          daily_streak: number
          new_badges: string[]
          runs: number
          xp_earned: number
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
